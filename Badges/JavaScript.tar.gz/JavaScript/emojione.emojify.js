Maintenance	https://img.shields.io/maintenance/no/red.svg	
npm version	http://img.shields.io/npm/v/emojify.js.svg?style=flat-square	https://www.npmjs.org/package/emojify.js
Bower version	http://img.shields.io/bower/v/emojify.js.svg?style=flat-square	http://bower.io/search/?q=emojify.js
MIT Licensed	http://img.shields.io/npm/l/emojify.js.svg?style=flat-square	http://hassankhan.mit-license.org/
Gitter chat	https://badges.gitter.im/hassankhan/emojify.js.svg	https://gitter.im/hassankhan/emojify.js
Master branch build status	http://img.shields.io/travis/hassankhan/emojify.js.svg?style=flat-square	https://travis-ci.org/hassankhan/emojify.js
Develop branch build status	http://img.shields.io/travis/hassankhan/emojify.js/develop.svg?style=flat-square	https://travis-ci.org/hassankhan/emojify.js
Master branch Windows build status	https://ci.appveyor.com/api/projects/status/908bymld8nm3ykxm?svg=true	https://ci.appveyor.com/project/hassankhan/emojify-js
Develop branch Windows build status	https://ci.appveyor.com/api/projects/status/908bymld8nm3ykxm/branch/develop?svg=true	https://ci.appveyor.com/project/hassankhan/emojify-js
Browser Results	https://ci.testling.com/hassankhan/emojify.js.png	https://ci.testling.com/hassankhan/emojify.js
