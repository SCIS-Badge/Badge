npm	https://img.shields.io/npm/v/hls.js.svg?style=flat	https://npmjs.org/package/hls.js
npm	https://img.shields.io/npm/v/hls.js/alpha.svg?style=flat	https://www.npmjs.com/package/hls.js/v/alpha
Sauce Test Status	https://saucelabs.com/buildstatus/robwalch	https://app.saucelabs.com/u/robwalch
Sauce Test Status	https://saucelabs.com/browser-matrix/robwalch.svg	https://saucelabs.com/u/robwalch
Testing Powered By SauceLabs	https://opensource.saucelabs.com/images/opensauce/powered-by-saucelabs-badge-gray.png?sanitize=true	https://saucelabs.com
