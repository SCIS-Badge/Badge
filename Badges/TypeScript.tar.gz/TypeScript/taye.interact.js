interact.js	https://c4d6f7d727e094887e93-4ea74b676357550bd514a6a5b344c625.ssl.cf2.rackcdn.com/ijs-solid.svg	http://interactjs.io
Gitter	https://badges.gitter.im/taye/interact.js.svg	https://gitter.im/taye/interact.js
jsDelivr	https://data.jsdelivr.com/v1/package/npm/interactjs/badge	https://www.jsdelivr.com/package/npm/interactjs
Build Status	https://travis-ci.org/taye/interact.js.svg?branch=master	https://travis-ci.org/taye/interact.js
