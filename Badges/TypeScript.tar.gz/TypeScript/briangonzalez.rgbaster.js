npm version	http://img.shields.io/npm/v/rgbaster.js.svg?style=flat	https://npmjs.org/package/rgbaster.js
