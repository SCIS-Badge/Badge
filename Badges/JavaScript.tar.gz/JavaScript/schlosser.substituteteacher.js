Build status	https://travis-ci.org/schlosser/substituteteacher.js.svg	https://travis-ci.org/schlosser/substituteteacher.js
Substitute Teacher	http://static.schlosser.io/ss/sub/sub.gif	http://schlosser.github.io/substituteteacher.js/
