npm version	https://badge.fury.io/js/humanize-duration.svg	https://npmjs.org/package/humanize-duration
