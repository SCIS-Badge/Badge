Build Status	https://travis-ci.org/6502ts/6502.ts.svg?branch=master	https://travis-ci.org/6502ts/6502.ts
