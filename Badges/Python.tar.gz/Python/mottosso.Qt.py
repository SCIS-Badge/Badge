Downloads	https://pepy.tech/badge/qt-py	https://pepy.tech/project/qt-py
Build Status	https://travis-ci.org/mottosso/Qt.py.svg?branch=master	https://travis-ci.org/mottosso/Qt.py
PyPI version	https://badge.fury.io/py/Qt.py.svg	https://pypi.python.org/pypi/Qt.py
Anaconda-Server Badge	https://anaconda.org/conda-forge/qt.py/badges/version.svg	https://anaconda.org/conda-forge/qt.py
Gitter	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/Qt-py/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Reviewed by Hound	https://img.shields.io/badge/Reviewed_by-Hound-8E64B0.svg	https://houndci.com
