Build Status	https://travis-ci.org/codemix/fast.js.svg?branch=master	https://travis-ci.org/codemix/fast.js
