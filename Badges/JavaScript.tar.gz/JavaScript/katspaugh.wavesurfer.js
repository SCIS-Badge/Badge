npm version	https://img.shields.io/npm/v/wavesurfer.js.svg?style=flat	https://www.npmjs.com/package/wavesurfer.js
Join the chat at https://gitter.im/katspaugh/wavesurfer.js	https://badges.gitter.im/katspaugh/wavesurfer.js.svg	https://gitter.im/katspaugh/wavesurfer.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Screenshot	https://raw.githubusercontent.com/katspaugh/wavesurfer.js/gh-pages/example/screenshot.png	https://wavesurfer-js.org
Build Status	https://github.com/katspaugh/wavesurfer.js/workflows/wavesurfer.js/badge.svg?branch=master	https://github.com/katspaugh/wavesurfer.js/actions?workflow=wavesurfer.js
Coverage Status	https://coveralls.io/repos/github/katspaugh/wavesurfer.js/badge.svg	https://coveralls.io/github/katspaugh/wavesurfer.js
License	https://img.shields.io/badge/License-BSD%203--Clause-blue.svg	https://opensource.org/licenses/BSD-3-Clause
