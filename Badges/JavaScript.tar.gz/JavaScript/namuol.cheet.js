Build Status	https://drone.io/github.com/namuol/cheet.js/status.png	https://drone.io/github.com/namuol/cheet.js/latest
dependency Status	https://david-dm.org/namuol/cheet.js/status.svg?style=flat-square	https://david-dm.org/namuol/cheet.js#info=devDependencies
devDependency Status	https://david-dm.org/namuol/cheet.js/dev-status.svg?style=flat-square	https://david-dm.org/namuol/cheet.js#info=devDependencies
