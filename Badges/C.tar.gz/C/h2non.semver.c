Build Status	https://travis-ci.org/h2non/semver.c.png	https://travis-ci.org/h2non/semver.c
GitHub release	https://img.shields.io/github/tag/h2non/semver.c.svg	https://github.com/h2non/semver.c/releases
