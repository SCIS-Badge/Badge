Packagist	https://img.shields.io/packagist/dt/afipsdk/afip.php.svg??logo=php&?logoColor=white	https://packagist.org/packages/afipsdk/afip.php
Contributors	https://img.shields.io/github/contributors/afipsdk/afip.php.svg?color=orange	https://github.com/afipsdk/afip.php/graphs/contributors
Closed issues	https://img.shields.io/github/issues-closed-raw/afipsdk/afip.php.svg?color=blueviolet	https://github.com/afipsdk/afip.php/issues
License	https://img.shields.io/github/license/afipsdk/afip.php.svg?color=blue	https://github.com/afipsdk/afip.php/blob/master/LICENSE
Logo	https://github.com/afipsdk/afipsdk.github.io/blob/master/images/logo-colored.png	https://github.com/afipsdk/afip.php
