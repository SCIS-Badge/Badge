# webserver-libev-httpparser

It's a http server library written in C using libev ( http://software.schmorp.de/pkg/libev.html ) and Ryan Dahl's http parser (see http://github.com/joyent/http-parser ) heavily based on lighttz ( https://arekzb.wordpress.com/2008/04/27/lighttz-a-simple-and-fast-web-server/ )

To compile:

    cmake CMakeLists.txt
    make
