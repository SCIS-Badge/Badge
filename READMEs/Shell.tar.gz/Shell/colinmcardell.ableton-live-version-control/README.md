ableton-live-version-control
============================

A script for setting up, updating & merging an Ableton Live .als (an XML based file, gzip'd with a .als extension) project folder with Git version controlling

Currently it is rather useful if you don't attempt to branch and then merge back...

Obviously versioning with WAVs/AIFFs can get rather bloated quickly.
I would like to add some functionality/niceties to clean up some of that bloat as one works on their project.

Eventually I would like to figure out a way to get it playing nice with merges, although that might be a pipe dream.