InstantSearch.js	.github/banner.png	https://www.algolia.com/doc/guides/building-search-ui/what-is-instantsearch/js/
Version	https://img.shields.io/npm/v/instantsearch.js.svg?style=flat-square	https://npmjs.org/package/instantsearch.js
License	http://img.shields.io/badge/license-MIT-green.svg?style=flat-square	LICENSE
Build Status	https://img.shields.io/circleci/project/github/algolia/instantsearch.js.svg?style=flat-square	https://circleci.com/gh/algolia/instantsearch.js
Edit on CodeSandbox	https://codesandbox.io/static/img/play-codesandbox.svg	https://codesandbox.io/s/github/algolia/doc-code-samples/tree/master/InstantSearch.js/getting-started
E-commerce demo preview	https://www.algolia.com/doc/assets/images/build-search-ui/demos/e-commerce-2c7ed6b6.png	https://instantsearchjs.netlify.com/examples/e-commerce/
Media demo preview	https://instantsearchjs.netlify.com/examples/media/capture.png	https://instantsearchjs.netlify.com/examples/media/
Tourism demo preview	https://instantsearchjs.netlify.com/examples/tourism/capture.png	https://instantsearchjs.netlify.com/examples/tourism/
