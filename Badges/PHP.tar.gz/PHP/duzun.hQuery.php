Build Status	https://travis-ci.org/duzun/hQuery.php.svg?branch=master	https://travis-ci.org/duzun/hQuery.php
Donate	https://img.shields.io/badge/Donate-PayPal-green.svg	https://www.paypal.me/duzuns
