npm version	https://img.shields.io/npm/v/streamsaver.svg?style=flat-square	https://www.npmjs.com/package/streamsaver
