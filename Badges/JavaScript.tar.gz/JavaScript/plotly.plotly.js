npm version	https://badge.fury.io/js/plotly.js.svg	https://badge.fury.io/js/plotly.js
circle ci	https://circleci.com/gh/plotly/plotly.js.png?&style=shield&circle-token=1f42a03b242bd969756fc3e53ede204af9b507c0	https://circleci.com/gh/plotly/plotly.js
MIT License	https://img.shields.io/badge/License-MIT-brightgreen.svg	https://github.com/plotly/plotly.js/blob/master/LICENSE
