Build Status	https://travis-ci.org/Tonejs/Tone.js.svg?branch=dev	https://travis-ci.org/Tonejs/Tone.js
codecov	https://codecov.io/gh/Tonejs/Tone.js/branch/dev/graph/badge.svg	https://codecov.io/gh/Tonejs/Tone.js
