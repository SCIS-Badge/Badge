Join the chat at https://gitter.im/olivernn/lunr.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/olivernn/lunr.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Build Status	https://travis-ci.org/olivernn/lunr.js.svg?branch=master	https://travis-ci.org/olivernn/lunr.js
