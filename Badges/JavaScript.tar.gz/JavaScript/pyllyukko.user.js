Build Status	https://travis-ci.org/pyllyukko/user.js.svg?branch=master	https://travis-ci.org/pyllyukko/user.js
