build status	https://secure.travis-ci.org/avoidwork/filesize.js.svg	http://travis-ci.org/avoidwork/filesize.js
downloads	https://img.shields.io/npm/dt/filesize.svg	https://www.npmjs.com/package/filesize
CDNJS version	https://img.shields.io/cdnjs/v/filesize.svg	https://cdnjs.com/libraries/filesize
