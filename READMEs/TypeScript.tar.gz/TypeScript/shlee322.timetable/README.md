Timetable
==========================

[![Build Status](https://travis-ci.org/shlee322/timetable.svg)](https://travis-ci.org/shlee322/timetable)

대학교 모의 시간표 서비스입니다.

공식 서비스 URL : http://timetable.elab.kr

