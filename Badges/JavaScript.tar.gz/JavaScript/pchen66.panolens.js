NPM package	https://img.shields.io/npm/v/panolens.svg	https://www.npmjs.com/package/panolens
License	https://img.shields.io/github/license/pchen66/panolens.js.svg	./LICENSE
Bundle Size	https://badgen.net/bundlephobia/minzip/panolens	https://bundlephobia.com/result?p=panolens
Build Status	https://travis-ci.com/pchen66/panolens.js.svg?branch=dev	https://travis-ci.com/pchen66/panolens.js
Dependencies	https://img.shields.io/david/pchen66/panolens.js.svg	https://david-dm.org/pchen66/panolens.js
Dev Dependencies	https://img.shields.io/david/dev/pchen66/panolens.js.svg	https://david-dm.org/pchen66/panolens.js?type=dev
Language Grade	https://img.shields.io/lgtm/grade/javascript/g/pchen66/panolens.js.svg?logo=lgtm&logoWidth=18&label=code%20quality	https://lgtm.com/projects/g/pchen66/panolens.js/context:javascript
Coverage	https://coveralls.io/repos/github/pchen66/panolens.js/badge.svg?branch=dev	https://coveralls.io/github/pchen66/panolens.js?branch=dev
