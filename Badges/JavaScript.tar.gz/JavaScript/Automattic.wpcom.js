CircleCI	https://circleci.com/gh/Automattic/wpcom.js.svg?style=svg	https://circleci.com/gh/Automattic/wpcom.js
