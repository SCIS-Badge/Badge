Build Status	https://secure.travis-ci.org/indutny/bn.js.png	http://travis-ci.org/indutny/bn.js
