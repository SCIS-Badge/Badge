Build Status	https://img.shields.io/travis/ziishaned/dumper.js/master.svg	https://travis-ci.org/ziishaned/dumper.js
Software License	https://img.shields.io/badge/license-MIT-brightgreen.svg	https://github.com/ziishaned/dumper.js
