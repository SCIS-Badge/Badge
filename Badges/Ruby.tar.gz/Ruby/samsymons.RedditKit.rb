Gem Version	https://badge.fury.io/rb/redditkit.png	https://rubygems.org/gems/redditkit
Build Status	https://circleci.com/gh/samsymons/RedditKit.rb/tree/master.svg?style=svg	https://circleci.com/gh/samsymons/RedditKit.rb/tree/master
Code Climate	https://codeclimate.com/github/samsymons/RedditKit.rb.png	https://codeclimate.com/github/samsymons/RedditKit.rb
Coverage Status	https://coveralls.io/repos/samsymons/RedditKit.rb/badge.png?branch=master	https://coveralls.io/r/samsymons/RedditKit.rb
