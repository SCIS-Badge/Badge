# fade_in_out_dialog
Android Dialog which has fade-in and fade-out animation  （带有淡入淡出动画的Android Dialog）  
效果图：  
![Alt text](https://github.com/xuningjack/fade_in_out_dialog/raw/master/images/0.gif)
