npm	https://img.shields.io/npm/v/long.svg	https://www.npmjs.com/package/long
Build Status	https://travis-ci.org/dcodeIO/long.js.svg	https://travis-ci.org/dcodeIO/long.js
