Build Status	https://secure.travis-ci.org/crcn/sift.js.png	https://secure.travis-ci.org/crcn/sift.js
