Backers on Open Collective	https://opencollective.com/editorjs/backers/badge.svg	#backers
Sponsors on Open Collective	https://opencollective.com/editorjs/sponsors/badge.svg	#sponsors
Join the chat at https://gitter.im/codex-team/editor.js	https://badges.gitter.im/codex-team/editor.js.svg	https://gitter.im/codex-team/editor.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
IE / Edge	https://raw.githubusercontent.com/alrra/browser-logos/master/src/edge/edge_48x48.png	http://godban.github.io/browsers-support-badges/
Firefox	https://raw.githubusercontent.com/alrra/browser-logos/master/src/firefox/firefox_48x48.png	http://godban.github.io/browsers-support-badges/
Chrome	https://raw.githubusercontent.com/alrra/browser-logos/master/src/chrome/chrome_48x48.png	http://godban.github.io/browsers-support-badges/
Safari	https://raw.githubusercontent.com/alrra/browser-logos/master/src/safari/safari_48x48.png	http://godban.github.io/browsers-support-badges/
iOS Safari	https://raw.githubusercontent.com/alrra/browser-logos/master/src/safari-ios/safari-ios_48x48.png	http://godban.github.io/browsers-support-badges/
Opera	https://raw.githubusercontent.com/alrra/browser-logos/master/src/opera/opera_48x48.png	http://godban.github.io/browsers-support-badges/
