npm	https://badge.fury.io/js/inquirer.svg	http://badge.fury.io/js/inquirer
tests	https://travis-ci.org/SBoudrias/Inquirer.js.svg?branch=master	http://travis-ci.org/SBoudrias/Inquirer.js
Coverage Status	https://codecov.io/gh/SBoudrias/Inquirer.js/branch/master/graph/badge.svg	https://codecov.io/gh/SBoudrias/Inquirer.js
FOSSA Status	https://app.fossa.com/api/projects/git%2Bgithub.com%2FSBoudrias%2FInquirer.js.svg?type=shield	https://app.fossa.com/projects/git%2Bgithub.com%2FSBoudrias%2FInquirer.js?ref=badge_shield
