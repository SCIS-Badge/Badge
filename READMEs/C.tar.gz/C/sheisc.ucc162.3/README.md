# ucc162.3
UCC: A Lightweight Open-Source C Compiler for Research and Education.
The original author is Wenjun Wang.

