Quality Assurance	https://github.com/rybakit/msgpack.php/workflows/QA/badge.svg	https://github.com/rybakit/msgpack.php/actions?query=workflow%3AQA
Code Coverage	https://scrutinizer-ci.com/g/rybakit/msgpack.php/badges/coverage.png?b=master	https://scrutinizer-ci.com/g/rybakit/msgpack.php/?branch=master
Mentioned in Awesome PHP	https://awesome.re/mentioned-badge.svg	https://github.com/ziadoz/awesome-php#data-structure-and-storage
