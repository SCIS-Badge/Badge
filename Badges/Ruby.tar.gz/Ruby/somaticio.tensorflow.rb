Build Status	https://circleci.com/gh/somaticio/tensorflow.rb.svg?style=shield	https://circleci.com/gh/somaticio/tensorflow.rb
Code Climate	https://codeclimate.com/github/somaticio/tensorflow.rb/badges/gpa.svg	https://codeclimate.com/github/somaticio/tensorflow.rb
Join the chat at https://gitter.im/tensorflowrb/Lobby	https://badges.gitter.im/tensorflowrb/Lobby.svg	https://gitter.im/tensorflowrb/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Inline docs	https://inch-ci.org/github/somaticio/tensorflow.rb.svg?branch=master	https://inch-ci.org/github/somaticio/tensorflow.rb
