# ASP.NET Core API Demos

Demos from my talk "Building HTTP APIs with ASP.NET Core" on 31.01.2017 at Microsoft TechDays, Baden, Switzerland.
