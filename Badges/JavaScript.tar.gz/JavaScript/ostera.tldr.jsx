Travis-CI	https://api.travis-ci.org/ostera/tldr.jsx.svg	https://travis-ci.org/ostera/tldr.jsx
Become a Patron	https://c5.patreon.com/external/logo/become_a_patron_button.png	https://www.patreon.com/AbstractMachines
