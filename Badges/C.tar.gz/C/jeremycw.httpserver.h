Build Status	https://travis-ci.com/jeremycw/httpserver.h.svg?branch=master	https://travis-ci.com/jeremycw/httpserver.h
