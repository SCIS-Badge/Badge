Build Status	https://travis-ci.org/alexei/sprintf.js.svg?branch=master	https://travis-ci.org/alexei/sprintf.js
NPM Version	https://badge.fury.io/js/sprintf-js.svg	https://badge.fury.io/js/sprintf-js
Dependency Status	https://david-dm.org/alexei/sprintf.js.svg	https://david-dm.org/alexei/sprintf.js
devDependency Status	https://david-dm.org/alexei/sprintf.js/dev-status.svg	https://david-dm.org/alexei/sprintf.js#info=devDependencies
