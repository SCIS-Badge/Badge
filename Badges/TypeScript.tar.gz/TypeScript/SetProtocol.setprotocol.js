License	https://img.shields.io/badge/License-Apache%202.0-blue.svg	https://github.com/SetProtocol/setProtocol.js/blob/master/LICENSE
NPM	https://img.shields.io/npm/v/setprotocol.js.svg	https://www.npmjs.com/package/setprotocol.js
