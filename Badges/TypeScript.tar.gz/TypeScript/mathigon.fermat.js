Build Status	https://travis-ci.org/mathigon/fermat.js.svg?branch=master	https://travis-ci.org/mathigon/fermat.js
npm	https://img.shields.io/npm/v/@mathigon/fermat.svg	https://www.npmjs.com/package/@mathigon/fermat
npm	https://img.shields.io/github/license/mathigon/fermat.js.svg	https://github.com/mathigon/fermat.js/blob/master/LICENSE
