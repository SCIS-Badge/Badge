## Climbing-Movement-Component
Climbing Movement Component  for Unreal Engine.

I am create climbing movement component on c++.

It can:

1. jumps on the wall.
2. Run up the wall.
3. jump over small obstacles
4. Do acceleration under continuous running
5. Make a slide when pressing Shift
6. slide down the inclined surfaces
7. Also, I am create an interactive object on which the rope can also be slide

If you want add this plugin in you project copy folder ClimbingPawnMovementComponent from folder plugins in "your progect folder"\plugins.

To create Visual Studio project file right click on UE project file and choose "Generate VS project file".

## Компонент движения для лазанья
Здесь находится компонент движения который позволит персонажу:

1. Запрыгивать на стену.
2. Бегать по стене.
3. Перескакивать через небольшие препятствия
4. Делать ускорение при непрерывном беге
5. Делать подкат при нажатие Shift
6. Скатываться с наклонных поверхностей
7. А также я создал интерактивный объект веревку по которой  можно скатится

Чтобы использовать плагин скопируйте папку ClimbingPawnMovementComponent из папки plugins в папку "директоря вашего проекта"\plugins.

Чтобы создать файл проекта для Visual Studio, кликнете правой кнопкой мыши по файлу проекта UE и выберите "Generate VS project file".

[Video](https://www.youtube.com/watch?v=dSjZBR9v4DA&feature=youtu.be)

[Habrahabr.ru](https://habrahabr.ru/post/303394/)

[Playable demo game](https://cloud.mail.ru/public/6crd/aUQkDzpfF/)
