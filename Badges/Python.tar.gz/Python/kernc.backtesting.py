Build Status	https://img.shields.io/github/workflow/status/kernc/backtesting.py/CI/master?style=for-the-badge	https://github.com/kernc/backtesting.py/actions
Code Coverage	https://img.shields.io/codecov/c/gh/kernc/backtesting.py.svg?style=for-the-badge	https://codecov.io/gh/kernc/backtesting.py
Backtesting on PyPI	https://img.shields.io/pypi/v/backtesting.svg?color=blue&style=for-the-badge	https://pypi.org/project/backtesting
PyPI downloads	https://img.shields.io/pypi/dd/backtesting.svg?color=skyblue&style=for-the-badge	https://pypi.org/project/backtesting
GitHub Sponsors	https://img.shields.io/github/sponsors/kernc?color=pink&style=for-the-badge	https://github.com/sponsors/kernc
plot of trading simulation	https://i.imgur.com/xRFNHfg.png	https://kernc.github.io/backtesting.py/#example
