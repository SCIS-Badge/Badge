NPM version	https://img.shields.io/npm/v/gridstack.svg	https://www.npmjs.com/package/gridstack
Dependency Status	https://david-dm.org/gridstack/gridstack.js.svg	https://david-dm.org/gridstack/gridstack.js
devDependency Status	https://david-dm.org/gridstack/gridstack.js/dev-status.svg	https://david-dm.org/gridstack/gridstack.js#info=devDependencies
Coverage Status	https://coveralls.io/repos/github/gridstack/gridstack.js/badge.svg?branch=develop	https://coveralls.io/github/gridstack/gridstack.js?branch=develop
downloads	https://img.shields.io/npm/dm/gridstack.svg	https://www.npmjs.com/package/gridstack
Donate	https://img.shields.io/badge/Donate-PayPal-green.svg	https://www.paypal.me/alaind831
Donate	https://img.shields.io/badge/Donate-Venmo-g.svg	https://www.venmo.com/adumesny
Slack Status	https://gridstackjs.troolee.com/badge.svg	https://gridstackjs.troolee.com
NPM version	https://img.shields.io/npm/v/gridstack.svg	https://www.npmjs.com/package/gridstack
