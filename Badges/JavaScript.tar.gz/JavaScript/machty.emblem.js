Build Status	https://travis-ci.org/machty/emblem.js.svg?branch=master	https://travis-ci.org/machty/emblem.js
Bitdeli Badge	https://d2weczhvl823v0.cloudfront.net/machty/emblem.js/trend.png	https://bitdeli.com/free
