Just a collection of colorscripts

to whoever it may concern: 

As the readme always said this is just a collection of color scripts of which I do not (and never did) claim I wrote them all on my own. I've been away for quite some time and only recently noticed some discussions going on and some people claiming I stole them, while others claimed John stole them from me. I never tried to steal, but collected them from various sites (and partly changed them + wrote some on my own) in order to provide a complete collection making it easier to get most scripts as easy as possible. As I committed them here in order to share the collection nobody ever stole from me.

to John:
I hereby want to apologize to you and also want you to know that due to my complete absence, I did not know anything about these rumors at all.
