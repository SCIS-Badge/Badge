Coverage Status	https://badgen.net/codecov/c/github/nuxt/nuxt.js/master	https://codecov.io/gh/nuxt/nuxt.js
Downloads	https://badgen.net/npm/dm/nuxt	https://www.npmjs.com/package/nuxt
Version	https://badgen.net/npm/v/nuxt	https://www.npmjs.com/package/nuxt
License	https://badgen.net/npm/license/nuxt	https://www.npmjs.com/package/nuxt
Discord	https://badgen.net/badge/Discord/join-us/7289DA	https://discord.nuxtjs.org/
Support us	https://img.shields.io/badge/Support%20us-Open%20Collective-41B883.svg	https://oc.nuxtjs.org/
Hire Nuxt	https://api.otechie.com/consultancy/nuxt/badge.svg	https://otechie.com/nuxt?ref=badge
Open Collective Platinum Sponsors	https://opencollective.com/nuxtjs/tiers/platinum-sponsors.svg?avatarHeight=96&width=890	https://opencollective.com/nuxtjs#contributors
Open Collective Gold Sponsors	https://opencollective.com/nuxtjs/tiers/gold-sponsors.svg?avatarHeight=80&width=890	https://opencollective.com/nuxtjs#contributors
Open Collective Silver Sponsors	https://opencollective.com/nuxtjs/tiers/silver-sponsors.svg?avatarHeight=64&width=890	https://opencollective.com/nuxtjs#contributors
Open Collective Bronze Sponsors	https://opencollective.com/nuxtjs/tiers/bronze-sponsors.svg?avatarHeight=48&width=890	https://opencollective.com/nuxtjs#contributors
Open Collective Nuxters	https://opencollective.com/nuxtjs/tiers/nuxters.svg?width=890&button=false	https://opencollective.com/nuxtjs#contributors
Sébastien Chopin	https://avatars2.githubusercontent.com/u/904724?v=4	https://github.com/atinux
Alexandre Chopin	https://avatars2.githubusercontent.com/u/4084277?v=4	https://github.com/alexchopin
Pooya Parsa	https://avatars0.githubusercontent.com/u/5158436?v=4	https://github.com/pi0
Clark Du	https://avatars3.githubusercontent.com/u/4312154?v=4	https://github.com/clarkdo
Alexander Lichter	https://avatars0.githubusercontent.com/u/640208?s=460&v=4	https://github.com/manniL
Jonas Galvez	https://avatars1.githubusercontent.com/u/12291?s=460&v=4	https://github.com/galvez
Dmitry Molotkov	https://avatars2.githubusercontent.com/u/571159?v=4	https://github.com/aldarund
Kevin Marrec	https://avatars2.githubusercontent.com/u/25272043?v=4	https://github.com/kevinmarrec
Pim	https://avatars3.githubusercontent.com/u/1067403?v=4	https://github.com/pimlie
Nuxt Contributors	https://opencollective.com/nuxtjs/contributors.svg?width=890&button=false	https://github.com/nuxt/nuxt.js/graphs/contributors
Open in Gitpod	https://gitpod.io/button/open-in-gitpod.svg	https://gitpod.io/#https://github.com/nuxt/nuxt.js
BrowserStack	https://nuxtjs.org/browserstack.svg	http://browserstack.com
SauceLabs	https://nuxtjs.org/saucelabs.svg	https://saucelabs.com
