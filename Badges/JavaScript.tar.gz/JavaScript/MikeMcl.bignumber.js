npm version	https://img.shields.io/npm/v/bignumber.js.svg	https://www.npmjs.com/package/bignumber.js
build status	https://travis-ci.org/MikeMcl/bignumber.js.svg	https://travis-ci.org/MikeMcl/bignumber.js
