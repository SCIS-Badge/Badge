Cybernetically enhanced web apps: Svelte	https://sveltejs.github.io/assets/banner.png	https://svelte.dev
npm version	https://img.shields.io/npm/v/svelte.svg	https://www.npmjs.com/package/svelte
license	https://img.shields.io/npm/l/svelte.svg	https://github.com/sveltejs/svelte/blob/master/LICENSE
