Build Status	https://travis-ci.com/torokmark/assert.sh.svg?branch=master	https://travis-ci.com/torokmark/assert.sh
