npm version	https://badge.fury.io/js/pixi.js.svg	https://badge.fury.io/js/pixi.js
Inline docs	http://inch-ci.org/github/pixijs/pixi.js.svg?branch=dev	http://inch-ci.org/github/pixijs/pixi.js
Node.js CI	https://github.com/pixijs/pixi.js/workflows/Node.js%20CI/badge.svg	https://github.com/pixi.js/pixi.js/actions?query=workflow%3A%22Node.js+CI%22
Analytics	https://ga-beacon.appspot.com/UA-39213431-2/pixi.js/index	https://github.com/igrigorik/ga-beacon
