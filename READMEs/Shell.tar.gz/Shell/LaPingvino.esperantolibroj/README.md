% README
% README

Esperanto-libroj
===============

Por taŭgigi Esperanto-librojn por legado per elektronikaj legiloj

La Libroj ĉi tie estas en Markdown-formato, por poste facile povi transformi ilin
al epub per Pandoc. Ankoraŭ estas multaj problemoj en la dosieroj pro la aŭtomata
transformo de PDF al Markdown, ekzemple la ĉapeloj ankoraŭ ne ĝustas en ĉiu loko,
la subpaĝaĵoj ankoraŭ enestas kune kun paĝnumeroj kaj la alineoj eble ne ĉie tute
ĝustas. Ankaŭ en multaj lokoj estas frazfinaj streketoj kiujn necesas forigi.

Mi ege bonvenigas vian helpon pri ĉi tiu laboro!
