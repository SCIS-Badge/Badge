WikiToLearn [![Backers on Open Collective](https://opencollective.com/WikiToLearn/backers/badge.svg)](#backers) [![Sponsors on Open Collective](https://opencollective.com/WikiToLearn/sponsors/badge.svg)](#sponsors)
===========

![](doc/logo/wikitolearn-logo.svg.png)

http://meta.wikitolearn.org/WikiToLearn_Home

http://meta.wikitolearn.org/Directory_Structure

Happy Wiki!

## Contributors

This project exists thanks to all the people who contribute. [[Contribute](http://meta.wikitolearn.org/Guide_for_the_development_of_WikiToLearn)]
<!-- <a href= "graphs/contributors">---><img src="https://opencollective.com/WikiToLearn/contributors.svg?width=890" /></a>


## Backers

Thank you to all our backers! 🙏 [[Become a backer](https://opencollective.com/WikiToLearn#backer)]

<a href="https://opencollective.com/WikiToLearn#backers" target="_blank"><img src="https://opencollective.com/WikiToLearn/backers.svg?width=890"></a>


## Sponsors

Support this project by becoming a sponsor. Your logo will show up here with a link to your website. [[Become a sponsor](https://opencollective.com/WikiToLearn#sponsor)]

<a href="https://opencollective.com/WikiToLearn/sponsor/0/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/0/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/1/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/1/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/2/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/2/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/3/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/3/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/4/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/4/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/5/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/5/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/6/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/6/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/7/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/7/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/8/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/8/avatar.svg"></a>
<a href="https://opencollective.com/WikiToLearn/sponsor/9/website" target="_blank"><img src="https://opencollective.com/WikiToLearn/sponsor/9/avatar.svg"></a>


