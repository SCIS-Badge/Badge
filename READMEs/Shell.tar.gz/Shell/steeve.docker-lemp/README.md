docker-lemp
===========

nginx + PHP5-FPM + MariaDB + supervisord on Docker
