NPM version	http://img.shields.io/npm/v/selectize.svg?style=flat	https://www.npmjs.org/package/selectize
CDNJS version	http://img.shields.io/cdnjs/v/selectize.js.svg?style=flat	https://cdnjs.com/libraries/selectize.js
Coverage Status	http://img.shields.io/coveralls/selectize/selectize.js/master.svg?style=flat	https://coveralls.io/r/selectize/selectize.js
Discussion & Help	https://img.shields.io/badge/Discuss-Keybase-cc004c?style=flat	https://keybase.io/team/selectize
