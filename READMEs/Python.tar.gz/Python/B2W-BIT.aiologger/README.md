# Repository Deprecation Note

Don't worry, `aiologger` just moved. It's currently being developed and maintained at [https://www.github.com/async-worker/aiologger](https://www.github.com/async-worker/aiologger) 
