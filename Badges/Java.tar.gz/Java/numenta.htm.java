htm.java awesomeness	https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg	http://cogmission.ai
AGI Probability	https://img.shields.io/badge/AGI%20Probability-97%25-blue.svg	http://numenta.com/#hero
Coolness Factor	https://img.shields.io/badge/Coolness%20Factor-100%25-blue.svg	https://github.com/numenta/htm.java-examples
Build Status	https://travis-ci.org/numenta/htm.java.png?branch=master	https://travis-ci.org/numenta/htm.java
Coverage Status	https://coveralls.io/repos/numenta/htm.java/badge.svg?branch=master&service=github	https://coveralls.io/github/numenta/htm.java?branch=master
Maven Central	https://maven-badges.herokuapp.com/maven-central/org.numenta/htm.java/badge.svg	https://maven-badges.herokuapp.com/maven-central/org.numenta/htm.java
docs-badge	https://img.shields.io/badge/API-docs-blue.svg?style=flat-square	http://numenta.org/docs/htm.java/
Gitter	https://img.shields.io/badge/gitter-join_chat-green.svg?style=flat	https://gitter.im/numenta/htm.java?utm_source=badge
OpenHub	https://www.openhub.net/p/htm-java/widgets/project_thin_badge.gif	https://www.openhub.net/p/htm-java
Gitter	https://img.shields.io/badge/gitter-join_chat-orange.svg?style=flat	https://gitter.im/numenta/public?utm_source=badge
Gitter	https://img.shields.io/badge/gitter-join_chat-green.svg?style=flat	https://gitter.im/numenta/htm.java?utm_source=badge
