NPM version	https://badge.fury.io/js/fishbone.png	http://badge.fury.io/js/fishbone
Analytics	https://ga-beacon.appspot.com/UA-57649-14/aemkei/fishbone	https://github.com/igrigorik/ga-beacon
