NPM Version	https://img.shields.io/npm/v/kute.js.svg?style=flat-square	https://www.npmjs.com/package/kute.js
NPM Downloads	https://img.shields.io/npm/dm/kute.js.svg?style=flat-square	http://npm-stat.com/charts.html?package=kute.js
jsDeliver	https://data.jsdelivr.com/v1/package/npm/kute.js/badge	https://www.jsdelivr.com/package/npm/kute.js
CDNJS	https://img.shields.io/cdnjs/v/kute.js.svg?style=flat-square	https://cdnjs.com/libraries/kute.js
