# @profiscience/knockout-contrib

[![KnockoutJS][knockout-shield]][knockoutjs]
[![Build Status][drone-ci-shield]][drone-ci]
[![Coverage States][codecov-shield]][codecov]
[![Gitter][gitter-shield]][gitter]
[![Dependabot][dependabot-shield]][dependabot]

Goodies for building modern SPAs and rich UIs with [KnockoutJS][knockoutjs]

[Docs](./packages/_)

[knockoutjs]: https://knockoutjs.com
[knockout-shield]: https://img.shields.io/badge/KnockoutJS-3.5.0-red.svg
[drone-ci]: https://ci.caseywebb.xyz/Profiscience/knockout-contrib/
[drone-ci-shield]: https://img.shields.io/drone/build/Profiscience/knockout-contrib?server=https%3A%2F%2Fci.caseywebb.xyz
[codecov]: https://codecov.io/gh/Profiscience/knockout-contrib
[codecov-shield]: https://img.shields.io/codecov/c/github/Profiscience/knockout-contrib.svg
[gitter]: https://gitter.im/Profiscience/ko-component-router
[gitter-shield]: https://img.shields.io/gitter/room/profiscience/ko-component-router.svg
[dependabot-shield]: https://api.dependabot.com/badges/status?host=github&repo=Profiscience/knockout-contrib
[dependabot]: https://dependabot.com
