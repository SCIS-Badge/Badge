Bower version	https://badge.fury.io/bo/angular-chart.js.svg	http://badge.fury.io/bo/angular-chart.js
npm version	https://badge.fury.io/js/angular-chart.js.svg	http://badge.fury.io/js/angular-chart.js
Build Status	https://travis-ci.org/jtblin/angular-chart.js.svg?branch=master	https://travis-ci.org/jtblin/angular-chart.js
Codacy Badge	https://api.codacy.com/project/badge/grade/6aa5ba92f4984a24874e5976ee541623	https://www.codacy.com/app/jtblin/angular-chart-js
Code Coverage	https://d3s6mut3hikguw.cloudfront.net/github/jtblin/angular-chart.js/badges/coverage.svg	https://codeclimate.com/github/jtblin/angular-chart.js
npm	https://img.shields.io/npm/dm/angular-chart.js.svg?maxAge=2592000	https://www.npmjs.com/package/angular-chart.js
