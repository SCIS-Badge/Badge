# GoogleVoice

说明：http://blog.jialezi.net/GoogleVoice


```
wget -N --no-check-certificate https://raw.githubusercontent.com/jialezi/GoogleVoice/master/gv.sh && chmod +x gv.sh && bash gv.sh

```


![](https://i.imgur.com/UBukzgV.gif)
