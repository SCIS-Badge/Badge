npm (tag)	https://img.shields.io/npm/v/ethers	https://www.npmjs.com/package/ethers
Node.js CI	https://github.com/ethers-io/ethers.js/workflows/Node.js%20CI/badge.svg?branch=ethers-v5-beta	https://github.com/ethers-io/ethers.js/actions?query=workflow%3A%22Node.js+CI%22
