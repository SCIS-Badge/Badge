No Maintenance Intended	http://unmaintained.tech/badge.svg	http://unmaintained.tech/
Flattr donate button	https://raw.github.com/balupton/flattr-buttons/master/badge-89x18.gif	https://flattr.com/submit/auto?user_id=SimonWaldherr&url=http%3A%2F%2Fgithub.com%2FSimonWaldherr%2Fpasskit.php
PayPal donate button	https://img.shields.io/badge/donate%20via-paypal-blue.svg	https://www.paypal.me/SimonWaldherr
