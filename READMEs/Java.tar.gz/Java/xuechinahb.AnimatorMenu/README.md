# AnimatorMenu

![imag](https://github.com/xuechinahb/AnimatorMenu/raw/master/image/preview.gif)


Notice
======

Resolution is 480X800px.

The real device is smoother than the simulator.

If your SDK is under 3.0, consider [NineOldAndroids](https://github.com/JakeWharton/NineOldAndroids) instead.


Author
======

Clover Xue <xuechinahb@gmail.com>


Copyright and License
=====================

This module is licensed under the [GPLv3](http://gplv3.fsf.org/) license.

Copyright (C) 2015, by Clover Xue.

All rights reserved.
