Build Status	https://travis-ci.org/jhlywa/chess.js.svg?branch=master	https://travis-ci.org/jhlywa/chess.js
