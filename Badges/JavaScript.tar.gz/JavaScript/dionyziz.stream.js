Build Status	https://travis-ci.org/dionyziz/stream.js.svg?branch=master	https://travis-ci.org/dionyziz/stream.js
codecov.io	https://codecov.io/github/dionyziz/stream.js/coverage.svg?branch=master	https://codecov.io/github/dionyziz/stream.js?branch=master
