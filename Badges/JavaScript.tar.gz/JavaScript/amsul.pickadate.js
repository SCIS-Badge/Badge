Build status: master	https://travis-ci.org/amsul/pickadate.js.svg?branch=master	https://travis-ci.org/amsul/pickadate.js
jsDelivr Hits	https://data.jsdelivr.com/v1/package/npm/pickadate/badge?style=rounded	https://www.jsdelivr.com/package/npm/pickadate
Join the community on Spectrum	https://withspectrum.github.io/badge/badge.svg	https://spectrum.chat/pickadate
Spectrum	https://withspectrum.github.io/badge/badge.svg	https://spectrum.chat/pickadate
