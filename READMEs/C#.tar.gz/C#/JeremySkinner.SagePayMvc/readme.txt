This project is an implementation of the SagePay (http://www.sagepay.com) VSP Server protocol for use with ASP.NET MVC. 

The project was written by Jeremy Skinner (http://www.jeremyskinner.co.uk) and Mark Embling (http://www.markembling.info) for The Sixth Form College Farnborough (http://www.farnborough.ac.uk)

For more details see the following blog posts:
http://www.jeremyskinner.co.uk/2009/09/26/how-not-to-write-a-web-application-the-sagepay-net-integration-kit/
http://www.jeremyskinner.co.uk/2009/09/27/using-sagepay-with-asp-net-mvc/