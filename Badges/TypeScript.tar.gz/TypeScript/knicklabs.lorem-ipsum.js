Codacy Badge	https://api.codacy.com/project/badge/Grade/b55bd2bc24764915adde9b0e74223045	https://www.codacy.com/app/knicklabs/lorem-ipsum.js?utm_source=github.com&utm_medium=referral&utm_content=knicklabs/lorem-ipsum.js&utm_campaign=Badge_Grade
Build Status	https://travis-ci.org/knicklabs/lorem-ipsum.js.svg?branch=master	https://travis-ci.org/knicklabs/lorem-ipsum.js
Coverage Status	https://coveralls.io/repos/github/knicklabs/lorem-ipsum.js/badge.svg?branch=master	https://coveralls.io/github/knicklabs/lorem-ipsum.js?branch=master
npm version	https://badge.fury.io/js/lorem-ipsum.svg	https://badge.fury.io/js/lorem-ipsum
