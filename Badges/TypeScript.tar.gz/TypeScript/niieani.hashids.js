hashids	http://hashids.org/public/img/hashids.gif	http://hashids.org/
Build Status	https://travis-ci.org/niieani/hashids.js.svg	https://travis-ci.org/niieani/hashids.js
Coveralls Status	https://coveralls.io/repos/github/niieani/hashids.js/badge.svg	https://coveralls.io/github/niieani/hashids.js
NPM downloads	https://img.shields.io/npm/dm/hashids.svg?style=flat-square	https://www.npmjs.com/package/hashids
NPM version	https://img.shields.io/npm/v/hashids.svg	https://www.npmjs.com/package/hashids
License	https://img.shields.io/packagist/l/hashids/hashids.svg?style=flat	https://github.com/niieani/hashids.js/blob/master/LICENSE
Chat	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/hashids/hashids?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Play with it using CodeSandbox	https://codesandbox.io/static/img/play-codesandbox.svg	https://codesandbox.io/s/hashids-demo-54qvc?fontsize=14&hidenavigation=1&module=%2Fsrc%2Findex.ts&theme=dark
