Apache 2 License	https://img.shields.io/github/license/c4ptaincrunch/ics.py.svg	https://pypi.python.org/pypi/ics/
Parse ALL the calendars!	http://i.imgur.com/KnSQg48.jpg	https://github.com/C4ptainCrunch/ics.py
