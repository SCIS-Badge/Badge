build static	https://travis-ci.org/dcodeIO/bcrypt.js.svg?branch=master	https://travis-ci.org/dcodeIO/bcrypt.js
	https://img.shields.io/npm/v/bcryptjs.svg	https://npmjs.org/package/bcryptjs
	https://img.shields.io/npm/dm/bcryptjs.svg	https://npmjs.org/package/bcryptjs
