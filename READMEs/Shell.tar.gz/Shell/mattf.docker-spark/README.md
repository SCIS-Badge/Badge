# Apache Spark images for Docker

# Build

* ```docker build -t <name>/spark-base base```
* ```docker build -t <name>/spark-master master```
* ```docker build -t <name>/spark-worker worker```
