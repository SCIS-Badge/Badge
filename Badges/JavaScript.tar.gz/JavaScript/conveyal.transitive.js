NPM version	https://img.shields.io/npm/v/transitive-js.svg?maxAge=2592000&style=flat-square	https://www.npmjs.com/package/transitive-js
Build status	https://img.shields.io/travis/conveyal/transitive.js.svg?style=flat-square	https://travis-ci.org/conveyal/transitive.js
