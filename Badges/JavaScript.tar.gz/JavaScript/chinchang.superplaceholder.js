npm version	https://badge.fury.io/js/superplaceholder.svg	http://badge.fury.io/js/superplaceholder
