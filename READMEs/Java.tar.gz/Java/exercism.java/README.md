# java ![Java CI with Gradle](https://github.com/exercism/java/workflows/Java%20CI%20with%20Gradle/badge.svg) [![Join the chat at https://gitter.im/exercism/xjava](https://badges.gitter.im/exercism/java.svg)](https://gitter.im/exercism/java?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Source for Exercism Exercises in Java.

## Contributing Guide

For general information about how to contribute to Exercism, please refer to the [Contributing Guide](https://github.com/exercism/docs/blob/master/contributing-to-language-tracks).

For information on contributing to this track, refer to the [CONTRIBUTING.md](https://github.com/exercism/java/blob/master/CONTRIBUTING.md) file.
