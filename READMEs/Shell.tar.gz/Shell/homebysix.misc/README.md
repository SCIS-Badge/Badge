# misc

General catch-all for things that doesn't fit into other projects, including various presentations and demos I've given.
