    
	CaptureDevice is an Adobe Air Native Extension for video capturing from cameras
	
	Features
	--------
	  * Windows (Direct Show), Mac (QTkit), iOS and Android support
	  * Multiple cameras support
	  * Update only on new frame
	  