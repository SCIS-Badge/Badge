Build Status	https://travis-ci.org/ansman/validate.js.svg?branch=master	https://travis-ci.org/ansman/validate.js
Coverage Status	https://coveralls.io/repos/ansman/validate.js/badge.svg?branch=master	https://coveralls.io/r/ansman/validate.js?branch=master
