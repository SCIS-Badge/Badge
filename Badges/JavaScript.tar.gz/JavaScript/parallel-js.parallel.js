Build Status	https://travis-ci.org/parallel-js/parallel.js.svg?branch=master	https://travis-ci.org/parallel-js/parallel.js
NPM version	https://badge.fury.io/js/paralleljs.svg	http://badge.fury.io/js/paralleljs
Dependency Status	https://img.shields.io/david/parallel-js/parallel.js.svg	https://david-dm.org/parallel-js/parallel.js
npm	https://img.shields.io/npm/dm/paralleljs.svg?maxAge=2592000	https://www.npmjs.com/package/paralleljs
Pull Requests Welcome	https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat	http://makeapullrequest.com
first-timers-only Friendly	https://img.shields.io/badge/first--timers--only-friendly-blue.svg	http://www.firsttimersonly.com/
