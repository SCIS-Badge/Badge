Build Status	https://img.shields.io/travis/Operational-Transformation/ot.js.svg?style=flat	https://travis-ci.org/Operational-Transformation/ot.js
NPM	https://img.shields.io/npm/v/ot.svg?style=flat	https://npmjs.org/package/ot
