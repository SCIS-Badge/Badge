Build Status	https://travis-ci.org/JamesBarwell/rpi-gpio.js.svg?branch=master	https://travis-ci.org/JamesBarwell/rpi-gpio.js
NPM version	https://badge.fury.io/js/rpi-gpio.svg	http://badge.fury.io/js/rpi-gpio
