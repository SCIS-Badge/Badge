Continuous integration	https://github.com/hypothesis/h/workflows/Continuous%20integration/badge.svg?branch=master	https://github.com/hypothesis/h/actions?query=branch%3Amaster
BSD licensed	https://img.shields.io/badge/license-BSD-blue.svg	https://github.com/hypothesis/h/blob/master/LICENSE
Python 3.6	https://img.shields.io/badge/python-3.6-blue.svg	https://www.python.org/
Docs	https://readthedocs.org/projects/h/badge/?version=latest	https://h.readthedocs.io/en/latest/?badge=latest
Code style: Black	https://img.shields.io/badge/code%20style-black-000000.svg	https://github.com/ambv/black
