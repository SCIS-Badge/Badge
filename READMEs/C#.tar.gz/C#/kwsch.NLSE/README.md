# NLSE
Animal Crossing: New Leaf Save Editor

Edits savedata with the same functions as the [web-js editor](http://usuaris.tinet.cat/mark/acnl_editor/) and more.

Can Import/Export RAM dumps, fix Checksums, and edit numerous things within the garden.dat file.

![Image of Main Window](http://i.imgur.com/5xqLqEO.png)

![Image of Map Items](http://i.imgur.com/TWKOsR7.png)

![Image of Player Editor](http://i.imgur.com/1WugTZd.png)

![Image of Building Editor](http://i.imgur.com/84v31eR.png)
