Bower version	https://badge.fury.io/bo/graphql.js.svg	http://badge.fury.io/bo/graphql.js
NPM version	https://badge.fury.io/js/graphql.js.svg	http://badge.fury.io/js/graphql.js
Build Status	https://travis-ci.org/f/graphql.js.svg?branch=master	https://travis-ci.org/f/graphql.js
