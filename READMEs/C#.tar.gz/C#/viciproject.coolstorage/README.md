This project is no longer being developed and has been replaced by [Iridium](http://github.com/activa/iridium)
