Actions Status	https://github.com/gzuidhof/zarr.js/actions/workflows/test.yml/badge.svg	https://github.com/gzuidhof/zarr.js/actions
NPM badge	https://img.shields.io/npm/v/zarr	https://www.npmjs.com/package/zarr
Documentation	https://img.shields.io/badge/Read%20the-documentation-1abc9c.svg	http://guido.io/zarr.js
