# Tamper Dev

Tamper Dev is an extension that allows you to intercept and edit HTTP/HTTPS requests and responses as they happen without the need of a proxy.

> Tamper Chrome was version 1, which uses a deprecated API, and will stop working at some point.\
> **Users should migrate to Tamper Dev (v2).** Visit https://tamper.dev to update.

