Build Status	https://travis-ci.org/imaya/zlib.js.png?branch=master	https://travis-ci.org/imaya/zlib.js
