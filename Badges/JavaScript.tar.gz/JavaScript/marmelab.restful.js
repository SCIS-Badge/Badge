Build Status	https://travis-ci.org/marmelab/restful.js.svg?branch=master	https://travis-ci.org/marmelab/restful.js
