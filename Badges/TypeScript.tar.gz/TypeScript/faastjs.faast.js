faast.js	./website/static/img/faastjs.png	https://faastjs.org
License	https://img.shields.io/badge/License-Apache%202.0-green.svg	https://opensource.org/licenses/Apache-2.0
CircleCI	https://circleci.com/gh/faastjs/faast.js.svg?style=shield&circle-token=c97f196a78c7173d6ca4e5fc9f09c2cba4ab0647	https://circleci.com/gh/faastjs/faast.js
codecov	https://codecov.io/gh/faastjs/faast.js/branch/master/graph/badge.svg?token=Ml90RLLbEh	https://codecov.io/gh/faastjs/faast.js
Codacy Badge	https://api.codacy.com/project/badge/Grade/1132c1cda6a24a5d85d7c7c61c849ef6	https://www.codacy.com?utm_source=github.com&utm_medium=referral&utm_content=faastjs/faast.js&utm_campaign=Badge_Grade
semantic-release	https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg	https://github.com/semantic-release/semantic-release
FOSSA Status	https://app.fossa.com/api/projects/git%2Bgithub.com%2Ffaastjs%2Ffaast.js.svg?type=shield	https://app.fossa.com/projects/git%2Bgithub.com%2Ffaastjs%2Ffaast.js?ref=badge_shield
