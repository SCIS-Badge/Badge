Build Status	https://travis-ci.org/dtao/lazy.js.svg?branch=master	https://travis-ci.org/dtao/lazy.js
Bower version	https://badge.fury.io/bo/lazy.js.svg	http://badge.fury.io/bo/lazy.js
NPM version	https://badge.fury.io/js/lazy.js.svg	http://badge.fury.io/js/lazy.js
