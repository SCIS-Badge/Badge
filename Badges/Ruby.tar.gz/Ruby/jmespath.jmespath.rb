Gitter chat	https://badges.gitter.im/jmespath/jmespath.rb.png	https://gitter.im/jmespath/jmespath.rb
Build Status	https://travis-ci.org/jmespath/jmespath.rb.png?branch=master	https://travis-ci.org/jmespath/jmespath.rb
