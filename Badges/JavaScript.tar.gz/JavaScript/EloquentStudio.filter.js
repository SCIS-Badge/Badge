CDNJS version	https://img.shields.io/cdnjs/v/filter.js.svg	https://cdnjs.com/libraries/filter.js
Open Source Helpers	https://www.codetriage.com/jiren/filter.js/badges/users.svg	https://www.codetriage.com/jiren/filter.js
