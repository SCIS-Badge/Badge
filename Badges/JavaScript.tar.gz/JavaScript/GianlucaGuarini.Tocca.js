Build Status	https://img.shields.io/travis/GianlucaGuarini/Tocca.js.svg?style=flat-square	https://travis-ci.org/GianlucaGuarini/Tocca.js
NPM version	http://img.shields.io/npm/v/tocca.svg?style=flat-square	https://npmjs.org/package/tocca
NPM downloads	http://img.shields.io/npm/dm/tocca.svg?style=flat-square	https://npmjs.org/package/tocca
MIT License	http://img.shields.io/badge/license-MIT-000000.svg?style=flat-square	LICENSE
CDNJS	https://img.shields.io/cdnjs/v/Tocca.js.svg	https://cdnjs.com/libraries/Tocca.js
Donate	https://img.shields.io/badge/donate-%E2%9D%A4-brightgreen.svg?style=flat-square	https://www.paypal.me/GianlucaGuarini
