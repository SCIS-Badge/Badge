npm version	https://img.shields.io/npm/v/@popperjs/core?style=for-the-badge	https://www.npmjs.com/package/@popperjs/core
npm downloads per month (popper.js + @popperjs/core)	https://img.shields.io/endpoint?style=for-the-badge&url=https://runkit.io/fezvrasta/combined-npm-downloads/1.0.0?packages=popper.js,@popperjs/core	https://www.npmjs.com/package/@popperjs/core
Rolling Versions	https://img.shields.io/badge/Rolling%20Versions-Enabled-brightgreen?style=for-the-badge	https://rollingversions.com/popperjs/popper-core
Popper visualized	https://i.imgur.com/F7qWsmV.jpg	https://popper.js.org
