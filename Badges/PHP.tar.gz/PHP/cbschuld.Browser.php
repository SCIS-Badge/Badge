Build Status	https://travis-ci.org/cbschuld/Browser.php.png?branch=master	https://travis-ci.org/cbschuld/Browser.php
