# GTALua
GTALua is a powerful and flexible scripting engine for GTA V. You can easily create new scripts and even reload them without restarting the game. Writing own plugins has never been as easy.

You can download finished GTALua versions from our [website](http://www.gtalua.com/) or from the [releases page](https://github.com/Freeeaky/GTALua/releases).

## Getting Started
Make sure to check out our wiki!

http://wiki.gtalua.com/index.php/Getting_Started
