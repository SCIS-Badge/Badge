Build Status	https://github.com/mozilla/pdf.js/workflows/CI/badge.svg?branch=master	https://github.com/mozilla/pdf.js/actions?query=workflow%3ACI+branch%3Amaster
