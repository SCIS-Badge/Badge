code style: prettier	https://img.shields.io/badge/code_style-prettier-ff69b4.svg?style=flat-square	https://github.com/prettier/prettier
build status	https://img.shields.io/travis/xmppjs/xmpp.js/master.svg?maxAge=2592000&style=flat-square	https://travis-ci.org/xmppjs/xmpp.js/branches
license	https://img.shields.io/github/license/xmppjs/xmpp.js.svg?maxAge=2592000&style=flat-square	https://raw.githubusercontent.com/xmppjs/xmpp.js/master/LICENSE
