Build Status	https://img.shields.io/circleci/project/github/auth0/auth0.js.svg?branch=master&style=flat-square	https://circleci.com/gh/auth0/auth0.js
NPM version	https://img.shields.io/npm/v/auth0-js.svg?style=flat-square	https://npmjs.org/package/auth0-js
Coverage	https://img.shields.io/codecov/c/github/auth0/auth0.js/master.svg?style=flat-square	https://codecov.io/github/auth0/auth0.js?branch=master
License	https://img.shields.io/npm/l/auth0-js.svg?style=flat-square	#license
Downloads	https://img.shields.io/npm/dm/auth0-js.svg?style=flat-square	https://npmjs.org/package/auth0-js
FOSSA Status	https://app.fossa.com/api/projects/git%2Bgithub.com%2Fauth0%2Fauth0.js.svg?type=shield	https://app.fossa.com/projects/git%2Bgithub.com%2Fauth0%2Fauth0.js?ref=badge_shield
FOSSA Status	https://app.fossa.com/api/projects/git%2Bgithub.com%2Fauth0%2Fauth0.js.svg?type=large	https://app.fossa.com/projects/git%2Bgithub.com%2Fauth0%2Fauth0.js?ref=badge_large
