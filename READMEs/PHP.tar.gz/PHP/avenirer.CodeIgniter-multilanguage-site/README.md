# CodeIgniter-multilanguage-site
A multi-language site created in CodeIgniter 3

1. First of all, import the SQL file into the database.

2. Go to the database.php file in application/config and update the database settings accordingly to your settings.

3. Go to the config.php file in application/config, change the ```$config['base_url']```, ```$config['sess_cookie_name']```, ```$config['csrf_token_name']```, ```$config['csrf_cookie_name']```, add an ```$config['encryption_key']```.

4. Go to yoursite/admin, login with username: "administrator" and password: "password".

This is not a final product. Take care. If you have issues to report, I would be more than happy to find a solutions. If you don't understand something, you can write me at avenir.ro[@]gmail(.)com

Questions? Ask away...
