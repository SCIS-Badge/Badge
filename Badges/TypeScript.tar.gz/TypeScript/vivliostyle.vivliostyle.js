Build Status	https://travis-ci.com/vivliostyle/vivliostyle.js.svg?branch=master	https://travis-ci.com/vivliostyle/vivliostyle.js
Sauce Test Status	https://saucelabs.com/buildstatus/vivliostyle	https://app.saucelabs.com/u/vivliostyle
GitHub contributors	https://img.shields.io/github/contributors/vivliostyle/vivliostyle.js.svg	https://github.com/vivliostyle/vivliostyle.js/graphs/contributors
PR's welcome	https://img.shields.io/badge/PRs%20-welcome-brightgreen.svg	https://github.com/vivliostyle/vivliostyle.js/blob/master/CONTRIBUTING.md
npm: version	https://flat.badgen.net/npm/v/@vivliostyle/core	https://www.npmjs.com/package/@vivliostyle/core
npm: total downloads	https://flat.badgen.net/npm/dt/@vivliostyle/core	https://www.npmjs.com/package/@vivliostyle/core
npm: version	https://flat.badgen.net/npm/v/@vivliostyle/viewer	https://www.npmjs.com/package/@vivliostyle/viewer
npm: total downloads	https://flat.badgen.net/npm/dt/@vivliostyle/viewer	https://www.npmjs.com/package/@vivliostyle/viewer
npm: version	https://flat.badgen.net/npm/v/@vivliostyle/cli	https://www.npmjs.com/package/@vivliostyle/cli
npm: total downloads	https://flat.badgen.net/npm/dt/@vivliostyle/cli	https://www.npmjs.com/package/@vivliostyle/cli
npm: version	https://flat.badgen.net/npm/v/@vivliostyle/react	https://www.npmjs.com/package/@vivliostyle/react
npm: total downloads	https://flat.badgen.net/npm/dt/@vivliostyle/react	https://www.npmjs.com/package/@vivliostyle/react
npm: version	https://flat.badgen.net/npm/v/@vivliostyle/vfm	https://www.npmjs.com/package/@vivliostyle/vfm
npm: total downloads	https://flat.badgen.net/npm/dt/@vivliostyle/vfm	https://www.npmjs.com/package/@vivliostyle/vfm
npm: version	https://flat.badgen.net/npm/v/@vivliostyle/print	https://www.npmjs.com/package/@vivliostyle/print
npm: total downloads	https://flat.badgen.net/npm/dt/@vivliostyle/print	https://www.npmjs.com/package/@vivliostyle/print
npm: version	https://flat.badgen.net/npm/v/create-book	https://www.npmjs.com/package/create-book
npm: total downloads	https://flat.badgen.net/npm/dt/create-book	https://www.npmjs.com/package/create-book
npm: total downloads	https://flat.badgen.net/npm/dt/create-vivliostyle-theme	https://npmjs.com/package/create-vivliostyle-theme
Testing Powered By SauceLabs	https://saucelabs.github.io/images/opensauce/powered-by-saucelabs-badge-white.png?sanitize=true	https://saucelabs.com
