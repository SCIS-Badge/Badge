ASP.NET SignalR SQL Server Scaleout
========

AppVeyor: [![AppVeyor](https://ci.appveyor.com/api/projects/status/iulqt7mtu1dot7fh/branch/dev?svg=true)](https://ci.appveyor.com/project/aspnetci/SignalR-SqlServer/branch/dev)

Travis:   [![Travis](https://travis-ci.org/aspnet/SignalR-SqlServer.svg?branch=dev)](https://travis-ci.org/aspnet/SignalR-SqlServer)

ASP.NET SignalR is a is a new library for ASP.NET developers that makes it incredibly simple to add real-time web functionality to your applications. 

This project is part of ASP.NET Core. You can find samples, documentation and getting started instructions for ASP.NET Core at the [Home](https://github.com/aspnet/home) repo.
