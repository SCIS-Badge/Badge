Logo	https://raw.githubusercontent.com/amoffat/sh/master/logo-230.png	https://amoffat.github.com/sh
Version	https://img.shields.io/pypi/v/sh.svg?style=flat-square	https://pypi.python.org/pypi/sh
Downloads Status	https://img.shields.io/pypi/dm/sh.svg?style=flat-square	https://pypi.python.org/pypi/sh
Python Versions	https://img.shields.io/pypi/pyversions/sh.svg?style=flat-square	https://pypi.python.org/pypi/sh
Build Status	https://img.shields.io/travis/amoffat/sh/master.svg?style=flat-square	https://travis-ci.org/amoffat/sh
Coverage Status	https://img.shields.io/coveralls/amoffat/sh.svg?style=flat-square	https://coveralls.io/r/amoffat/sh?branch=master
