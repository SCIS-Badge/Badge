# libfixmath

This is a mirror of the libfixmath's original SVN repository on Google Code.

Libfixmath implements Q16.16 format fixed point operations in C.

License: <a href="http://www.opensource.org/licenses/mit-license.php">MIT</a>
