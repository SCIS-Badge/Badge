CircleCI	https://circleci.com/gh/datenwolf/linmath.h.svg?style=svg	https://app.circleci.com/pipelines/github/datenwolf/linmath.h
