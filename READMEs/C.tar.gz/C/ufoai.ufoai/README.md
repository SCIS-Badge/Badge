[![Build Status](https://travis-ci.org/ufoai/ufoai.svg?branch=master)](https://travis-ci.org/ufoai/ufoai)
[![Build status](https://ci.appveyor.com/api/projects/status/v3a601svb3odeot9?svg=true)](https://ci.appveyor.com/project/ufoai/ufoai)

Please see the [wiki](http://ufoai.sf.net) for more information on how to compile the game and the gamedata
