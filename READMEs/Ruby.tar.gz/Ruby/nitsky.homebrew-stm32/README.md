homebrew-stm32
==============

1. Install homebrew if you haven't already: http://brew.sh/

2. Tap this repo: `brew tap nitsky/stm32`

3. Install gcc for ARM: `brew install arm-none-eabi-gcc`

4. Install stlink: `brew install --HEAD stlink`
