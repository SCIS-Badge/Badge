Travis Build Status	https://api.travis-ci.org/fastly/insights.js.svg	https://travis-ci.org/fastly/insights.js
