Build Status	http://img.shields.io/travis/liferay/senna.js/master.svg?style=flat	https://travis-ci.org/liferay/senna.js
Dependencies Status	http://img.shields.io/david/liferay/senna.js.svg?style=flat	https://david-dm.org/liferay/senna.js#info=dependencies
DevDependencies Status	http://img.shields.io/david/dev/liferay/senna.js.svg?style=flat	https://david-dm.org/liferay/senna.js#info=devDependencies
Eduardo Lundgren	https://avatars3.githubusercontent.com/u/113087?s=70	https://github.com/eduardolundgren
Bruno Basto	https://avatars1.githubusercontent.com/u/156388?s=70	https://github.com/brunobasto
Sauce Test Status	https://saucelabs.com/browser-matrix/senna.svg	https://travis-ci.org/liferay/senna.js
