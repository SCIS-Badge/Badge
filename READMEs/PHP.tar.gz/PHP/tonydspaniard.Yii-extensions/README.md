Yii Framework Extensions
=============================

The following is my small contribution for the amazing Yii community.

IMPORTANT NOTICE
================
This repository will soon be refactored to a list of sub-modules pointing to isolated extensions / widgets / helpers 
in order to help you and the libraries to be improved independently. Was a mistake on the first place to create one 
single and huge repository to publish all my extensions. 

Hope with this change things will be better for all of us to maintain/improve :)


EXTENSIONS LIBRARY
------------------

This repository has the following structure and extensions:

      behaviors/
      	EDateFormatBehavior/
      	EJsonBehavior/          http://www.yiiframework.com/extension/ejsonbehavior/
      	
      extensions/          
      	EFeed/                  http://www.yiiframework.com/extension/efeed/
      	EGMap/                  http://www.yiiframework.com/extension/egmap/
      	EGeoIp/                 http://www.yiiframework.com/extension/egeoip/
      	EGeoNameService/        http://www.yiiframework.com/extension/egeonameservice/
      	EHttpClient/            http://www.yiiframework.com/extension/ehttpclient/
      	EWebBrowser/            http://www.yiiframework.com/extension/ewebbrowser/
        EScriptBoost/           http://www.yiiframework.com/extension/escriptboost/
      	
      helpers/
      	ECurrencyHelper/        http://www.yiiframework.com/extension/ecurrencyhelper/
      	EDownloadHelper/        http://www.yiiframework.com/extension/edownloadhelper/
      	EIniHelper/             http://www.yiiframework.com/extension/einihelper/
      	
      validators/
      	EABARoutingNumberValidator/   http://www.yiiframework.com/extension/eabavalidator/
      	ECCValidator/                 http://www.yiiframework.com/extension/eccvalidator/
      	EConditionalValidator/        http://www.yiiframework.com/extension/econditionalvalidator/
      	EIBANValidator/               http://www.yiiframework.com/extension/eibanvalidator/
      
      widgets/
      	EDateRangePicker/       http://www.yiiframework.com/extension/edaterangepicker/
            EProjekktor/            http://www.yiiframework.com/extension/jqprettyphoto/
      	jqPrettyPhoto/          http://www.yiiframework.com/extension/jqprettyphoto/

      	
      README               this file


EXTENSIONS WIKI
------------------

Please, follow any of the links of each extension to further know its use.

