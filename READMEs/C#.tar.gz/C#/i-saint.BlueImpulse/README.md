![image](doc/ss1.png)  
[youtube](https://www.youtube.com/watch?v=upZZVJW7K64) | [unity web player](http://primitive-games.jp/Unity/blue_impulse/)  | [executable (windows)](https://raw.githubusercontent.com/i-saint/BlueImpulse/master/doc/BlueImpulse.zip)  
  
"blue impulse" by primitive  
PC demo released at [TokyoDemoFest2015](http://tokyodemofest.jp/) ([pouet](http://www.pouet.net/party.php?which=1542&when=2015))  
code: i-saint ([@i_saint](https://twitter.com/i_saint))  
sound: Masaki Kawano ([@pocomo](https://twitter.com/pocomo))  
