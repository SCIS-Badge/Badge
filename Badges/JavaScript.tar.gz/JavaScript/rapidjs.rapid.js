npm	https://img.shields.io/npm/v/rapid.js.svg?style=flat-square	https://www.npmjs.com/package/rapid.js
npm	https://img.shields.io/npm/dt/rapid.js.svg?style=flat-square	https://www.npmjs.com/package/rapid.js
npm	https://img.shields.io/travis/rapidjs/rapid.js.svg?branch=master&style=flat-square	https://www.npmjs.com/package/rapid.js
