NPM version	http://img.shields.io/npm/v/thenjs.svg	https://npmjs.org/package/thenjs
Build Status	http://img.shields.io/travis/teambition/then.js.svg	https://travis-ci.org/teambition/then.js
