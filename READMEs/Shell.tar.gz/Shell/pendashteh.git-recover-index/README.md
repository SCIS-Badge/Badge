# Rescue your ever lost commits
Recovers your staged file (index) after a hard reset: $ git reset HEAD --hard &amp;&amp; git recover-index

# Quick usage

```
$ cd /path/to/disatered/repo
$ git clone git@github.com:pendashteh/git-recover-index.git $HOME/.git-recover-index
$ $HOME/.git-recover-index/git-recover-index.sh
```