Tesseract.js	./docs/images/tesseract.png	https://tesseract.projectnaptha.com/
Gitpod Ready-to-Code	https://img.shields.io/badge/Gitpod-ready--to--code-blue?logo=gitpod	https://github.com/naptha/tesseract.js
Financial Contributors on Open Collective	https://opencollective.com/tesseractjs/all/badge.svg?label=financial+contributors	https://opencollective.com/tesseractjs
npm version	https://badge.fury.io/js/tesseract.js.svg	https://badge.fury.io/js/tesseract.js
Maintenance	https://img.shields.io/badge/Maintained%3F-yes-green.svg	https://github.com/naptha/tesseract.js/graphs/commit-activity
License	https://img.shields.io/badge/License-Apache%202.0-blue.svg	https://opensource.org/licenses/Apache-2.0
Code Style	https://badgen.net/badge/code%20style/airbnb/ff5a5f?icon=airbnb	https://github.com/airbnb/javascript
Downloads Total	https://img.shields.io/npm/dt/tesseract.js.svg	https://www.npmjs.com/package/tesseract.js
Downloads Month	https://img.shields.io/npm/dm/tesseract.js.svg	https://www.npmjs.com/package/tesseract.js
fancy demo gif	./docs/images/demo.gif	http://tesseract.projectnaptha.com
Tesseract.js Video	./docs/images/video-demo.gif	https://github.com/jeromewu/tesseract.js-video
Open in Gitpod	https://gitpod.io/button/open-in-gitpod.svg	https://gitpod.io/#https://github.com/naptha/tesseract.js/blob/master/examples/browser/demo.html
