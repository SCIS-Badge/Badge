CDNJS	https://img.shields.io/cdnjs/v/Base64.svg	https://cdnjs.com/libraries/Base64
