Build Badge	https://secure.travis-ci.org/schmittjoh/twig.js.png	http://travis-ci.org/schmittjoh/twig.js
Scrutinizer Badge	https://scrutinizer-ci.com/g/h2s/twig.js/badges/quality-score.png?b=master	https://scrutinizer-ci.com/g/h2s/twig.js/?branch=master
