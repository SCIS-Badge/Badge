Build status	https://ci.appveyor.com/api/projects/status/phfjjahhs9j4gxvs?svg=true	https://ci.appveyor.com/project/sheredom/utf8-h
Build status	https://api.travis-ci.org/repositories/sheredom/utf8.h.svg	https://travis-ci.org/sheredom/utf8.h
