NPM version	https://img.shields.io/npm/v/mosaic-js.svg?style=flat-square	https://www.npmjs.com/package/mosaic-js
License	https://img.shields.io/npm/l/mosaic-js.svg?style=flat-square	https://github.com/maraisr/mosaic-js/blob/master/license.md
