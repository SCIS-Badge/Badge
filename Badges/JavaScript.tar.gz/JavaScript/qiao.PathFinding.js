Gitter	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/qiao/PathFinding.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Build Status	https://travis-ci.org/qiao/PathFinding.js.svg?branch=master	https://travis-ci.org/qiao/PathFinding.js
Dependency Status	https://david-dm.org/qiao/pathfinding.js.png	https://david-dm.org/qiao/pathfinding.js
Documentation Status	https://readthedocs.org/projects/pathfindingjs/badge/	https://readthedocs.org/projects/pathfindingjs/?badge=latest
