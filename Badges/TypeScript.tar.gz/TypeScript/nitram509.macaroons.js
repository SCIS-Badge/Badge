License: Apache 2.0	https://img.shields.io/:license-Apache%202.0-blue.svg	http://www.apache.org/licenses/LICENSE-2.0
Build Status	https://travis-ci.org/nitram509/jmacaroons.svg?branch=master	https://travis-ci.org/nitram509/macaroons.js
Built with Grunt	https://cdn.gruntjs.com/builtwith.png	http://gruntjs.com/
NPM	https://nodei.co/npm/macaroons.js.png	https://nodei.co/npm/macaroons.js/
endorse	https://api.coderwall.com/nitram509/endorsecount.png	https://coderwall.com/nitram509
Stargazers over time	https://starchart.cc/nitram509/macaroons.js.svg	https://starchart.cc/nitram509/macaroons.js
