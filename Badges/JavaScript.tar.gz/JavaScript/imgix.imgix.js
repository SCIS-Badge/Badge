NPM Version	https://img.shields.io/npm/v/imgix.js.svg	https://www.npmjs.com/package/imgix.js
Build Status	https://travis-ci.com/imgix/imgix.js.svg?branch=main	https://travis-ci.com/imgix/imgix.js
Monthly Downloads	https://img.shields.io/npm/dm/imgix.js.svg	https://www.npmjs.com/package/imgix.js
styled with prettier	https://img.shields.io/badge/styled_with-prettier-ff69b4.svg	https://github.com/prettier/prettier
