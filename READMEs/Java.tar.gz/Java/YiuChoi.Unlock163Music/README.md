# Unblock163MusicClient - Xposed

Compatible with the v3.3.0,3.2.1,3.1.4,3.1.3 app.

## Thanks

Thanks bin456789 for his source code [https://github.com/bin456789/Unblock163MusicClient-Xposed]