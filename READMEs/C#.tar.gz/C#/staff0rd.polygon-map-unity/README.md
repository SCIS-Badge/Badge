polygon-map-unity
==============

A C#/Unity3d implementation of Polygon Map Generation per the article [here](http://www-cs-students.stanford.edu/~amitp/game-programming/polygon-map-generation/), using the
as3delaunay library from [here](https://github.com/jceipek/Unity-delaunay)

![Polygon Map Generator](/screenshot.PNG?raw=true)
