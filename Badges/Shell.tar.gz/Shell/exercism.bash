Build Status	https://travis-ci.org/exercism/bash.svg?branch=master	https://travis-ci.org/exercism/bash
Gitter	https://badges.gitter.im/exercism/bash.svg	https://gitter.im/exercism/bash?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge
