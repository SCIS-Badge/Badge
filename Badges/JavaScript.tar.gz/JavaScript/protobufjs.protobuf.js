	https://img.shields.io/npm/v/protobufjs.svg	https://npmjs.org/package/protobufjs
	https://travis-ci.org/dcodeIO/protobuf.js.svg?branch=master	https://travis-ci.org/dcodeIO/protobuf.js
	https://img.shields.io/npm/dm/protobufjs.svg	https://npmjs.org/package/protobufjs
