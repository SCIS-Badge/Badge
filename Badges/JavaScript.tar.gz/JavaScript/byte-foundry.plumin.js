Dependency Status	https://david-dm.org/byte-foundry/plumin.js.svg?theme=shields.io	https://david-dm.org/byte-foundry/plumin.js
devDependency Status	https://david-dm.org/byte-foundry/plumin.js/dev-status.svg?theme=shields.io	https://david-dm.org/byte-foundry/plumin.js#info=devDependencies
Gitter	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/byte-foundry/prototypo?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Build Status	https://travis-ci.org/byte-foundry/plumin.js.svg?branch=master	https://travis-ci.org/byte-foundry/plumin.js
