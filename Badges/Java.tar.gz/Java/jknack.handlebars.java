Become a Patreon	https://img.shields.io/badge/patreon-donate-orange.svg	https://patreon.com/edgarespina
Build Status	https://travis-ci.org/jknack/handlebars.java.svg?branch=master	https://travis-ci.org/jknack/handlebars.java
coveralls.io	https://img.shields.io/coveralls/jknack/handlebars.java.svg	https://coveralls.io/r/jknack/handlebars.java?branch=master
codecov	https://codecov.io/gh/jknack/handlebars.java/branch/master/graph/badge.svg	https://codecov.io/gh/jknack/handlebars.java
Maven Central	https://maven-badges.herokuapp.com/maven-central/com.github.jknack/handlebars/badge.svg	https://maven-badges.herokuapp.com/maven-central/com.github.jknack/handlebars
javadoc	https://javadoc.io/badge/com.github.jknack/handlebars.svg	https://javadoc.io/doc/com.github.jknack/handlebars
Maven Central	https://maven-badges.herokuapp.com/maven-central/com.github.jknack/handlebars/badge.svg	https://maven-badges.herokuapp.com/maven-central/com.github.jknack/handlebars
