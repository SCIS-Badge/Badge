Logo	http://gpu.rocks/static/media/jelly.3587de60.png	http://gpu.rocks/
Join the chat at https://gitter.im/gpujs/gpu.js	https://badges.gitter.im/gpujs/gpu.js.svg	https://gitter.im/gpujs/gpu.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Slack	https://slack.bri.im/badge.svg	https://slack.bri.im
