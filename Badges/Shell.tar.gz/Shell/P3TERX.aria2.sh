GitHub Stars	https://img.shields.io/github/stars/P3TERX/aria2.sh.svg?style=flat-square&label=Stars&logo=github	https://github.com/P3TERX/aria2.sh/stargazers
GitHub Forks	https://img.shields.io/github/forks/P3TERX/aria2.sh.svg?style=flat-square&label=Forks&logo=github	https://github.com/P3TERX/aria2.sh/fork
