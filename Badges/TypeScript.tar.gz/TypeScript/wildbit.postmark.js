Postmark Logo	https://github.com/wildbit/postmark.js/raw/master/postmark.png	https://postmarkapp.com
Build Status	https://circleci.com/gh/wildbit/postmark.js.svg?style=shield	https://circleci.com/gh/wildbit/postmark.js
License	http://img.shields.io/badge/license-MIT-blue.svg?style=flat	http://www.opensource.org/licenses/MIT
npm version	https://badge.fury.io/js/postmark.svg	https://badge.fury.io/js/postmark
