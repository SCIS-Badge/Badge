Build Status	https://semaphoreci.com/api/v1/eavichay/slim-js/branches/master/badge.svg	https://semaphoreci.com/eavichay/slim-js
