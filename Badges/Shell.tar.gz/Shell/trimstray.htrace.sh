Travis-CI	https://travis-ci.org/trimstray/htrace.sh.svg?branch=master	https://travis-ci.org/trimstray/htrace.sh
Dockerfile	https://img.shields.io/badge/Dockerfile-Available-blue.svg	https://github.com/trimstray/htrace.sh/tree/master/build
Master	https://github.com/trimstray/htrace.sh/blob/master/static/img/htrace.sh_logo.png	https://github.com/trimstray/htrace.sh
