Build Status	https://img.shields.io/circleci/project/vuejs/vue/dev.svg	https://circleci.com/gh/vuejs/vue/tree/dev
Coverage Status	https://img.shields.io/codecov/c/github/vuejs/vue/dev.svg	https://codecov.io/github/vuejs/vue?branch=dev
Downloads	https://img.shields.io/npm/dm/vue.svg	https://www.npmjs.com/package/vue
Version	https://img.shields.io/npm/v/vue.svg	https://www.npmjs.com/package/vue
License	https://img.shields.io/npm/l/vue.svg	https://www.npmjs.com/package/vue
Sauce Test Status	https://saucelabs.com/browser-matrix/vuejs.svg	https://saucelabs.com/u/vuejs
vue-router-status	https://img.shields.io/npm/v/vue-router.svg	https://npmjs.com/package/vue-router
vuex-status	https://img.shields.io/npm/v/vuex.svg	https://npmjs.com/package/vuex
vue-cli-status	https://img.shields.io/npm/v/vue-cli.svg	https://npmjs.com/package/vue-cli
vue-loader-status	https://img.shields.io/npm/v/vue-loader.svg	https://npmjs.com/package/vue-loader
vue-server-renderer-status	https://img.shields.io/npm/v/vue-server-renderer.svg	https://npmjs.com/package/vue-server-renderer
vue-class-component-status	https://img.shields.io/npm/v/vue-class-component.svg	https://npmjs.com/package/vue-class-component
vue-rx-status	https://img.shields.io/npm/v/vue-rx.svg	https://npmjs.com/package/vue-rx
vue-devtools-status	https://img.shields.io/chrome-web-store/v/nhdogjmejiglipccpnnnanhbledajbpd.svg	https://chrome.google.com/webstore/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd
