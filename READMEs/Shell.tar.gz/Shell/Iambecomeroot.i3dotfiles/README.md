#My Dotfiles
Here are the dotfiles for my Arch Linux installation

##Screenshots:
######Clean
![Clean Screenshot](http://i.imgur.com/sKPvCfK.png "Clean Screenshot")
######Fake Busy
![Fake Busy Screenshot](http://i.imgur.com/NN2WJQG.png "Fake Busy Screenshot")
######Neofetch
![Neofetch Screenshot](http://i.imgur.com/z3cSYe9.png "Neofetch Screenshot")
######Sublime Text 3
![Sublime Text Screenshot](http://i.imgur.com/TxDV9Vx.png "Sublime Text Screenshot")
######ncmpcpp
![ncmpcpp Screenshot](http://i.imgur.com/CuMab7g.png "ncmpcpp Screenshot")
######OBLogout
!['OBLogout Screenshot'](http://i.imgur.com/JtWKpic.png "OBLogout Screenshot")
######Wallpaper
![Wallpaper](http://i.imgur.com/EzZ80HE.jpg "Wallpaper")