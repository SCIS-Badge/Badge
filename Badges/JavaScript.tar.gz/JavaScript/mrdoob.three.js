NPM Package	https://img.shields.io/npm/v/three	https://www.npmjs.com/package/three
Build Size	https://badgen.net/bundlephobia/minzip/three	https://bundlephobia.com/result?p=three
NPM Downloads	https://img.shields.io/npm/dw/three	https://www.npmtrends.com/three
