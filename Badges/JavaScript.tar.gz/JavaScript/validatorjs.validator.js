NPM version	http://img.shields.io/npm/v/validator.svg	https://npmjs.org/package/validator
Build Status	https://travis-ci.org/validatorjs/validator.js.svg?branch=master	https://travis-ci.org/validatorjs/validator.js
codecov	https://codecov.io/gh/validatorjs/validator.js/branch/master/graph/badge.svg	https://codecov.io/gh/validatorjs/validator.js
Downloads	http://img.shields.io/npm/dm/validator.svg	https://npmjs.org/package/validator
Backers on Open Collective	https://opencollective.com/validatorjs/backers/badge.svg	#backers
Sponsors on Open Collective	https://opencollective.com/validatorjs/sponsors/badge.svg	#sponsors
