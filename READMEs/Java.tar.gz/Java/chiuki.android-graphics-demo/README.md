Android Graphics Demo
---------------------

Companion app for my [Android Shaders and Filters talk][1], demonstrating:

 * `LinearGradient`
 * `BitmapShader`
 * `ColorMatrixColorFilter`
 * `LightingColorFilter`
 * `PorterDuffXfermode`
 * `EmbossMaskFilter`
 * `BlurMaskFilter`
 * `ScriptIntrinsicBlur`
 * `ScriptIntrinsicConvolve3x3`

  [1]: http://chiuki.github.io/android-shaders-filters
