# rack-pagespeed

Please refer to [the instructions manual](http://rack-pagespeed.heroku.com) for details. GitHub ain't stylish enough.

# License

It's as free as sneezing. Just [give me credit](http://twitter.com/julio_ody) if you make some extraordinary out of this.