zoom.ts	https://raw.githubusercontent.com/michaelbull/zoom.ts/master/assets/logo.png	#readme
npm version	https://img.shields.io/npm/v/zoom.ts.svg?style=flat-square	https://www.npmjs.com/package/zoom.ts
npm downloads	https://img.shields.io/npm/dt/zoom.ts.svg?style=flat-square	https://www.npmjs.com/package/zoom.ts
software license	https://img.shields.io/github/license/michaelbull/zoom.ts.svg?style=flat-square	https://github.com/michaelbull/zoom.ts/blob/master/LICENSE
build status	https://img.shields.io/travis/michaelbull/zoom.ts.svg?style=flat-square	https://travis-ci.org/michaelbull/zoom.ts
coverage status	https://img.shields.io/coveralls/michaelbull/zoom.ts.svg?style=flat-square	https://coveralls.io/github/michaelbull/zoom.ts?branch=master
example	https://github.com/michaelbull/zoom.ts/raw/master/assets/example.gif	https://michaelbull.github.io/zoom.ts
