NPM Version	https://img.shields.io/npm/v/@tweenjs/tween.js.svg	https://npmjs.org/package/@tweenjs/tween.js
CDNJS	https://img.shields.io/cdnjs/v/tween.js.svg	https://cdnjs.com/libraries/tween.js
NPM Downloads	https://img.shields.io/npm/dm/@tweenjs/tween.js.svg	https://npmjs.org/package/@tweenjs/tween.js
Build and Tests	https://github.com/tweenjs/tween.js/workflows/build%20and%20tests/badge.svg?branch=master	https://github.com/tweenjs/tween.js/actions
A-Frame VR	https://tweenjs.github.io/tween.js/assets/projects/10_aframe.png	https://aframe.io
MOMA Inventing Abstraction 1910-1925	https://tweenjs.github.io/tween.js/assets/projects/09_moma.png	http://www.moma.org/interactives/exhibitions/2012/inventingabstraction/
Web Lab	https://tweenjs.github.io/tween.js/assets/projects/08_web_lab.png	http://www.chromeweblab.com/
MACCHINA I	https://tweenjs.github.io/tween.js/assets/projects/07_macchina.png	http://5013.es/toys/macchina
Minesweeper 3D	https://tweenjs.github.io/tween.js/assets/projects/06_minesweeper3d.png	http://egraether.com/mine3d/
ROME	https://tweenjs.github.io/tween.js/assets/projects/05_rome.png	http://ro.me
WebGL Globe	https://tweenjs.github.io/tween.js/assets/projects/04_webgl_globe.png	http://data-arts.appspot.com/globe
Androidify	https://tweenjs.github.io/tween.js/assets/projects/03_androidify.png	http://www.androidify.com/
The Wilderness Downtown	https://tweenjs.github.io/tween.js/assets/projects/01_wilderness.png	http://thewildernessdowntown.com/
Linechart	https://tweenjs.github.io/tween.js/assets/projects/00_linechart.png	http://dejavis.org/linechart
