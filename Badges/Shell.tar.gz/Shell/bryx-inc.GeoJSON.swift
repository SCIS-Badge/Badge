Version	https://img.shields.io/cocoapods/v/GeoJSON.svg?style=flat	http://cocoapods.org/pods/GeoJSON
License	https://img.shields.io/cocoapods/l/GeoJSON.svg?style=flat	http://cocoapods.org/pods/GeoJSON
Platform	https://img.shields.io/cocoapods/p/GeoJSON.svg?style=flat	http://cocoapods.org/pods/GeoJSON
