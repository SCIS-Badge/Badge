Actions Status	https://github.com/sheredom/utest.h/workflows/CMake/badge.svg	https://github.com/sheredom/utest.h/actions
Build status	https://ci.appveyor.com/api/projects/status/i2u3a0pw4pxprrcv?svg=true	https://ci.appveyor.com/project/sheredom/utest-h
Sponsor	https://img.shields.io/badge/💜-sponsor-blueviolet	https://github.com/sponsors/sheredom
