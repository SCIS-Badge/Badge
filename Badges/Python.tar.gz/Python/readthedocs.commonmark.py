Pypi Link	https://img.shields.io/pypi/v/commonmark.svg	https://pypi.org/project/commonmark/
Build Status	https://travis-ci.org/rtfd/commonmark.py.svg?branch=master	https://travis-ci.org/rtfd/commonmark.py
Documentation Status	https://readthedocs.org/projects/commonmarkpy/badge/?version=latest	https://commonmarkpy.readthedocs.io/en/latest/?badge=latest
