Build Status	https://travis-ci.org/paperjs/paper.js.svg?branch=develop	https://travis-ci.org/paperjs/paper.js
NPM	https://img.shields.io/npm/v/paper.svg	https://www.npmjs.com/package/paper
Open Source Helpers	https://www.codetriage.com/paperjs/paper.js/badges/users.svg	https://www.codetriage.com/paperjs/paper.js
