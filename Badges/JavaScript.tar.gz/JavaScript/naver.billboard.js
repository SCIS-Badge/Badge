Latest Version	https://img.shields.io/npm/v/billboard.js/latest.svg	https://www.npmjs.com/package/billboard.js
Next version	https://img.shields.io/npm/v/billboard.js/next.svg	https://www.npmjs.com/package/billboard.js
semantic-release	https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg	https://github.com/semantic-release/semantic-release
Coverage Status	https://coveralls.io/repos/github/naver/billboard.js/badge.svg	https://coveralls.io/github/naver/billboard.js
Known Vulnerabilities	https://snyk.io/test/github/naver/billboard.js/badge.svg?targetFile=package.json	https://snyk.io/test/github/naver/billboard.js?targetFile=package.json
download	https://img.shields.io/npm/dm/billboard.js.svg?style=flat	https://npm-stat.com/charts.html?package=billboard.js&from=2017-06-08
jsDelivr	https://data.jsdelivr.com/v1/package/npm/billboard.js/badge?style=rounded	https://www.jsdelivr.com/package/npm/billboard.js
FOSSA Status	https://app.fossa.io/api/projects/git%2Bgithub.com%2Fnaver%2Fbillboard.js.svg?type=large	https://app.fossa.io/projects/git%2Bgithub.com%2Fnaver%2Fbillboard.js?ref=badge_large
