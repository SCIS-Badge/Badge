Build Status	https://travis-ci.org/Gottox/terminal.js.png	https://travis-ci.org/Gottox/terminal.js
