Cube.js	https://i.imgur.com/zYHXm4o.png	https://cube.dev
npm version	https://badge.fury.io/js/%40cubejs-backend%2Fserver.svg	https://badge.fury.io/js/%40cubejs-backend%2Fserver
GitHub Actions	https://github.com/cube-js/cube.js/workflows/Build/badge.svg	https://github.com/cube-js/cube.js/actions?query=workflow%3ABuild+branch%3Amaster
FOSSA Status	https://app.fossa.io/api/projects/git%2Bgithub.com%2Fcube-js%2Fcube.js.svg?type=shield	https://app.fossa.io/projects/git%2Bgithub.com%2Fcube-js%2Fcube.js?ref=badge_shield
FOSSA Status	https://app.fossa.io/api/projects/git%2Bgithub.com%2Fcube-js%2Fcube.js.svg?type=large	https://app.fossa.io/projects/git%2Bgithub.com%2Fcube-js%2Fcube.js?ref=badge_large
