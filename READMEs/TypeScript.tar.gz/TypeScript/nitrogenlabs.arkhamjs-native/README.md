# arkhamjs-native


This module is __deprecated__. It has been refactored. Now you can use the arkhamjs package with the React Native storage to provide the same great framework in one package. Please use the following packages:
* [arkhamjs](https://www.npmjs.com/package/arkhamjs)
* [@nlabs/arkhamjs-storage-native](https://www.npmjs.com/package/@nlabs/arkhamjs)

### Installation

Using [npm](https://www.npmjs.com/):
```bash
$ npm install arkhamjs @nlabs/arkhamjs-storage-native
```
or
```bash
$ yarn add arkhamjs @nlabs/arkhamjs-storage-native
```
