Build Status	https://travis-ci.org/ajacksified/Mediator.js.png	https://travis-ci.org/ajacksified/Mediator.js
