Build Status	https://travis-ci.org/raphamorim/waterfall.js.svg?branch=master	https://travis-ci.org/raphamorim/waterfall.js
NPM Version	https://img.shields.io/npm/v/express.svg?style=flat	https://www.npmjs.com/package/waterfall.js
Standard - JavaScript Style Guide	https://img.shields.io/badge/code%20style-standard-brightgreen.svg	http://standardjs.com/
