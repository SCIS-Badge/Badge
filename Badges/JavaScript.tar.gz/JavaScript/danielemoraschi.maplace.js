Build Status	https://travis-ci.org/danielemoraschi/maplace.js.svg	https://travis-ci.org/danielemoraschi/maplace.js
