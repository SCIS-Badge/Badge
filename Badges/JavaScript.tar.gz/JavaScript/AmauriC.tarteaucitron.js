npm	https://img.shields.io/npm/v/tarteaucitronjs.svg	https://www.npmjs.com/package/tarteaucitronjs
GitHub contributors	https://img.shields.io/github/contributors/AmauriC/tarteaucitron.js.svg	https://github.com/AmauriC/tarteaucitron.js/graphs/contributors
Sponsor	https://img.shields.io/static/v1?label=Sponsor&message=%E2%9D%A4&logo=GitHub	https://github.com/sponsors/AmauriC
