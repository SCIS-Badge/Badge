brewbygems
==========

Brewbygems is a RubyGems plugin that adds post-install and post-uninstall
hooks to RubyGems that update the symlinks in your Homebrew /bin/. Yay.

Requirements
------------

 * RubyGems
 * Homebrew

Install
-------

`gem install brewbygems`

License
-------

The MIT License, © 2009 Andre Arko.