GitHub Actions	https://github.com/rx-ts/vue/workflows/Node%20CI/badge.svg	https://github.com/rx-ts/vue/actions?query=workflow%3A%22Node+CI%22
Codacy Grade	https://img.shields.io/codacy/grade/16b92cd21d844d74b399de3207ae6cb9	https://www.codacy.com/gh/rx-ts/vue
GitHub release	https://img.shields.io/github/release/rx-ts/vue	https://github.com/rx-ts/vue/releases
David Dev	https://img.shields.io/david/dev/rx-ts/vue.svg	https://david-dm.org/rx-ts/vue?type=dev
Conventional Commits	https://img.shields.io/badge/conventional%20commits-1.0.0-yellow.svg	https://conventionalcommits.org
JavaScript Style Guide	https://img.shields.io/badge/code_style-standard-brightgreen.svg	https://standardjs.com
Code Style: Prettier	https://img.shields.io/badge/code_style-prettier-ff69b4.svg	https://github.com/prettier/prettier
lerna	https://img.shields.io/badge/maintained%20with-lerna-cc00ff.svg	https://lerna.js.org
codechecks.io	https://raw.githubusercontent.com/codechecks/docs/master/images/badges/badge-default.svg?sanitize=true	https://codechecks.io
npm	https://img.shields.io/npm/v/vue-qrcode.svg	https://www.npmjs.com/package/vue-qrcode
David Peer	https://img.shields.io/david/peer/rx-ts/vue.svg?path=packages/vue-qrcode	https://david-dm.org/rx-ts/vue?path=packages/vue-qrcode&type=peer
David	https://img.shields.io/david/rx-ts/vue.svg?path=packages/vue-qrcode	https://david-dm.org/rx-ts/vue?path=packages/vue-qrcode
npm	https://img.shields.io/npm/v/vue-qrious.svg	https://www.npmjs.com/package/vue-qrious
David Peer	https://img.shields.io/david/peer/rx-ts/vue.svg?path=packages/vue-qrious	https://david-dm.org/rx-ts/vue?path=packages/vue-qrious&type=peer
David	https://img.shields.io/david/rx-ts/vue.svg?path=packages/vue-qrious	https://david-dm.org/rx-ts/vue?path=packages/vue-qrious
npm	https://img.shields.io/npm/v/vue-translator.svg	https://www.npmjs.com/package/vue-translator
David Peer	https://img.shields.io/david/peer/rx-ts/vue.svg?path=packages/vue-translator	https://david-dm.org/rx-ts/vue?path=packages/vue-translator&type=peer
David	https://img.shields.io/david/rx-ts/vue.svg?path=packages/vue-translator	https://david-dm.org/rx-ts/vue?path=packages/vue-translator
