Build Status	https://secure.travis-ci.org/twitter/hogan.js.png	http://travis-ci.org/twitter/hogan.js
