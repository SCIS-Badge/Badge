image	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/jmespath/chat
image	https://travis-ci.org/jmespath/jmespath.py.svg?branch=develop	https://travis-ci.org/jmespath/jmespath.py
image	https://codecov.io/github/jmespath/jmespath.py/coverage.svg?branch=develop	https://codecov.io/github/jmespath/jmespath.py?branch=develop
