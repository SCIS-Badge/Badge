Build Status	https://travis-ci.org/marcj/topsort.php.svg	https://travis-ci.org/marcj/topsort.php
Code Climate	https://codeclimate.com/github/marcj/topsort.php/badges/gpa.svg?	https://codeclimate.com/github/marcj/topsort.php
Test Coverage	https://codeclimate.com/github/marcj/topsort.php/badges/coverage.svg?	https://codeclimate.com/github/marcj/topsort.php
