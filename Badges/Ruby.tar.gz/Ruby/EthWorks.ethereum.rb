Build Status	https://travis-ci.org/EthWorks/ethereum.rb.svg?branch=master	https://travis-ci.org/EthWorks/ethereum.rb
security	https://hakiri.io/github/NullVoxPopuli/MetaHash/master.svg	https://hakiri.io/github/NullVoxPopuli/MetaHash/master
Dependency Status	https://gemnasium.com/marekkirejczyk/ethereum.rb.svg	https://gemnasium.com/marekkirejczyk/ethereum.rb
Code Climate	https://codeclimate.com/github/marekkirejczyk/ethereum.rb/badges/gpa.svg	https://codeclimate.com/github/marekkirejczyk/ethereum.rb
