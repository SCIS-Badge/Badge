Version	https://badge.fury.io/js/atpl.svg	https://www.npmjs.org/package/atpl
Build Status	https://secure.travis-ci.org/soywiz/atpl.js.svg	http://travis-ci.org/soywiz/atpl.js
