Build Status	https://travis-ci.org/klein/klein.php.png?branch=master	https://travis-ci.org/klein/klein.php
