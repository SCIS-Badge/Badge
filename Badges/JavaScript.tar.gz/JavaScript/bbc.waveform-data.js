Build Status	https://travis-ci.org/bbc/waveform-data.js.svg?branch=master	https://travis-ci.org/bbc/waveform-data.js
