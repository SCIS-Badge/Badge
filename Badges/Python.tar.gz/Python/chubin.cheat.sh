asciicast	https://asciinema.org/a/3xvqwrsu9g4taj5w526sb2t35.png	https://asciinema.org/a/3xvqwrsu9g4taj5w526sb2t35
vscode-snippet	https://cheat.sh/files/vscode-snippet-demo.gif	https://github.com/mre/vscode-snippet
cheat.sh-sublime-plugin-demo	https://cheat.sh/files/demo-sublime.gif	https://github.com/gauravk-in/cheat.sh-sublime-plugin
idea-cheatsh-plugin	https://cheat.sh/files/idea-demo.gif	https://github.com/szymonprz/idea-cheatsh-plugin
cheatsh-qtcreator	https://user-images.githubusercontent.com/1259724/73876361-ecce5d00-4867-11ea-9f75-c5b127a9739c.gif	https://github.com/pozemka/cheatsh-qtcreator
