License	https://img.shields.io/badge/license-MIT-blue.svg	https://raw.githubusercontent.com/julmot/mark.js/master/LICENSE
jsDelivr Hits	https://data.jsdelivr.com/v1/package/npm/mark.js/badge?style=rounded	https://www.jsdelivr.com/package/npm/mark.js
