## ZapZap - Telegram Client for Android

[ZapZap](http://zapzapbr.mobi) is a messaging app, based on the source code of the Official Telegram with a focus on speed and security. It’s superfast, simple and free.

This repo contains official [ZapZap App for Android](https://play.google.com/store/apps/details?id=org.telegram.messenger.erick) source code.

### API, Protocol documentation

Documentation for Telegram API is available here: http://core.telegram.org/api

Documentation for MTproto protocol is available here: http://core.telegram.org/mtproto

### Usage

Import the root folder into your IDE (tested on Android Studio), then run project.
