Build Status	https://travis-ci.org/rdfjs/rdfxml-streaming-parser.js.svg?branch=master	https://travis-ci.org/rdfjs/rdfxml-streaming-parser.js
Coverage Status	https://coveralls.io/repos/github/rdfjs/rdfxml-streaming-parser.js/badge.svg?branch=master	https://coveralls.io/github/rdfjs/rdfxml-streaming-parser.js?branch=master
npm version	https://badge.fury.io/js/rdfxml-streaming-parser.svg	https://www.npmjs.com/package/rdfxml-streaming-parser
