Integrity — Continuous Integration server
=========================================

Code: https://github.com/integrity/integrity

Docs: http://integrity.github.io/

Bugs: https://github.com/integrity/integrity/issues

IRC: [irc://irc.freenode.net/integrity](irc://irc.freenode.net/integrity)

Mailing List: integrity@librelist.com

Archives: http://librelist.com/browser/integrity/

[![Travis build status](https://api.travis-ci.org/integrity/integrity.png)](https://travis-ci.org/integrity/integrity)

NOTE: The website, integrityapp.com has been abandoned by the original owners,
and I am unable to resolve that.
