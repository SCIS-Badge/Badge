Slack community badge	https://slack.bevry.me/badge.svg	https://slack.bevry.me
Patreon donate button	https://img.shields.io/badge/patreon-donate-yellow.svg	http://patreon.com/bevry
Gratipay donate button	https://img.shields.io/badge/gratipay-donate-yellow.svg	https://www.gratipay.com/bevry
Flattr donate button	https://img.shields.io/badge/flattr-donate-yellow.svg	https://flattr.com/profile/balupton
PayPal donate button	https://img.shields.io/badge/paypal-donate-yellow.svg	https://bevry.me/paypal
Bitcoin donate button	https://img.shields.io/badge/bitcoin-donate-yellow.svg	https://bevry.me/bitcoin
Wishlist browse button	https://img.shields.io/badge/wishlist-donate-yellow.svg	https://bevry.me/wishlist
