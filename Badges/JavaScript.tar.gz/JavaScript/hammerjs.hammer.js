NPM Version	https://img.shields.io/npm/v/hammerjs.svg	https://npmjs.org/package/hammerjs
NPM Downloads	https://img.shields.io/npm/dm/hammerjs.svg	https://npmjs.org/package/hammerjs
Build Status	https://img.shields.io/travis/stream-utils/raw-body/master.svg	https://travis-ci.org/hammerjs/hammer.js
Github Issues	https://img.shields.io/github/issues/hammerjs/hammer.js.svg	https://github.com/hammerjs/hammer.js/issues
Github PRs	https://img.shields.io/github/issues-pr/hammerjs/hammer.js.svg	https://github.com/hammerjs/hammer.js/pulls
Slack	https://hammerjs.herokuapp.com/badge.svg	https://hammerjs.herokuapp.com/
