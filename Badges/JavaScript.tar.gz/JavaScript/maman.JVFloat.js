Join the chat at https://gitter.im/maman/JVFloat.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/maman/JVFloat.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Bitdeli Badge	https://d2weczhvl823v0.cloudfront.net/maman/jvfloat.js/trend.png	https://bitdeli.com/free
