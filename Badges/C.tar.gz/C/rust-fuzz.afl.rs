afl.rs logo	etc/logo.gif	https://github.com/frewsxcv/afl.rs/issues/66
