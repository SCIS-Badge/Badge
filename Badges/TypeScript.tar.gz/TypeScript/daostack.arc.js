Build Status	https://travis-ci.com/daostack/client.svg?token=aXt9zApRNkfx8zDMypWx&branch=master	https://travis-ci.com/daostack/client
