Build Status	https://secure.travis-ci.org/mozilla-comm/ical.js.png?branch=master	http://travis-ci.org/mozilla-comm/ical.js
Coverage Status	https://coveralls.io/repos/mozilla-comm/ical.js/badge.svg	https://coveralls.io/r/mozilla-comm/ical.js
npm version	https://badge.fury.io/js/ical.js.svg	http://badge.fury.io/js/ical.js
CDNJS	https://img.shields.io/cdnjs/v/ical.js.svg	https://cdnjs.com/libraries/ical.js
Dependency Status	https://david-dm.org/mozilla-comm/ical.js.svg	https://david-dm.org/mozilla-comm/ical.js
devDependency Status	https://david-dm.org/mozilla-comm/ical.js/dev-status.svg	https://david-dm.org/mozilla-comm/ical.js?type=dev
