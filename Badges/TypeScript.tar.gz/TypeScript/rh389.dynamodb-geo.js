npm version	https://badge.fury.io/js/dynamodb-geo.svg	https://badge.fury.io/js/dynamodb-geo
CircleCI	https://circleci.com/gh/rh389/dynamodb-geo.js.svg?style=shield	https://circleci.com/gh/rh389/dynamodb-geo.js
