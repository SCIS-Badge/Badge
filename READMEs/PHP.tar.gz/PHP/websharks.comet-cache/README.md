## Comet Cache

Caching plugin for WordPress®.

Comet Cache™ Pro is a commercial plugin available at [http://cometcache.com](http://cometcache.com). The plugin is hosted here on a public Github repository in order to better faciliate community contributions from developers and users alike. If you have a suggestion, a bug report, or a patch for an issue, feel free to submit it here. We do ask, however, that if you are using the plugin on a live site that you please purchase a valid license from the [website](http://cometcache.com). We cannot provide support to anyone that does not hold a valid license key.
