Build Status	https://travis-ci.org/weixsong/elasticlunr.js.svg?branch=master	https://travis-ci.org/weixsong/elasticlunr.js
npm version	https://badge.fury.io/js/elasticlunr.svg	https://badge.fury.io/js/elasticlunr
GitHub license	https://img.shields.io/badge/license-MIT-blue.svg	https://raw.githubusercontent.com/weixsong/elasticlunr.js/master/LICENSE
Open Source Love	https://badges.frapsoft.com/os/v2/open-source.svg?v=103	https://github.com/ellerbrock/open-source-badge/
