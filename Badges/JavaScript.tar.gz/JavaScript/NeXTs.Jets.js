Jets.js on NPM	https://img.shields.io/npm/v/jets.svg	https://www.npmjs.com/package/jets
Jets.js on Bower	https://img.shields.io/bower/v/jets.svg	http://bower.io/search/?q=jets
Build Status	https://api.travis-ci.org/NeXTs/Jets.js.svg	https://travis-ci.org/NeXTs/Jets.js
Package Quality	http://npm.packagequality.com/shield/jets.svg	http://packagequality.com/#?package=jets
Join the chat at https://gitter.im/NeXTs/Jets.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/NeXTs/Jets.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
example	http://nexts.github.io/Jets.js/img/demo_hover.gif	https://jets.js.org/
