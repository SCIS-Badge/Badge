Build Status	https://travis-ci.org/firstopinion/formatter.js.png	https://travis-ci.org/firstopinion/formatter.js
