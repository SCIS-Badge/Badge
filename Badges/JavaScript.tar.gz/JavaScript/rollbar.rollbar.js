Code Quality: Javascript	https://img.shields.io/lgtm/grade/javascript/g/rollbar/rollbar.js.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/rollbar/rollbar.js/context:javascript
Total Alerts	https://img.shields.io/lgtm/alerts/g/rollbar/rollbar.js.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/rollbar/rollbar.js/alerts
