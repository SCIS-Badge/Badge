Build Status	https://travis-ci.org/openplannerteam/planner.js.svg?branch=dev	https://travis-ci.org/openplannerteam/planner.js
MIT License	https://img.shields.io/github/license/openplannerteam/planner.js.svg?maxAge=2592000	https://github.com/openplannerteam/planner.js/blob/master/LICENSE
npm version	https://badge.fury.io/js/plannerjs.svg	https://badge.fury.io/js/plannerjs
