Build Status	https://travis-ci.org/dcodeIO/bytebuffer.js.svg?branch=master	https://travis-ci.org/dcodeIO/bytebuffer.js
Donate	https://raw.githubusercontent.com/dcodeIO/bytebuffer.js/master/donate.png	https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=dcode%40dcode.io&item_name=%3C3%20bytebuffer.js
