MIT License	https://img.shields.io/badge/license-MIT-blue.svg	https://github.com/dinerojs/dinero.js/blob/master/LICENSE.md
Build Status	https://img.shields.io/travis/dinerojs/dinero.js.svg	https://travis-ci.org/dinerojs/dinero.js
NPM version	https://img.shields.io/npm/v/dinero.js.svg	https://www.npmjs.com/package/dinero.js
Coverage Status	https://img.shields.io/coveralls/github/dinerojs/dinero.js.svg?branch=master	https://coveralls.io/github/dinerojs/dinero.js?branch=master
semantic-release	https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg	https://github.com/semantic-release/semantic-release
