swieros
=======
A tiny and fast Unix-ish kernel (based on xv6), compiler, and userland for fun, education, and research.

Virtual CPU with full user/supervisor and virtual memory support, fast enough to support self-emulation.

Fast C-subset compiler allowing on-the-fly compile-and-go of all applications.

Network clients & servers, remote OpenGL, GUI applications, and many other nifty features.

Runs under Windows or Linux.

See the 00README.txt for full details and a step-by-step walkthrough tutorial.
