Build Status	https://travis-ci.org/takuyaa/kuromoji.js.svg?branch=master	https://travis-ci.org/takuyaa/kuromoji.js
Coverage Status	https://coveralls.io/repos/github/takuyaa/kuromoji.js/badge.svg?branch=master	https://coveralls.io/github/takuyaa/kuromoji.js?branch=master
npm version	https://badge.fury.io/js/kuromoji.svg	https://badge.fury.io/js/kuromoji
dependencies	https://david-dm.org/takuyaa/kuromoji.js.svg	https://david-dm.org/takuyaa/kuromoji.js
Code Climate	https://codeclimate.com/github/takuyaa/kuromoji.js/badges/gpa.svg	https://codeclimate.com/github/takuyaa/kuromoji.js
Downloads	https://img.shields.io/npm/dm/kuromoji.svg	https://www.npmjs.com/package/kuromoji
