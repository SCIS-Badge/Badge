ComVer	https://img.shields.io/badge/ComVer-compliant-brightgreen.svg	https://github.com/staltz/comver
Join the chat at https://gitter.im/motorcyclets/motorcycle	https://badges.gitter.im/motorcyclets/motorcycle.svg	https://gitter.im/motorcyclets/motorcycle?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Build Status	https://travis-ci.org/motorcyclets/motorcycle.svg?branch=master	https://travis-ci.org/motorcyclets/motorcycle
