pyDash - v1.4.6
======

Project moved to [Gitlab](https://gitlab.com/k3oni/pydash), sorry for the inconvenience! 
