#Introduction 
This project is to give customers a set of bot scenarios to build with the Azure Bot Service

#Getting Started
Install each of the Azure Bot Service scenarios

1.	Installation process

    We're going to use the latest Visual Studio 2017 release bits.

2.	Software dependencies
3.	Latest releases
4.	API references


#References
Microsoft sites with reference materials.
- [BotBuilder samples GitHub repository](https://github.com/Microsoft/AzureBotService-Samples)
- [Azure Bot Service Site](https://aka.ms/ai/bots/)
- [Azure Bot Service Doc Site](https://docs.botframework.com/en-us/)
