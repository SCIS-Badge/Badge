Build Status	https://img.shields.io/travis/stacktracejs/stacktrace.js/master.svg?style=flat-square	https://travis-ci.org/stacktracejs/stacktrace.js
Coverage Status	https://img.shields.io/coveralls/stacktracejs/stacktrace.js.svg?style=flat-square	https://coveralls.io/r/stacktracejs/stacktrace.js?branch=master
GitHub license	https://img.shields.io/github/license/stacktracejs/stacktrace.js.svg?style=flat-square	https://opensource.org/licenses/MIT
CDNJS	https://img.shields.io/cdnjs/v/stacktrace.js.svg?style=flat-square	https://cdnjs.com/libraries/stacktrace.js
size with dependencies	https://img.shields.io/badge/size-29.9k-green.svg?style=flat-square	https://github.com/stacktracejs/stacktrace.js/releases
gzip size	https://img.shields.io/badge/gzipped-9.1k-green.svg?style=flat-square	https://github.com/stacktracejs/stacktrace.js/releases
module format	https://img.shields.io/badge/module%20format-umd-lightgrey.svg?style=flat-square&colorB=ff69b4	https://github.com/stacktracejs/stacktrace.js/releases
Sauce Test Status	https://saucelabs.com/browser-matrix/stacktracejs.svg	https://saucelabs.com/u/stacktracejs
