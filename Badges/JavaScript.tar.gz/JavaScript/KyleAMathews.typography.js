Build Status	https://img.shields.io/travis/KyleAMathews/typography.js.svg	https://travis-ci.org/KyleAMathews/typography.js
Coverage Status	https://img.shields.io/codecov/c/github/KyleAMathews/typography.js.svg	https://codecov.io/github/KyleAMathews/typography.js
