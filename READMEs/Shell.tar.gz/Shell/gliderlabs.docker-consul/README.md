# Consul in Docker

Looking for what used to be `progrium/consul`? Look in the `legacy` branch.

## License

MIT

<img src="https://ga-beacon.appspot.com/UA-58928488-2/docker-consul/readme?pixel" />
