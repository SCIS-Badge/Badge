PHP version	https://badge.fury.io/ph/mistic100%2Frandomcolor.svg	http://badge.fury.io/ph/mistic100%2Frandomcolor
Demo	https://raw.githubusercontent.com/mistic100/RandomColor.php/master/demo/screenshot.jpg	http://www.strangeplanet.fr/work/RandomColor.php
