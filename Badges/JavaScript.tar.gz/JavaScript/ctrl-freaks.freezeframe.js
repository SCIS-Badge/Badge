npm version	https://badge.fury.io/js/freezeframe.svg	https://badge.fury.io/js/freezeframe
Coverage Status	https://coveralls.io/repos/github/ctrl-freaks/freezeframe.js/badge.svg?branch=master	https://coveralls.io/github/ctrl-freaks/freezeframe.js?branch=master
License: MIT	https://img.shields.io/badge/License-MIT-blue.svg	https://opensource.org/licenses/MIT
