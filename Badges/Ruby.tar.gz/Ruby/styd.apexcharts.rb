Gem Version	https://img.shields.io/gem/v/apexcharts.svg?label=apexcharts	https://rubygems.org/gems/apexcharts
Build Test Status	https://github.com/styd/apexcharts.rb/workflows/build-test/badge.svg?branch=master	https://github.com/styd/apexcharts.rb/actions
Downloads	https://img.shields.io/gem/dt/apexcharts	https://rubygems.org/gems/apexcharts
License	https://img.shields.io/badge/License-MIT-brightgreen.svg	https://github.com/styd/apexcharts.rb/blob/master/LICENSE
codebeat badge	https://codebeat.co/badges/7be581d6-e74a-406b-ae76-65605a2bff78	https://codebeat.co/projects/github-com-styd-apexcharts-rb-master
README Score	http://readme-score-api.herokuapp.com/score.svg?url=styd/apexcharts.rb	http://clayallsopp.github.io/readme-score/?url=styd/apexcharts.rb
