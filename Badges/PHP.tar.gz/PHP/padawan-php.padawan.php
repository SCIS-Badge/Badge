Join the chat at https://gitter.im/mkusher/padawan.php	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/mkusher/padawan.php?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Build Status	https://travis-ci.org/padawan-php/padawan.php.svg?branch=master	https://travis-ci.org/padawan-php/padawan.php
Total Downloads	https://poser.pugx.org/mkusher/padawan/downloads	https://packagist.org/packages/mkusher/padawan
Latest Stable Version	https://poser.pugx.org/mkusher/padawan/v/stable	https://packagist.org/packages/mkusher/padawan
Latest Unstable Version	https://poser.pugx.org/mkusher/padawan/v/unstable	https://packagist.org/packages/mkusher/padawan
Scrutinizer Code Quality	https://scrutinizer-ci.com/g/padawan-php/padawan.php/badges/quality-score.png?b=master	https://scrutinizer-ci.com/g/padawan-php/padawan.php/?branch=master
License	https://poser.pugx.org/mkusher/padawan/license	https://packagist.org/packages/mkusher/padawan
ScreenShot	http://i1.ytimg.com/vi/qpLJD24DYcU/maxresdefault.jpg	https://www.youtube.com/watch?v=qpLJD24DYcU
ScreenShot	http://i1.ytimg.com/vi/Y54P2N1T6-I/maxresdefault.jpg	https://www.youtube.com/watch?v=Y54P2N1T6-I
