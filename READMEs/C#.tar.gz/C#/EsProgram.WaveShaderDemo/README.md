# WaveShaderDemo

Unityで水の表現をして見るやつ。記事は以下から。
[Unityで波打つ水表現のサンプル](http://esprog.hatenablog.com/entry/2018/01/10/000942)

Assets -> Sample のSampleシーンで再生できます。


© UTJ/UCL
   
## 環境
 * Unity 2017.2.1f1
 * DirectX 11

## イメージ

<p align="center">
   <img src="https://github.com/EsProgram/WaveShaderDemo/blob/master/Assets/Sample/preview.gif" width="600"/>
</p>

</br>

<p align="center">
  <a href="https://www.youtube.com/watch?v=HBlMCAyFIkA">
   <img src="http://img.youtube.com/vi/HBlMCAyFIkA/0.jpg" width="600"/>
  </a>
</p>
<p align="center">
 サンプル動画(Click image).
</p>

</br>

<p align="center">
  <a href="https://www.youtube.com/watch?v=rpXeDkfSdwg">
   <img src="http://img.youtube.com/vi/rpXeDkfSdwg/0.jpg" width="600"/>
  </a>
</p>
<p align="center">
 サンプル動画(Click image).
</p>
