License	https://img.shields.io/badge/license-GPL_2-green.svg	https://github.com/cesanta/mjs/blob/master/LICENSE
