# 本项目已全部转移到DDTV2，[点击跳转到DDTV2项目页](https://github.com/CHKZL/DDTV2)  

# DDTV2.0发布！  
## 全新的界面和更稳定的功能！  

[点击跳转到2.0发布和下载网页](https://github.com/CHKZL/DDTV2)  

(https://github.com/CHKZL/DDTV2)

--

# DDTV
DD导播中心
![DD导播中心](https://github.com/CHKZL/DDTV/blob/master/src/DDTV.png)

## 为何要写这个东西
~~当然是为了方便的爱着大家啊(震声！~~  
~~我是单推(破音！！~~  
估摸着可以给DD国添砖加瓦，就想了一下需求，DUANG~就变出来了。



## 功能完成情况
* 多路直播监控，可自定义监听房间，摸鱼中\直播中一目了然
* 多窗口随意排列，大小随意
* 每路声音可单独调整
* 截图保存/手动录像/开播自动录像
* 监控列表开播提示
* 直播流选择
* 在标题滑动鼠标滚轮修改窗口音量
* 缩小到系统托盘后台监听
* 弹幕显示
* 油管直播流下载(不提供油管的直播流内置观看，请善用本地播放器
* 开播,录像气泡提示
* B站，油管多线程异步直播缓存(至多512个，达到这个数量前一般网络先会受不了)
* B站主站视频下载
* 直播弹幕记录
* 直播弹幕发送功能
  
~~暂时还没想到其他的需求，欢迎提供~~

## 关于监控列表
因为我自己平时也在用，所以会默认有一些，如果不需要，选择过后点击删除就行。  
或者把软件执行文件根目录中的RoomListConfig.json文件删除即可。  

### 在更新软件的时候请备份好RoomListConfig.json文件，该文件是监控房间配置文件
### 在更新软件的时候请备份好RoomListConfig.json文件，该文件是监控房间配置文件
### 在更新软件的时候请备份好RoomListConfig.json文件，该文件是监控房间配置文件

## 界面
主界面DD中：

![主界面](https://github.com/CHKZL/DDTV/blob/master/src/5.png)


开播提示：

![开播提示](https://github.com/CHKZL/DDTV/blob/master/src/4.png)

## 兼容性
需要.net4.7.1环境  
如果桌面缩放布局比率不是100%，打开弹幕层可能会出现弹幕显示位置和大小错位的问题。

## FA♂Q
有啥问题想到再写(

## 捐助
### 捐助表示您对我这个项目的认可，也能激励我继续开发更多好的项目

* 支付宝

![支付宝](https://github.com/CHKZL/DDTV/blob/master/src/ZFB.png)
* 微信

![微信](https://github.com/CHKZL/DDTV/blob/master/src/WX.png)
