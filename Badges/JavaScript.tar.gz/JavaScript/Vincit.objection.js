Build Status	https://travis-ci.org/Vincit/objection.js.svg?branch=master	https://travis-ci.org/Vincit/objection.js
Coverage Status	https://coveralls.io/repos/github/Vincit/objection.js/badge.svg?branch=master&service=github	https://coveralls.io/github/Vincit/objection.js?branch=master
Join the chat at https://gitter.im/Vincit/objection.js	https://badges.gitter.im/Vincit/objection.js.svg	https://gitter.im/Vincit/objection.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
