All Contributors	https://img.shields.io/badge/all_contributors-36-orange.svg?style=flat-square	#contributors-
Build Status	https://travis-ci.org/nicoespeon/gitgraph.js.svg?branch=master	https://travis-ci.org/nicoespeon/gitgraph.js
MIT License	https://img.shields.io/badge/License-MIT-yellow.svg	LICENSE.md
lerna	https://img.shields.io/badge/maintained%20with-lerna-cc00ff.svg	https://lerna.js.org/
Join the chat at https://gitter.im/gitgraphjs/community	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/gitgraphjs/community?utm_source=badge&utm_medium=badge&utm_content=badge
