Travis Build Status	https://travis-ci.org/thibault-martinez/iota.lib.cpp.svg?branch=master	https://travis-ci.org/thibault-martinez/iota.lib.cpp
Appveyor Build Status	https://ci.appveyor.com/api/projects/status/lp9awde5sykw16u0/branch/master?svg=true	https://ci.appveyor.com/project/thibault-martinez/iota-lib-cpp/branch/master
Coveralls Status	https://coveralls.io/repos/github/thibault-martinez/iota.lib.cpp/badge.svg?branch=master	https://coveralls.io/github/thibault-martinez/iota.lib.cpp?branch=master
Codacy Status	https://api.codacy.com/project/badge/Grade/a7c3070bcf4f4bc2bfff8f266208634a	https://www.codacy.com/app/thibault.martinez.30/iota.lib.cpp?utm_source=github.com&utm_medium=referral&utm_content=thibault-martinez/iota.lib.cpp&utm_campaign=Badge_Grade
CodeFactor Status	https://www.codefactor.io/repository/github/thibault-martinez/iota.lib.cpp/badge	https://www.codefactor.io/repository/github/thibault-martinez/iota.lib.cpp
Documentation	https://img.shields.io/readthedocs/pip/stable.svg	https://thibault-martinez.github.io/iota.lib.cpp/html/
IOTA API coverage	https://img.shields.io/badge/IOTA%20API%20coverage-15/15%20commands-green.svg	https://iota.readme.io/reference
MIT License	https://img.shields.io/apm/l/vim-mode.svg	https://github.com/thibault-martinez/iota.lib.cpp/blob/master/LICENSE
