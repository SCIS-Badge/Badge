Build Status	https://travis-ci.org/na2hiro/Shogi.js.svg?branch=master	https://travis-ci.org/na2hiro/Shogi.js
