### SnapShot:

<div>
    <img src='https://raw.githubusercontent.com/liaohuqiu/android-support-23.2-sample/master/art/1.gif' width="300px" style='border: #f1f1f1 solid 1px'/>
</div>

### Contains features

* Vector Drawable

* Animated Vector Drawable

* AppCompat DayNight theme

* Bottom Sheets

    Using BottomSheetDialog in day-night mode.

* RecyclerView: WRAP_CONTENT


### License

MIT


### Related links

*  https://medium.com/@chrisbanes/appcompat-v23-2-daynight-d10f90c83e94#.x3z9rzkm2

*  http://android-developers.blogspot.com/2016/02/android-support-library-232.html


### Thanks

*  http://code.tutsplus.com/articles/using-androids-vectordrawable-class--cms-23948

*  https://medium.com/@chrisbanes/appcompat-v23-2-daynight-d10f90c83e94