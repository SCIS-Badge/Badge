Latest version	https://img.shields.io/npm/v/zeromq?label=version	https://www.npmjs.com/package/zeromq
Greenkeeper monitoring	https://img.shields.io/badge/dependencies-monitored-brightgreen	https://greenkeeper.io/
