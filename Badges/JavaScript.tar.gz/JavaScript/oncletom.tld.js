Backers on Open Collective	https://opencollective.com/tldjs/backers/badge.svg	#backers
Sponsors on Open Collective	https://opencollective.com/tldjs/sponsors/badge.svg	#sponsors
Build Status	https://secure.travis-ci.org/oncletom/tld.js.svg?branch=master	http://travis-ci.org/oncletom/tld.js
