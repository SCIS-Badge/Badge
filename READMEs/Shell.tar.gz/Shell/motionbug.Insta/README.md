Insta
=================

My InstaDMG AddOns. Trying to build images on the basis of "RUNONCE". Then use my software management system for frequent changes. Reduces admin etc.

Run _BUILD.bash to automate the package builds.

NOTES : 

- Scripts use a naming convention so you can easily identify stuff.
- Folders labelled XXXPayload correlate to the XXX.sh script in the same dir.
- Scripts labelled with LaunchAgent or LaunchDaemon create these to execute at startup. (mainly to write ByHost prefs etc).

chris.gerke@gmail.com