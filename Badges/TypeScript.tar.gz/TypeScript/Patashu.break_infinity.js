NPM	https://img.shields.io/npm/v/break_infinity.js.svg	https://www.npmjs.com/package/break_infinity.js
