Build Status	https://travis-ci.org/plibither8/2048.cpp.svg?branch=master	https://travis-ci.org/plibither8/2048.cpp
Build status	https://ci.appveyor.com/api/projects/status/sljhlvcx8k11ckw7?svg=true	https://ci.appveyor.com/project/plibither8/2048-cpp
Codacy Badge	https://api.codacy.com/project/badge/Grade/b37414d66e7d4146bf72a4a467fdc84d	https://app.codacy.com/app/plibither8/2048.cpp?utm_source=github.com&utm_medium=referral&utm_content=plibither8/2048.cpp&utm_campaign=Badge_Grade_Dashboard
Language grade: C/C++	https://img.shields.io/lgtm/grade/cpp/g/plibither8/2048.cpp.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/plibither8/2048.cpp/context:cpp
Made with Love in India	https://madewithlove.org.in/badge.svg	https://madewithlove.org.in/
