CircleCI branch	https://img.shields.io/circleci/project/github/imgproxy/imgproxy.rb/master.svg?style=for-the-badge	https://circleci.com/gh/imgproxy/imgproxy.rb
Gem	https://img.shields.io/gem/v/imgproxy.svg?style=for-the-badge	https://rubygems.org/gems/imgproxy
rubydoc.org	https://img.shields.io/badge/rubydoc-reference-blue.svg?style=for-the-badge	https://www.rubydoc.info/gems/imgproxy
Sponsored by Evil Martians	https://evilmartians.com/badges/sponsored-by-evil-martians.svg	https://evilmartians.com/?utm_source=imgproxy.rb
