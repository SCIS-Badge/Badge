Build status	https://travis-ci.org/hhatto/nude.py.svg?branch=master	https://travis-ci.org/hhatto/nude.py
