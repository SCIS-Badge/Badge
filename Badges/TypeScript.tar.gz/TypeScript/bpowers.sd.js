npm	https://img.shields.io/npm/v/sd.js.svg	
David status	https://david-dm.org/sdlabs/sd.js.svg	https://david-dm.org/sdlabs/sd.js#info=dependencies&view=table
David dev status	https://david-dm.org/sdlabs/sd.js/dev-status.svg	https://david-dm.org/sdlabs/sd.js#info=devDependencies&view=table
