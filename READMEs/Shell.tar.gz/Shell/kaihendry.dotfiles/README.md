# Setup

	git init
	git remote set-url master git@github.com:kaihendry/dotfiles.git
	git pull origin master
