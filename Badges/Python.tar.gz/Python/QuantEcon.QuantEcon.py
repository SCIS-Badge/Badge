Build Status	https://github.com/QuantEcon/QuantEcon.py/workflows/build/badge.svg	https://github.com/QuantEcon/QuantEcon.py/actions?query=workflow%3Abuild
Coverage Status	https://coveralls.io/repos/QuantEcon/QuantEcon.py/badge.svg	https://coveralls.io/r/QuantEcon/QuantEcon.py
Code Quality: Python	https://img.shields.io/lgtm/grade/python/g/QuantEcon/QuantEcon.py.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/QuantEcon/QuantEcon.py/context:python
Total Alerts	https://img.shields.io/lgtm/alerts/g/QuantEcon/QuantEcon.py.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/QuantEcon/QuantEcon.py/alerts
Documentation Status	https://readthedocs.org/projects/quanteconpy/badge/?version=latest	https://quanteconpy.readthedocs.io/en/latest/?badge=latest
Join the chat at https://gitter.im/QuantEcon/QuantEcon.py	https://badges.gitter.im/QuantEcon/QuantEcon.py.svg	https://gitter.im/QuantEcon/QuantEcon.py?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
