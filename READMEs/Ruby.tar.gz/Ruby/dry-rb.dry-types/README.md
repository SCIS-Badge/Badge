[gem]: https://rubygems.org/gems/dry-types
[actions]: https://github.com/dry-rb/dry-types/actions
[codacy]: https://www.codacy.com/gh/dry-rb/dry-types
[chat]: https://dry-rb.zulipchat.com
[inchpages]: http://inch-ci.org/github/dry-rb/dry-types

# dry-types [![Join the chat at https://dry-rb.zulipchat.com](https://img.shields.io/badge/dry--rb-join%20chat-%23346b7a.svg)][chat]

[![Gem Version](https://badge.fury.io/rb/dry-types.svg)][gem]
[![CI Status](https://github.com/dry-rb/dry-types/workflows/ci/badge.svg)][actions]
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f2d71613195f4da993acb9ac9d6ea336)][codacy]
[![Codacy Badge](https://api.codacy.com/project/badge/Coverage/f2d71613195f4da993acb9ac9d6ea336)][codacy]
[![Inline docs](http://inch-ci.org/github/dry-rb/dry-types.svg?branch=master)][inchpages]

## Links

* [User documentation](http://dry-rb.org/gems/dry-types)
* [API documentation](http://rubydoc.info/gems/dry-types)

## Supported Ruby versions

This library officially supports the following Ruby versions:

* MRI >= `2.5`
* jruby >= `9.2`

## License

See `LICENSE` file.
