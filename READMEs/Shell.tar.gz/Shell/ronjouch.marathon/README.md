marathon
========

**marathon** is a minimal shell-based launcher for Linux/X that tries to be
smart about running or focusing apps. When calling `marathon application`,

* If `application` is not running, marathon will **run** it.
* Else marathon will just **focus** `application`

That way, after binding your favorite apps to a few easily-accessible OS
global keyboard shortcuts, you can access them with a single keypress and
**forget about alt-tabbing or clicking app icons in your dock / window list**.

Flags:

* `--toggle` will emulate the Quake terminal-like behavior of *minimizing*
  already-focused windows. (By default, marathon leaves them untouched.)

* `--ignore-args-on-focus` will *ignore command arguments when focusing*
   (e.g. `--incognito` in `marathon google-chrome --incognito`) while still
   passing them on initial run.
   - This is useful for applications who use a runner or spawn other processes,
     making ineffective post-exec searching for the fully-qualified command.
   - This is *not* what you want if the process you want to focus needs
     arguments to be uniquely identified (e.g. `gvim -S work`).

* `--launch-closed` will use the active *window* list to determine if the
  requested program is running. By default, marathon looks in the *process*
  list. Useful to focus well-behaved single-instance programs closed to tray
  that respond to a re-launch by activating the window (e.g. Slack).

Installation
------------

- **macOS is not supported**, sorry (due to depending on Xorg utilities).
  But rejoice, you'll be well served with Automator or Alfred, see for example
  [this guide](https://superuser.com/questions/245711/starting-application-with-custom-keyboard-shortcut)

- **Linux**:
    1. X is required, as there is (at time of writing) no equivalent
       to `wmctrl` / `xdotool` under Wayland. You'll have to
       [disable Wayland](https://wiki.archlinux.org/index.php/GDM#Use_Xorg_backend).
       Suggestions welcome in issue [#5 - Support Wayland](https://github.com/ronjouch/marathon/issues/5).
    2. **Install `wmctrl` and `xdotool`** from your package manager.
    3. Drop `marathon` somewhere in your `$PATH`.
    4. Bind `marathon command` (optionally adding flags) to a keyboard shortcut,
       courtesy of your Desktop Environment / Window Manager:
        * GNOME → Settings → Devices → Keyboard → section *Custom Shortcuts*.
          Mine look like:  
          ![GNOME Keyboard Settings screenshot](gnome-keyboard-settings-screenshot.png)
        * LXDE → your `lxde-rc.xml`

Nit: ensure the app process name (or window class if using `--launch-closed`)
     matches the executable filename. If not, a symlink will do the trick.

Support, license, contact
-------------------------

[Bug Reports](https://github.com/ronjouch/marathon/issues) and
[Pull Requests](https://github.com/ronjouch/marathon/pulls) are welcome.

Licensed under the MIT license, 2012-2018,
[Ronan Jouchet](mailto:firstname@lastname.fr) / [@ronjouch](https://twitter.com/ronjouch)
