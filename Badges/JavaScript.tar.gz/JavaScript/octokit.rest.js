@latest	https://img.shields.io/npm/v/@octokit/rest.svg	https://www.npmjs.com/package/@octokit/rest
Build Status	https://github.com/octokit/rest.js/workflows/Test/badge.svg	https://github.com/octokit/rest.js/actions?query=workflow%3ATest+branch%3Amaster
