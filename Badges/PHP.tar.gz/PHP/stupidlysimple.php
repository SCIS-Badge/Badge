Chat with Discord	https://i.imgur.com/imbJExE.jpg	https://discord.gg/EQ4w9Cs
PHP version	https://badge.fury.io/ph/stupidlysimple%2Fphp.svg	https://badge.fury.io/ph/stupidlysimple%2Fphp
Build	https://api.travis-ci.org/stupidlysimple/php.svg	https://travis-ci.org/stupidlysimple/php
Style-CI	https://styleci.io/repos/62019007/shield?branch=master	https://styleci.io/repos/62019007
Scrutinizer-CI	https://www.scrutinizer-ci.com/g/stupidlysimple/php/badges/quality-score.png?b=master	https://scrutinizer-ci.com/g/stupidlysimple/php/
Total Downloads	https://poser.pugx.org/stupidlysimple/php/downloads	https://packagist.org/packages/stupidlysimple/php
composer.lock	https://poser.pugx.org/stupidlysimple/php/composerlock	https://packagist.org/packages/stupidlysimple/php
License	https://img.shields.io/:license-mit-blue.svg	https://github.com/stupidlysimple/php/blob/master/LICENSE
Made In	https://img.shields.io/badge/made%20in-Malaysia-red.svg	https://www.google.com/search?q=malaysia
