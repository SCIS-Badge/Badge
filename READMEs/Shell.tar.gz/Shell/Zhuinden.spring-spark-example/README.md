# spring-spark-example
An example of setting up Spring-Boot with Spark.
