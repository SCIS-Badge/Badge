Build Status	https://travis-ci.org/mgechev/aspect.js.svg?branch=master	https://travis-ci.org/mgechev/aspect.js
Cutting Angular's Crosscuts	https://github.com/mgechev/aspect.js/blob/master/assets/aspectjs.png?raw=true	https://www.youtube.com/watch?v=C6e6-31HD5A
UML Diagram	https://github.com/mgechev/aspect.js/blob/master/assets/diagram.png?raw=true	https://github.com/mgechev/aspect.js/blob/master/assets/diagram.png?raw=true
