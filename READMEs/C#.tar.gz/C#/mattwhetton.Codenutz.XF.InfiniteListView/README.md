Simple Infinite ListView
=======================

This solution is a really simple extension of ListView in Xamarin.Forms to enable infinite scrolling in an MVVM project, through data binding and commanding. The solution also includes a sample of using the control in xamarin.forms for both android and ios.

For more detail see this blog entry re [Xamarin Infinite Scrolling ListView](http://www.codenutz.com/lac09-xamarin-forms-infinite-scrolling-listview/ "Xamarin Infinite Scrolling ListView")
