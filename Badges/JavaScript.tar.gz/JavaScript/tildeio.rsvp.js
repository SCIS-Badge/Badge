Build Status	https://secure.travis-ci.org/tildeio/rsvp.js.svg?branch=master	http://travis-ci.org/tildeio/rsvp.js
Inline docs	http://inch-ci.org/github/tildeio/rsvp.js.svg?branch=master	http://inch-ci.org/github/tildeio/rsvp.js
