Build Status	https://circleci.com/gh/prebid/Prebid.js.svg?style=svg	https://circleci.com/gh/prebid/Prebid.js
Percentage of issues still open	http://isitmaintained.com/badge/open/prebid/Prebid.js.svg	http://isitmaintained.com/project/prebid/Prebid.js
Average time to resolve an issue	http://isitmaintained.com/badge/resolution/prebid/Prebid.js.svg	http://isitmaintained.com/project/prebid/Prebid.js
Code Climate	https://codeclimate.com/github/prebid/Prebid.js/badges/gpa.svg	https://codeclimate.com/github/prebid/Prebid.js
Coverage Status	https://coveralls.io/repos/github/prebid/Prebid.js/badge.svg	https://coveralls.io/github/prebid/Prebid.js
devDependencies Status	https://david-dm.org/prebid/Prebid.js/dev-status.svg	https://david-dm.org/prebid/Prebid.js?type=dev
Total Alerts	https://img.shields.io/lgtm/alerts/g/prebid/Prebid.js.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/prebid/Prebid.js/alerts/
