laroux.js logo	https://eserozvataf.github.io/laroux.js/assets/images/logo-medium.png	https://eserozvataf.github.io/laroux.js/
Build Status	https://travis-ci.org/eserozvataf/laroux.js.png?branch=master	https://travis-ci.org/eserozvataf/laroux.js
Scrutinizer Quality Score	https://scrutinizer-ci.com/g/eserozvataf/laroux.js/badges/quality-score.png?s=0a36236d23cac2919f7aafff510a636d9437abec	https://scrutinizer-ci.com/g/eserozvataf/laroux.js/
Coverage Status	https://coveralls.io/repos/eserozvataf/laroux.js/badge.png?branch=master	https://coveralls.io/r/eserozvataf/laroux.js?branch=master
