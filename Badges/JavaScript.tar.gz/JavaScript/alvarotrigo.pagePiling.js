Donate	https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif	https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=BEK5JQCQMED4J&lc=GB&item_name=pagePiling%2ejs&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHosted
Browserstack	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/browserstack2.png	http://www.browserstack.com/
Facebook	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/facebook-pagepiling.gif	http://www.facebookgroups.com/
WaltDisney	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/waltDisney.gif	http://waltdisney.org/galleries
Logitech	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/logitech.gif	http://www.logitech.com/en-gb
Donate	https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif	https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=BEK5JQCQMED4J&lc=GB&item_name=pagePiling%2ejs&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHosted
