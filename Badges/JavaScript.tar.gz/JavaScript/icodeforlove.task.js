Build Status	https://img.shields.io/travis/icodeforlove/task.js.svg?branch=master	https://travis-ci.org/icodeforlove/task.js
Code Climate	https://api.codeclimate.com/v1/badges/31e1fc75ec7591e84fb4/maintainability	https://codeclimate.com/github/icodeforlove/task.js
CDNJS	https://img.shields.io/cdnjs/v/task.js.svg	https://cdnjs.com/libraries/task.js
