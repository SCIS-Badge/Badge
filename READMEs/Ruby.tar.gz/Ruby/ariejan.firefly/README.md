# Welcome to Firefly 2.0

Firefly 2.0 is an excellent URL shortener service that scales.

