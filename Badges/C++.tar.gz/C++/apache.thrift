Build Status	https://travis-ci.org/apache/thrift.svg?branch=master	https://travis-ci.org/apache/thrift/branches
Build status	https://ci.appveyor.com/api/projects/status/github/apache/thrift?branch=master&svg=true	https://ci.appveyor.com/project/ApacheSoftwareFoundation/thrift/history
Coverity Scan Build Status	https://scan.coverity.com/projects/1345/badge.svg	https://scan.coverity.com/projects/thrift
Website	https://img.shields.io/badge/official-website-brightgreen.svg	https://thrift.apache.org/
Build Status	https://travis-ci.org/apache/thrift.svg?branch=0.13.0	https://travis-ci.org/apache/thrift/branches
Build Status	https://travis-ci.org/apache/thrift.svg?branch=0.12.0	https://travis-ci.org/apache/thrift/branches
