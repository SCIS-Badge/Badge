# VuePack [![Build Status](https://circleci.com/gh/znck/vuepack/tree/master.svg?style=shield)](https://circleci.com/gh/znck/vuepack/) [![Coverage Status](https://coveralls.io/repos/github/znck/vuepack/badge.svg)](https://coveralls.io/github/znck/vuepack)

> EXPERIMENTAL: DO NOT USE IN PRODUCTION.

A tool to normalize `.vue` components so they can be published in NPM packages as it is.

## Usage

``` bash
npm install -g vuepack

vuec -h
```
