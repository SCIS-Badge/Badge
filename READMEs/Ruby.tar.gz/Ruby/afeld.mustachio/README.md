[![Build Status](https://travis-ci.org/afeld/mustachio.png?branch=master)](https://travis-ci.org/afeld/mustachio)

![the queen](https://mustachify.me/?src=http://www.librarising.com/astrology/celebs/images2/QR/queenelizabethii.jpg)

https://mustachify.me/?src=YOUR-IMAGE-URL
