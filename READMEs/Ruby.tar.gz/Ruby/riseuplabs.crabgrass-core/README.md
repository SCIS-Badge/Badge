![crabgrass](public/images/crabgrass.png)

Crabgrass is a web application designed for activist groups to be better able to collaborate online. Mostly, it is a glorified wiki with fine-grain control over access rights.

Crabgrass is based on Ruby on Rails and MySQL. It is released under the AGPL license, version 3.

For installation notes, see [doc/INSTALL.md](doc/INSTALL.md).
