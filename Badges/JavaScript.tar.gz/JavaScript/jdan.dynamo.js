build status	https://travis-ci.org/jdan/dynamo.js.png	https://travis-ci.org/jdan/dynamo.js
