build	https://img.shields.io/travis/concretesolutions/pareto.js/master.svg	https://travis-ci.org/concretesolutions/pareto.js
downloads	https://img.shields.io/npm/dm/paretojs.svg	https://www.npmjs.com/package/paretojs
npm	https://img.shields.io/npm/v/paretojs.svg	https://www.npmjs.com/package/paretojs
