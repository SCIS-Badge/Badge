Open-DoVision
=============

Open Source Virtual Reality for Everyone

**master** - The default projects written for Open DoVision

***

###General Descriptions:

**usb-mouse** - Make the Open DoVision a flying mouse

**usb-hid** - Make the Open DoVision a hid that send and receive data from the PC

The **usb-mouse** project is designed to give you a brief overview of the Open DoVision. And let you enjoy games that are not designed to be 3D rendering ready.

The **usb-hid** includes a little PC applet to show you how to communicate with the Open DoVision

The libraries that are not developed by DotLab are provided under their own licence
