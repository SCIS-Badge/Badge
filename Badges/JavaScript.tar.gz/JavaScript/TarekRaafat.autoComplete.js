License	https://img.shields.io/badge/License-Apache%202.0-blue.svg	https://opensource.org/licenses/Apache-2.0
Open Source Love	https://badges.frapsoft.com/os/v1/open-source.svg?v=103	https://github.com/TarekRaafat/autoComplete.js
autoComplete.js Code Example	./docs/img/autoComplete.init.png	https://codepen.io/tarekraafat/pen/rQopdW?editors=0010
jsDelivr	https://www.jsdelivr.com/img/logo@2x.png	https://www.jsdelivr.com/package/gh/TarekRaafat/autoComplete.js
