Build Status	https://travis-ci.org/baconjs/bacon.js.svg?branch=master	https://travis-ci.org/baconjs/bacon.js
NPM version	http://img.shields.io/npm/v/baconjs.svg	https://www.npmjs.org/package/baconjs
Dependency Status	https://david-dm.org/baconjs/bacon.js.svg	https://david-dm.org/baconjs/bacon.js
devDependency Status	https://david-dm.org/baconjs/bacon.js/dev-status.svg	https://david-dm.org/baconjs/bacon.js#info=devDependencies
