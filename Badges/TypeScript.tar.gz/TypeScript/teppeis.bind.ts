npm version	https://img.shields.io/npm/v/bind.ts.svg	https://npmjs.org/package/bind.ts
build status	https://circleci.com/gh/teppeis/bind.ts.svg?style=shield	https://circleci.com/gh/teppeis/bind.ts
dependency status	https://img.shields.io/david/teppeis/bind.ts.svg	https://david-dm.org/teppeis/bind.ts
