Documentation Status	https://readthedocs.org/projects/web3py/badge/?version=latest	https://web3py.readthedocs.io/en/latest/?badge=latest
Join the chat at https://gitter.im/ethereum/web3.py	https://badges.gitter.im/ethereum/web3.py.svg	https://gitter.im/ethereum/web3.py?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
Build Status	https://circleci.com/gh/ethereum/web3.py.svg?style=shield	https://circleci.com/gh/ethereum/web3.py
