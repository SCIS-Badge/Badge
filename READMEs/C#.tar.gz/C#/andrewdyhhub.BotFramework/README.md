
# Microsoft Bot Framework & LUIS 资料汇总 #

MSDN 开发视频: https://channel9.msdn.com/Series/For-China-Developers/Conversation20161017A01

Microsoft AI MOOC: https://mva.microsoft.com/colleges/MicrosoftAI 

Bot SDK：https://github.com/Microsoft/BotBuilder.git 

示例代码：
https://github.com/leonlj/BotDemo 

与微信连接:
http://www.cnblogs.com/sonic1abc/p/5941442.html

PowerBI Embedded & Bot Card Mode:
http://www.cnblogs.com/sonic1abc/p/6602530.html 

开发者入口：
https://dev.botframework.com/   

BOT FRAMEWROK技术白皮书:
http://www.cnblogs.com/MS-Yuheng/p/6088897.html

LUIS Entities 分类:
http://www.cnblogs.com/MS-Yuheng/p/6856523.html

HOL动手实验（英文版）:
https://docs.botframework.com/en-us/csharp/builder/sdkreference/gettingstarted.html 

详细的开发文档和介绍：
http://docs.botframework.com/ 

除了图片增加一些更多的交互:
http://blog.botframework.com/2016/05/13/BotFramework.buttons/ 

BUILD 上的Bots的介绍课程：
https://channel9.msdn.com/Events/Build/2016/B821 

LUIS的介绍(提高更好的自然语言交互):
https://www.azure.cn/cognitive-services/zh-cn/language-understanding-intelligent-service-luis 

语言分析：
https://www.azure.cn/cognitive-services/zh-cn/linguistic-analysis-api 


## 民警提示: 别忘了点上面的星星 ★star ##
