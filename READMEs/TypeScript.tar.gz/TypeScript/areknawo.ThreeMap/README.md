
# ThreeMap Dev 0.0.1 :earth_americas::earth_africa::earth_asia:

!> It's highly **Work In Progress** - there is still a lot to be done.
*Do not use it in production!*
If you're willing to help :heartpulse: - checkout **Contribiution guide**.

Library for high-quality :high_brightness: fully-customizable vector maps
built with THREE.JS for creating stunning :sunglasses: visualizations with ease.

## Installation

Just run: <br/>
`npm install three-map` <br/>
Or use cdn from [rawgit](https://rawgit.com/areknawo/ThreeMap/master/build/ThreeMap.min.js)

## Example

[ThreeMap](https://cdn.rawgit.com/areknawo/ThreeMap/a76571ba/example/index.html)
