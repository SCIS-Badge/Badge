**Notice: SAELayerCDN is no longer maintained**

## Layer

forked from [SaeLayerCDN](https://github.com/Slacken/cdn).

将SaeLayerCDN移植到全平台，所以是“Layer”而不再是“SaeLayer”。

目前支持平台：SAE（新浪）、BAE（百度）、GCS（盛大）、标准PHP（本地读写）
