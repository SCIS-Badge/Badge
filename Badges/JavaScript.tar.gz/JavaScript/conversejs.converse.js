Converse.js	https://github.com/conversejs/converse.js/blob/master/logo/readme.png	https://conversejs.org
XMPP Chat	https://inverse.chat/badge.svg?room=discuss@conference.conversejs.org	https://inverse.chat/#converse/room?jid=discuss@conference.conversejs.org
Travis	https://api.travis-ci.org/conversejs/converse.js.png?branch=master	https://travis-ci.org/conversejs/converse.js
Bountysource bounties	https://img.shields.io/bountysource/team/converse.js/activity.svg?maxAge=2592000	https://www.bountysource.com/teams/converse.js/issues?tracker_ids=194169
Translation status	https://hosted.weblate.org/widgets/conversejs/-/svg-badge.svg	https://hosted.weblate.org/engage/conversejs/?utm_source=widget
