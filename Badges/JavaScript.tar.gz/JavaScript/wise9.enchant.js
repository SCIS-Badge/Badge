Build Status	https://secure.travis-ci.org/wise9/enchant.js.png	https://travis-ci.org/wise9/enchant.js
Built with Grunt	https://cdn.gruntjs.com/builtwith.png	http://gruntjs.com/
