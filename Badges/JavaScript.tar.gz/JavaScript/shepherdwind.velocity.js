NPM version	http://img.shields.io/npm/v/velocityjs.svg?style=flat-square	http://npmjs.org/package/velocityjs
build status	https://img.shields.io/travis/shepherdwind/velocity.js/master.svg?style=flat-square	https://travis-ci.org/shepherdwind/velocity.js
Test coverage	https://img.shields.io/coveralls/shepherdwind/velocity.js.svg?style=flat-square	https://coveralls.io/r/shepherdwind/velocity.js?branch=master
npm download	https://img.shields.io/npm/dm/velocityjs.svg?style=flat-square	https://npmjs.org/package/velocityjs
