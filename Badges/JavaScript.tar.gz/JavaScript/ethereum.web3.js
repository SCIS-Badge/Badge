Gitter	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/ethereum/web3.js
StackExchange	https://img.shields.io/badge/web3js-stackexchange-brightgreen	https://ethereum.stackexchange.com/questions/tagged/web3js
NPM Package Version	https://img.shields.io/npm/v/web3.svg	https://npmjs.org/package/web3
NPM Package Downloads	https://img.shields.io/npm/dm/web3.svg	https://npmjs.org/package/web3
Build Status	https://github.com/ethereum/web3.js/workflows/Build/badge.svg	https://github.com/ethereum/web3.js/actions
Dev Dependency Status	https://david-dm.org/ethereum/web3.js/1.x/dev-status.svg	https://david-dm.org/ethereum/web3.js/1.x?type=dev
Coverage Status	https://coveralls.io/repos/ethereum/web3.js/badge.svg?branch=1.x	https://coveralls.io/r/ethereum/web3.js?branch=1.x
Lerna	https://img.shields.io/badge/maintained%20with-lerna-cc00ff.svg	https://lerna.js.org/
Netlify Status	https://api.netlify.com/api/v1/badges/1fc64933-d170-4939-8bdb-508ecd205519/deploy-status	https://app.netlify.com/sites/web3-staging/deploys
