Build Status	https://secure.travis-ci.org/ooxi/xml.c.png	http://travis-ci.org/ooxi/xml.c
