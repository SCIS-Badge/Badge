Check out my [BRUH3 Repo](https://github.com/bruhautomation/BRUH3-Home-Assistant-Configuration) for my up-to-date Home Assistant configuration. 

Home automation demo video - https://www.youtube.com/watch?v=o_INXFjkKtQ

For more information, check out my webpage http://www.bruhautomation.com and/or the Home Assistant website https://www.home-assistant.io

# Home-Assistant-Configuration
![ScreenShot](Home Assistant Config.gif)
