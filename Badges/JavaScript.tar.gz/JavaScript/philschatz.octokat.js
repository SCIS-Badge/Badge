gh-board	https://img.shields.io/github/issues/philschatz/octokat.js.svg?label=kanban%20board%20%28gh-board%29	http://philschatz.com/gh-board/#/r/philschatz:octokat.js
NPM version	https://img.shields.io/npm/v/octokat.svg	https://npmjs.org/package/octokat
Downloads	http://img.shields.io/npm/dm/octokat.svg	https://npmjs.org/package/octokat
build status	https://img.shields.io/travis/philschatz/octokat.js.svg	https://travis-ci.org/philschatz/octokat.js
dependency status	https://img.shields.io/david/philschatz/octokat.js.svg	https://david-dm.org/philschatz/octokat.js
dev dependency status	https://img.shields.io/david/dev/philschatz/octokat.js.svg	https://david-dm.org/philschatz/octokat.js#info=devDependencies
code coverage	https://img.shields.io/codecov/c/github/philschatz/octokat.js.svg	https://codecov.io/gh/philschatz/octokat.js
