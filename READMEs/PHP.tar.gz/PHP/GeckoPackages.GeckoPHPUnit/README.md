Abandoned!

We will try to move anything of value from here to PHPUnit 7 if possible.
