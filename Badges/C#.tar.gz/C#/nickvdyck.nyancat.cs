Build status	https://github.com/nickvdyck/nyancat.cs/workflows/CI/badge.svg	https://github.com/nickvdyck/nyancat.cs
NuGet	https://img.shields.io/nuget/v/nyancat.svg?style=flat-square&label=nuget	https://www.nuget.org/packages/nyancat/
feedz.io	https://img.shields.io/badge/endpoint.svg?url=https%3A%2F%2Ff.feedz.io%2Fnvd%2Fnyancat-cs%2Fshield%2Fnyancat%2Flatest&label=nyancat	https://f.feedz.io/nvd/nyancat-cs/packages/nyancat/latest/download
