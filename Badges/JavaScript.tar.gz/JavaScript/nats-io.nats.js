license	https://img.shields.io/github/license/nats-io/node-nats.svg	https://www.apache.org/licenses/LICENSE-2.0
npm	https://img.shields.io/npm/v/nats.svg	https://www.npmjs.com/package/nats
npm	https://img.shields.io/npm/dt/nats.svg	https://www.npmjs.com/package/nats
npm	https://img.shields.io/npm/dm/nats.svg	https://www.npmjs.com/package/nats
JavaScript Style Guide	https://img.shields.io/badge/code_style-standard-brightgreen.svg	https://standardjs.com
