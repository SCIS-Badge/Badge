Profile 1 Screenshot	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-profile1_small.png	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-profile1.png
Profile 2 Screenshot	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-profile2_small.png	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-profile2.png
Control Flow Graph	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-cfg_small.png	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-cfg.png
Screenshot	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-sample_small.png	https://raw.github.com/wiki/jrfonseca/xdot.py/xdot-sample.png
