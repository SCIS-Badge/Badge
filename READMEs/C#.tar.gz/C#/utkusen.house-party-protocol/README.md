# house-party-protocol
an ultimate evidence wiper
