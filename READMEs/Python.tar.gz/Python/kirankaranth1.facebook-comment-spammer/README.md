Facebook Comment Spammer
========================
Note: This DOES NOT work anymore as facebook graph API does not support commenting on public pages anymore.
To use:  
1. Get a Facebook Graph API access token at: https://developers.facebook.com/tools/explorer  
2. Open terminal and run python.  
3. Make sure "fb" and "facepy" libraries are installed (see comments for instructions).  
4. Run program.  
  
