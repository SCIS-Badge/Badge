Build Status	https://travis-ci.org/fitzgen/wu.js.png?branch=master	https://travis-ci.org/fitzgen/wu.js
NPM	https://nodei.co/npm/wu.png	https://www.npmjs.com/package/wu
