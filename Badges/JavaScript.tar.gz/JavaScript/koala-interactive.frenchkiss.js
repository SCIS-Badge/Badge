Build Status	https://travis-ci.com/koala-interactive/frenchkiss.js.svg?branch=master	https://travis-ci.com/koala-interactive/frenchkiss.js
File size	https://img.shields.io/badge/GZIP%20size-1.1%20kB-brightgreen.svg	./dist/umd/frenchkiss.js
License: MIT	https://img.shields.io/badge/License-MIT-brightgreen.svg	https://opensource.org/licenses/MIT
