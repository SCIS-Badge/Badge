Build Status	https://travis-ci.org/computablelabs/computable.js.svg?branch=master	https://travis-ci.org/computablelabs/computable.js
