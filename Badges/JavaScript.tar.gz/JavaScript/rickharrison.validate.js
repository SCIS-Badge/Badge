ghit.me	https://ghit.me/badge.svg?repo=rickharrison/validate.js	https://ghit.me/repo/rickharrison/validate.js
