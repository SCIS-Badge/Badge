Build Status	https://travis-ci.com/axa-group/nlp.js.svg?branch=master	https://travis-ci.com/axa-group/nlp.js
Coverage Status	https://coveralls.io/repos/github/axa-group/nlp.js/badge.svg?branch=master	https://coveralls.io/github/axa-group/nlp.js?branch=master
NPM version	https://img.shields.io/npm/v/node-nlp.svg?style=flat	https://www.npmjs.com/package/node-nlp
NPM downloads	https://img.shields.io/npm/dm/node-nlp.svg?style=flat	https://www.npmjs.com/package/node-nlp
Sonarcloud Status	https://sonarcloud.io/api/project_badges/measure?project=axa-group_nlp.js&metric=alert_status	https://sonarcloud.io/dashboard?id=axa-group_nlp.js
Maintainability Rating	https://sonarcloud.io/api/project_badges/measure?project=axa-group_nlp.js&metric=sqale_rating	https://sonarcloud.io/dashboard?id=axa-group_nlp.js
Reliability Rating	https://sonarcloud.io/api/project_badges/measure?project=axa-group_nlp.js&metric=reliability_rating	https://sonarcloud.io/dashboard?id=axa-group_nlp.js
Security Rating	https://sonarcloud.io/api/project_badges/measure?project=axa-group_nlp.js&metric=security_rating	https://sonarcloud.io/dashboard?id=axa-group_nlp.js
Contributors	https://contributors-img.firebaseapp.com/image?repo=axa-group/nlp.js	https://github.com/axa-group/nlp.js/graphs/contributors
