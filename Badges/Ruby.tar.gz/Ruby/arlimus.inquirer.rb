Build Status	https://travis-ci.org/arlimus/inquirer.rb.png	https://travis-ci.org/arlimus/inquirer.rb
