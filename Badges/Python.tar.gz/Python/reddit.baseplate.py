Build Status	https://cloud.drone.io/api/badges/reddit/baseplate.py/status.svg	https://cloud.drone.io/reddit/baseplate.py
