# Documentation

Get started with Scuttlebot and the Secure Scuttlebutt protocol.

## Links

- Scuttlebot implemented by [`ssb-server`](http://ssbc.github.io/ssb-server/): a p2p log store
- Secure Scuttlebutt implemented by [`ssb-db`](http://ssbc.github.io/ssb-db/): a global database protocol
- [Patchwork](http://ssbc.github.io/patchwork/): a social messaging app built on `ssb-server` and `ssb-db`