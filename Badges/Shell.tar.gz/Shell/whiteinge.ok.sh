Build Status	https://travis-ci.org/whiteinge/ok.sh.svg?branch=master	https://travis-ci.org/whiteinge/ok.sh
