MAIN DOWNLOAD: http://dl.dropbox.com/u/2944265/mods/BON.jar

You must install Forge (if necessary) and recompile before using BON to deobfuscate a mod.

Simple GUI version: Compile into a jar file, or download from the link above, then run it.

Command line version (for experts only):
	Run: java -cp BON.jar immibis.bon.cui.MCPRemap
	for a detailed list of command-line arguments.

Now automatically deletes META-INF, you don't need to do that yourself.
