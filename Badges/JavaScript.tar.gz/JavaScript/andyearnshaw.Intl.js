Build Status	https://travis-ci.org/andyearnshaw/Intl.js.svg?branch=master	https://travis-ci.org/andyearnshaw/Intl.js
