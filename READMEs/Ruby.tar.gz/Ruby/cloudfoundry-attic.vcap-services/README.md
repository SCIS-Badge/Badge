This repository has been deprecated.
=============

The NG MySQL and NG PostgresSQL services now are a part of the cf-services-release repo (https://github.com/cloudfoundry/cf-services-release).

The other services (which the Cloud Foundry team is not actively supporting) are in the cf-services-contrib-release repo (https://github.com/cloudfoundry/cf-services-contrib-release)
