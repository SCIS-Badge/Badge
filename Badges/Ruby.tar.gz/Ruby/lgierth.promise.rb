Build Status	https://travis-ci.org/lgierth/promise.rb.png?branch=master	https://travis-ci.org/lgierth/promise.rb
Code Climate	https://codeclimate.com/github/lgierth/promise.rb.png	https://codeclimate.com/github/lgierth/promise.rb
Coverage Status	https://coveralls.io/repos/lgierth/promise.rb/badge.png?branch=master	https://coveralls.io/r/lgierth/promise.rb?branch=master
