////////////////////////////////////////////////////////////////////////////////
//     __ _                        _                                          //
//    / _| |                      | |                                         //
//   | |_| |__   ___ _ __ ___   __| |                                         //
//   |  _| '_ \ / __| '_ ` _ \ / _` |                                         //
//   | | | |_) | (__| | | | | | (_| |                                         //
//   |_| |_.__/ \___|_| |_| |_|\__,_|                                         //
//                                                                            //
//   Facebook Command Line Interface Utility                                  //
//                                                                            //
//   [Project Home Page & wiki]  http://fbcmd.dtompkins.com                   //
//   [Facebook Page]             http://facebook.com/fbcmd                    //
//   [Discussion Group]          http://groups.google.com/group/fbcmd         //
//   [Open Source Repository]    http://github.com/dtompkins/fbcmd            //
//                                                                            //
//   Copyright (c) 2007,2010 Dave Tompkins                                    //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//   See http://fbcmd.dtompkins.com/history/ for a revision history.          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

See the Project Home Page & wiki for more information:

[Installation]  http://fbcmd.dtompkins.com/installation
[Syntax]        http://fbcmd.dtompkins.com/syntax
[Commands]      http://fbcmd.dtompkins.com/commands
[Help]          http://fbcmd.dtompkins.com/help

For ways of keeping your version up-to-date:

[Update]        http://fbcmd.dtompkins.com/update

To get involved in the project, or get some help:

[Contribute]    http://fbcmd.dtompkins.com/contribute
