NPM Version	https://img.shields.io/npm/v/rdflib.svg?style=flat	https://npm.im/rdflib
Join the chat at https://gitter.im/linkeddata/rdflib.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/linkeddata/rdflib.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
