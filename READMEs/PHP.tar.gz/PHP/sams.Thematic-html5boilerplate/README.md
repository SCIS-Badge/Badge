﻿Thematic Html5Boilerplate
=========================

* update the position of sidebars and sort out stuff
* compressed styles and script are placed in the wrong places by either w3 tool or wp-minify plugins
* some changes need documenting other need testing (others still need both)
* default theme needs reworking

A wordpress theme using html5 and based on Thematic ToolBox (and other Thematic themes).

 * Header branding image from TwentyTen
 * Widget locations from Twentyten
 * Background control from Twentyten
 * Layout control from Thematic Options
 * Logo control from Thematic Options 
 * Uses Object Orientated CSS   (todo)
 * Built in support for popular wordpress plugins (todo)
   * minify 
   * super cache
   * Cleaner Gallery (todo)
   * contact 7 form
   * white label cms
   * Yoast Plugins (todo)
   * wp fancybox (todo)
   * wp swfobject
 * Thematic Child Themes (todo)

# Plugins

## Minify

Install minify plugin for wp; Customise the sheets as befits; add files for required plugins
A switch will exist to have minify not min css or js

list the css files for minify to zap (dkf or add)
	library/css/h5bp.css
	library/css//core/grid/grids.css
	library/css/core/template/template.css
	library/css/core/module/mod.css
	library/css/screen.css
	library/ccs/all.css
	library/css/media.css
	
list the files for js as


## Super Cache

## Contact Form 7

## Cleaner Gallery

The original source is available at 
http://github.com/paulirish/html5-boilerplate
and more information is available at
http://html5boilerplate.com/

for more on OOCSS see
http://github.com/stubbornella/oocss

other plans in mind also

extra support for custom types

built in support for funky jquery plugins later

http://github.com/pengwynn/compass-wordpress ?




## Contributions & Thanks

Mo0X & John Raz
