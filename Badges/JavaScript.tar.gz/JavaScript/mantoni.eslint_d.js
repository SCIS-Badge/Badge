SemVer	https://img.shields.io/:semver-%E2%9C%93-brightgreen.svg	http://semver.org
License	https://img.shields.io/npm/l/eslint_d.svg	https://github.com/mantoni/eslint_d.js/blob/master/LICENSE
