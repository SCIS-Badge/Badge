Packagist	https://img.shields.io/packagist/v/vimeo/vimeo-api.svg?style=flat-square	https://packagist.org/packages/vimeo/vimeo-api
License	https://img.shields.io/packagist/l/vimeo/vimeo-api.svg?style=flat-square	https://packagist.org/packages/vimeo/vimeo-api
Travis CI	https://img.shields.io/travis/vimeo/vimeo.php.svg?style=flat-square	https://travis-ci.org/vimeo/vimeo.php
StyleCI	https://styleci.io/repos/9654006/shield?style=flat-square	https://styleci.io/repos/9654006/
