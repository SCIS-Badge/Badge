image	https://drone.io/github.com/jeanphix/Ghost.py/status.png	https://drone.io/github.com/jeanphix/Ghost.py/latest
