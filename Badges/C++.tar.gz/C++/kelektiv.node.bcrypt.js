Build Status	https://travis-ci.org/kelektiv/node.bcrypt.js.svg?branch=master	https://travis-ci.org/kelektiv/node.bcrypt.js
Dependency Status	https://david-dm.org/kelektiv/node.bcrypt.js.svg	https://david-dm.org/kelektiv/node.bcrypt.js
