UniversalAdbDriver
==================

A single Windows driver that supports the ADB (and fastboot) interface for most Android phones.


[Download Windows Installer](https://adb.clockworkmod.com/)
