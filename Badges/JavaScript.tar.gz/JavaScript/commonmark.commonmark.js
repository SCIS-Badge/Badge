Build Status	https://github.com/commonmark/commonmark.js/workflows/CI%20tests/badge.svg	https://github.com/commonmark/commonmark.js/actions
NPM version	https://img.shields.io/npm/v/commonmark.svg?style=flat	https://www.npmjs.org/package/commonmark
