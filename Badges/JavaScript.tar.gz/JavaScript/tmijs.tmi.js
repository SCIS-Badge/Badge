Npm Version	https://img.shields.io/npm/v/tmi.js.svg?style=flat	https://www.npmjs.org/package/tmi.js
Downloads	https://img.shields.io/npm/dm/tmi.js.svg?style=flat	https://www.npmjs.org/package/tmi.js
Issues	https://img.shields.io/github/issues/tmijs/tmi.js.svg?style=flat	https://github.com/tmijs/tmi.js/issues
Node Version	https://img.shields.io/node/v/tmi.js.svg?style=flat	https://www.npmjs.org/package/tmi.js
