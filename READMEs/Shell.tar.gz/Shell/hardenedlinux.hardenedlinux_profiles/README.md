# hardenedlinux_profiles
It contains hardenedlinux community documentation.
