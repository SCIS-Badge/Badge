Medium.js	http://i.imgur.com/U6t8Eq2.png	http://jakiestfu.github.io/Medium.js
Stories in Ready	https://badge.waffle.io/jakiestfu/medium.js.png?label=ready&title=Ready	https://waffle.io/jakiestfu/medium.js
