build status	https://travis-ci.org/algolia/algoliasearch-client-node.svg?branch=master	http://travis-ci.org/algolia/autocomplete.js
NPM version	https://badge.fury.io/js/autocomplete.js.svg	http://badge.fury.io/js/autocomplete.js
Coverage Status	https://coveralls.io/repos/algolia/autocomplete.js/badge.svg?branch=master	https://coveralls.io/r/algolia/autocomplete.js?branch=master
jsDelivr Hits	https://data.jsdelivr.com/v1/package/npm/autocomplete.js/badge?style=rounded	https://www.jsdelivr.com/package/npm/autocomplete.js
License: MIT	https://img.shields.io/badge/License-MIT-yellow.svg	https://opensource.org/licenses/MIT
Browser tests	https://saucelabs.com/browser-matrix/opensauce-algolia.svg	https://saucelabs.com/u/opensauce-algolia
