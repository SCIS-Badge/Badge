# Summary

This is a test project for a component [MASPreferences](https://github.com/shpakovski/MASPreferences).

# How to run

`git clone https://github.com/shpakovski/MASPreferencesDemo.git && open MASPreferencesDemo/Demo.xcworkspace`

Hit `Command-R` to build and run the project in Xcode.

# How to update

`cd MASPreferencesDemo && pod update`
