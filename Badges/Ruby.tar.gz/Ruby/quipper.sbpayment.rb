Circle CI	https://img.shields.io/circleci/project/quipper/sbpayment.rb.svg	https://circleci.com/gh/quipper/sbpayment.rb
Rubygems	https://img.shields.io/gem/v/sbpayment.svg	https://rubygems.org/gems/sbpayment
