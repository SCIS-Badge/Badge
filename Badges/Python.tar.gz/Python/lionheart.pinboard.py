CI Status	https://circleci.com/gh/lionheart/pinboard.py.svg?style=svg&circle-token=d50700e1c75836063a7951f80ab1913cf6447acf	https://circleci.com/gh/lionheart/pinboard.py
Version	http://img.shields.io/pypi/v/pinboard.svg?style=flat	https://pypi.python.org/pypi/pinboard
Versions	https://img.shields.io/pypi/pyversions/pinboard.svg?style=flat	https://pypi.python.org/pypi/pinboard
License	http://img.shields.io/pypi/l/pinboard.py.svg?style=flat	LICENSE
