npm	https://img.shields.io/npm/v/@vimeo/player.svg?cacheSeconds=120	https://www.npmjs.com/package/@vimeo/player
Coverage	https://img.shields.io/codecov/c/github/vimeo/player.js.svg?cacheSeconds=120	https://codecov.io/gh/vimeo/player.js
