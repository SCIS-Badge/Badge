Build	https://travis-ci.org/TinkoffCreditSystems/utils.js.svg?branch=master	https://travis-ci.org/TinkoffCreditSystems/utils.js
Coverage Status	https://coveralls.io/repos/github/TinkoffCreditSystems/utils.js/badge.svg?branch=master&t=CdowK8	https://coveralls.io/github/TinkoffCreditSystems/utils.js?branch=master
