Codacy Badge	https://api.codacy.com/project/badge/Grade/62336d873da240ac89188efdb9f50d8b	https://app.codacy.com/app/AlexanderWillner/things.sh?utm_source=github.com&utm_medium=referral&utm_content=AlexanderWillner/things.sh&utm_campaign=Badge_Grade_Dashboard
Build Status	https://travis-ci.org/AlexanderWillner/things.sh.svg?branch=master	https://travis-ci.org/AlexanderWillner/things.sh
download	https://img.shields.io/github/downloads/AlexanderWillner/things.sh/total	https://github.com/AlexanderWillner/things.sh/releases
Things.sh Scheduler	https://j.gifs.com/VPrxp9.gif	https://youtu.be/npOYItkLuhU
Things3 URL Helper	https://j.gifs.com/59VllB.gif	https://youtu.be/6niSmdXanug
Demo Markdown Clipbaord to Things3	https://j.gifs.com/gL8kx9.gif	https://youtu.be/HTaxOkZb9S4
