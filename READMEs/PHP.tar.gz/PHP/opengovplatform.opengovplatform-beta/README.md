Open Government Platform - Beta
====================

Release notes
----------

- Fix of OGPL-Alpha bugs
- Added Community Support
- Data Conversion API
- Enhanced Role Management
- Improved Matrices
- Multiple customized theme support
- Improved User Dashboard
- Added Endorsement option for Received Suggestions/Ideas
- Improved catalog page
- Data Visualization Tool


Data Portal India (http://data.gov.in) is powered by OGPL-Beta Codebase
