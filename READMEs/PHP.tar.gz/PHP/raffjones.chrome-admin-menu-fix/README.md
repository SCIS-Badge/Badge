# chrome-admin-menu-fix
Chrome 45 is mangling WordPress admin menus. This is a quick fix which adds a line of CSS to fix the problem.

If you just want to install the plugin in the normal "upload a ZIP" way, then click the "Download ZIP" button and upload it to your WordPress site.