Build Status	https://github.com/axetroy/vm.js/workflows/test/badge.svg	https://github.com/axetroy/vm.js/actions
Coverage Status	https://coveralls.io/repos/github/axetroy/vm.js/badge.svg?branch=master	https://coveralls.io/github/axetroy/vm.js?branch=master
DeepScan grade	https://deepscan.io/api/teams/5773/projects/7589/branches/79788/badge/grade.svg	https://deepscan.io/dashboard#view=project&tid=5773&pid=7589&bid=79788
Prettier	https://img.shields.io/badge/Code%20Style-Prettier-green.svg	https://github.com/prettier/prettier
npm version	https://badge.fury.io/js/%40axetroy%2Fvm.svg	https://badge.fury.io/js/%40axetroy%2Fvm
