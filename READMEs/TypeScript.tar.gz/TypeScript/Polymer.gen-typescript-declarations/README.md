## 🚨 Moved to [`Polymer/tools/packages/gen-typescript-declarations`][1] 🚨

The [`Polymer/gen-typescript-declarations`][2] repo has been migrated to [`packages/gen-typescript-declarations`][1] folder of the [`Polymer/tools`][3] 🚝  *monorepo*.

We are *actively* working on migrating open Issues and PRs to the new repo. New Issues and PRs should be filed at [`Polymer/tools`][3].

[1]: https://github.com/Polymer/tools/tree/master/packages/gen-typescript-declarations
[2]: https://github.com/Polymer/gen-typescript-declarations
[3]: https://github.com/Polymer/tools
