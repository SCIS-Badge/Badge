Build Status	https://travis-ci.org/structurizr/java.svg?branch=master	https://travis-ci.org/structurizr/java
