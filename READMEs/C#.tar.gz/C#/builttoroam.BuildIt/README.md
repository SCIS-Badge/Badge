## Welcome to BuildIt

A collection of useful methods and classes to make cross platform development easier

## Build status:
Master

![Build status](https://builttoroam.visualstudio.com/BuildIt%20Libraries/_apis/build/status/BuildIt%20Libraries)

Develop

![Build status](https://builttoroam.visualstudio.com/BuildIt%20Libraries/_apis/build/status/BuildIt%20Libraries?branchName=develop)


### Support or Contact

Contact Built to Roam for more information on the BuildIt Libraries
