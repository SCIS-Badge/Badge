# Linux-Mint-19.x-PosInstall
Shell Script de pós instalação do Linux Mint 19.x para utilização pessoal.
