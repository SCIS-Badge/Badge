# libbootimg
[![Build Status](https://travis-ci.org/Tasssadar/libbootimg.png?branch=master)](https://travis-ci.org/Tasssadar/libbootimg)

libbootimg is small library which can create, extract or update Android boot images.

**This library is required to build MultiROM and its modified TWRP. Clone it to
`/system/extras/libbootimg` inside the Android source tree.**

### bbootimg
`bbootimg` is a cli frontend for libbootimg, compatible with abootimg's arguments.
