Build Status	https://travis-ci.org/ianheggie/cruisecontrol.rb.png?branch=master	https://travis-ci.org/ianheggie/cruisecontrol.rb
Static Code analysis	https://codeclimate.com/github/ianheggie/cruisecontrol.rb.png	https://codeclimate.com/github/ianheggie/cruisecontrol.rb
Dependency Status	https://gemnasium.com/ianheggie/cruisecontrol.rb.png	https://gemnasium.com/ianheggie/cruisecontrol.rb
