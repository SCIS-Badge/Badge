Actions Status	https://github.com/sheredom/json.h/workflows/CMake/badge.svg	https://github.com/sheredom/json.h/actions
Build status	https://ci.appveyor.com/api/projects/status/piell6hcrlwrcxp9?svg=true	https://ci.appveyor.com/project/sheredom/json-h
