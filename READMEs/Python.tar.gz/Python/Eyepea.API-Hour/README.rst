API Hour
========

We have now a new project, Pillars, that will replace API-Hour in a near future: https://github.com/Eyepea/pillars

.. image:: https://raw.githubusercontent.com/Eyepea/API-Hour/master/docs/API-Hour_small.png
