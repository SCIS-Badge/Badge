Build Status	https://travis-ci.org/patorjk/figlet.js.svg	https://travis-ci.org/patorjk/figlet.js
NPM Downloads	https://img.shields.io/npm/dt/figlet.svg?style=flat	https://npmcharts.com/compare/figlet?minimal=true
