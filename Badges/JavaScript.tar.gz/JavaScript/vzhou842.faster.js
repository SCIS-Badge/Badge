NPM Version	https://img.shields.io/npm/v/faster.js.svg	https://www.npmjs.com/package/faster.js
Build Status	https://travis-ci.org/vzhou842/faster.js.svg?branch=master	https://travis-ci.org/vzhou842/faster.js
