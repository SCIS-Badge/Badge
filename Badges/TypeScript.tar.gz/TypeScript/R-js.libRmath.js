NPM	https://img.shields.io/npm/v/lib-r-math.js.svg	https://www.npmjs.com/package/lib-r-math.js
Build Status	https://travis-ci.org/R-js/libRmath.js.svg?branch=master	https://travis-ci.org/R-js/libRmath.js
