GitHub issues	https://img.shields.io/github/issues/LuRenJiasWorld/WP-Editor.md.svg	https://github.com/LuRenJiasWorld/WP-Editor.md/issues
GitHub forks	https://img.shields.io/github/forks/LuRenJiasWorld/WP-Editor.md.svg	https://github.com/LuRenJiasWorld/WP-Editor.md/network
GitHub stars	https://img.shields.io/github/stars/LuRenJiasWorld/WP-Editor.md.svg	https://github.com/LuRenJiasWorld/WP-Editor.md/stargazers
GitHub releases	https://img.shields.io/github/downloads/LuRenJiasWorld/WP-Editor.md/total.svg	https://github.com/LuRenJiasWorld/WP-Editor.md/releases
GitHub license	https://img.shields.io/github/license/LuRenJiasWorld/WP-Editor.md.svg	https://github.com/LuRenJiasWorld/WP-Editor.md/blob/master/LICENSE
Stargazers over time	https://starchart.cc/LuRenJiasWorld/WP-Editor.md.svg	https://starchart.cc/LuRenJiasWorld/WP-Editor.md
