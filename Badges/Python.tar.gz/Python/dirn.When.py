travismaster	https://secure.travis-ci.org/dirn/When.py.png?branch=master	http://travis-ci.org/dirn/When.py
travisdevelop	https://secure.travis-ci.org/dirn/When.py.png?branch=develop	http://travis-ci.org/dirn/When.py
