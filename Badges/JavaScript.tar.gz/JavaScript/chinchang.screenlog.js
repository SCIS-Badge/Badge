npm version	https://badge.fury.io/js/screenlog.svg	http://badge.fury.io/js/screenlog
