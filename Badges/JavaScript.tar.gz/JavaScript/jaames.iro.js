license	https://badgen.net/github/license/jaames/iro.js?color=BB5FD1	https://github.com/jaames/iro.js/blob/master/LICENSE.txt
version	https://badgen.net/npm/v/@jaames/iro?color=6C8FF2	https://npmjs.org/package/@jaames/iro
downloads	https://badgen.net/npm/dt/@jaames/iro?color=6AD4E0	https://npmjs.org/package/@jaames/iro
minzip size	https://badgen.net/bundlephobia/minzip/@jaames/iro?color=6FDF89	https://bundlephobia.com/result?p=@jaames/iro
no jQuery	https://badgen.net/badge/jQuery/none/F8AE55	
