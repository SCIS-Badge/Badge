npm version	https://badge.fury.io/js/httpclient.js.svg	https://badge.fury.io/js/httpclient.js
