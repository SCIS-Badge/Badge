build status	https://img.shields.io/travis/instructure/pdf-annotate.js.svg?style=flat-square	https://travis-ci.org/instructure/pdf-annotate.js
code coverage	https://img.shields.io/coveralls/instructure/pdf-annotate.js.svg?style=flat-square	https://coveralls.io/r/instructure/pdf-annotate.js
