CircleCI	https://img.shields.io/circleci/project/blockstack/stacks.js/master.svg	https://circleci.com/gh/blockstack/stacks.js/tree/master
Documentation	/docs-button.png	https://docs.blockstack.org/
