Directories
===========

firmware_v4 - Arduino sketches and libraries for ATmega328p based [Freematics ONE](https://freematics.com/products/freematics-one)

firmware_v5 - Arduino sketches for ESP32 based [Freematics ONE+](https://freematics.com/products/freematics-one-plus)

ESPRIT - Arduino library and example sketches for ESP32 development board [Freematics Esprit](https://freematics.com/products/freematics-esprit) and [devkits based on it](https://freematics.com/products/#kits)

libraries - Arduino libraries for ESP32 based Freematics ONE+ and Esprit

server - [Freematics Hub](https://freematics.com/hub/) server source code
