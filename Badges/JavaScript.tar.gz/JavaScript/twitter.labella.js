NPM version	https://badge.fury.io/js/labella.svg	https://npmjs.org/package/labella
Build Status	https://travis-ci.org/twitter/labella.js.svg?branch=master	https://travis-ci.org/twitter/labella.js
