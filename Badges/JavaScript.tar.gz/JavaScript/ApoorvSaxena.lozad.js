npm version	https://badge.fury.io/js/lozad.svg	https://badge.fury.io/js/lozad
Build Status	https://travis-ci.org/ApoorvSaxena/lozad.js.svg?branch=master	https://travis-ci.org/ApoorvSaxena/lozad.js
npm	https://img.shields.io/npm/dm/lozad	https://www.npmjs.com/package/lozad
