Build Status	https://secure.travis-ci.org/jenkinsci/jenkins.rb.png	https://travis-ci.org/jenkinsci/jenkins.rb
