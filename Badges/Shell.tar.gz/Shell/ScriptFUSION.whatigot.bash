Build status	https://travis-ci.org/ScriptFUSION/whatigot.bash.svg?branch=master	http://travis-ci.org/ScriptFUSION/whatigot.bash
