OpenCollective Backers	https://opencollective.com/jquery-adaptive-background/backers/badge.svg	#backers
OpenCollective Sponsors	https://opencollective.com/jquery-adaptive-background/sponsors/badge.svg	#sponsors
