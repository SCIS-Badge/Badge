Build Status	https://travis-ci.org/janl/mustache.js.svg?branch=master	https://travis-ci.org/janl/mustache.js
Gitter chat	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/janl/mustache.js
