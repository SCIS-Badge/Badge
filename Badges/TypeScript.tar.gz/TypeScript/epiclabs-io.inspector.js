Travis CI Status	https://travis-ci.org/epiclabs-io/inspector.js.svg?branch=master	https://travis-ci.org/epiclabs-io/inspector.js
