# Understand ruby memory usage 🤔

I initially made this post to add questions I have about ruby memory (in MRI). I don't have any CS degree, understanding how ruby use memory is not an easy path. I'm passionate about this subject.

This projet is now a wiki. Feel free to contribute. 🙌

https://github.com/benoittgt/understand_ruby_memory/wiki
