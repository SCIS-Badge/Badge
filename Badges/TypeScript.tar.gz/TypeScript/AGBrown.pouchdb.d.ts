Build Status	https://travis-ci.org/AGBrown/pouchdb.d.ts.svg?branch=master	https://travis-ci.org/AGBrown/pouchdb.d.ts
Build Status	https://travis-ci.org/AGBrown/pouchdb.d.ts.svg?branch=dev	https://travis-ci.org/AGBrown/pouchdb.d.ts
Build Status	https://travis-ci.org/AGBrown/pouchdb.d.ts.svg?branch=feat	https://travis-ci.org/AGBrown/pouchdb.d.ts
