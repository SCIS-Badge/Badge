image	https://travis-ci.org/halcy/Mastodon.py.svg?branch=master	https://travis-ci.org/halcy/Mastodon.py
image	https://codecov.io/gh/halcy/Mastodon.py/branch/master/graph/badge.svg	https://codecov.io/gh/halcy/Mastodon.py
