Build Status	https://ci.appveyor.com/api/projects/status/nt0h6ufvhdvk7obc/branch/master?svg=true	https://ci.appveyor.com/project/seanmcilvenna/fhir-js
Build Status	https://travis-ci.org/lantanagroup/FHIR.js.svg?branch=master	https://travis-ci.org/lantanagroup/FHIR.js
