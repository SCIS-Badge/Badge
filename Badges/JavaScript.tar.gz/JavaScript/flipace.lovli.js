bitHound Overall Score	https://www.bithound.io/github/flipace/lovli.js/badges/score.svg	https://www.bithound.io/github/flipace/lovli.js
bitHound Dependencies	https://www.bithound.io/github/flipace/lovli.js/badges/dependencies.svg	https://www.bithound.io/github/flipace/lovli.js/master/dependencies/npm
bitHound Code	https://www.bithound.io/github/flipace/lovli.js/badges/code.svg	https://www.bithound.io/github/flipace/lovli.js
