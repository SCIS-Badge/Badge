Build Status	https://travis-ci.org/angular/di.js.png?branch=master	https://travis-ci.org/angular/di.js
