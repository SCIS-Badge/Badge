drv-netif-netmap [![Build Status](https://travis-ci.org/rumpkernel/drv-netif-netmap.png?branch=master)](https://travis-ci.org/rumpkernel/drv-netif-netmap)
================

drv-netif-netmap is a [netmap](http://info.iet.unipi.it/~luigi/netmap/)
network interface for [rump kernels](http://rumpkernel.org).  The combined
result is a TCP/IP stack doing packet I/O via netmap.
Currently, netmap API revisions 11-15 are supported.

See [the wiki](http://wiki.rumpkernel.org/Repo:-drv-netif-netmap) for
more information and instructions.
