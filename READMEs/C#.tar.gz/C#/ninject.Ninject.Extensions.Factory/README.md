# Ninject.Extensions.Factory 

[![Build status](https://ci.appveyor.com/api/projects/status/2a4sju0s2ido9l9h?svg=true)](https://ci.appveyor.com/project/Ninject/ninject-extensions-factory)
[![codecov](https://codecov.io/gh/ninject/Ninject.Extensions.Factory/branch/master/graph/badge.svg)](https://codecov.io/gh/ninject/Ninject.Extensions.Factory)
[![NuGet Version](http://img.shields.io/nuget/v/Ninject.Extensions.Factory.svg?style=flat)](https://www.nuget.org/packages/Ninject.Extensions.Factory/) 
[![NuGet Downloads](http://img.shields.io/nuget/dt/Ninject.Extensions.Factory.svg?style=flat)](https://www.nuget.org/packages/Ninject.Extensions.Factory/)

This Ninject extension allows to create factory implementations automatically.

## Documentation

https://github.com/ninject/Ninject.Extensions.Factory/wiki