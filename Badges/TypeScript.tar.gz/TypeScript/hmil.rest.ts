Build Status	https://travis-ci.org/hmil/rest.ts.svg?branch=master	https://travis-ci.org/hmil/rest.ts
npm version	https://badge.fury.io/js/rest-ts-core.svg	https://www.npmjs.com/package/rest-ts-core
github home	./resources/GitHub-Mark-32px.png	https://github.com/hmil/rest.ts#readme
documentation	./resources/doc.png	http://code.hmil.fr/rest.ts/index.html
Overview	./resources/elevator-pitch.png	http://code.hmil.fr/rest.ts/resources/elevator-pitch.png
