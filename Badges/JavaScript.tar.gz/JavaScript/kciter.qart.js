CDNJS	https://img.shields.io/cdnjs/v/qartjs.svg	https://cdnjs.com/libraries/qartjs
Downloads	https://img.shields.io/npm/dt/qartjs.svg	https://www.npmjs.com/package/qartjs
Version	https://img.shields.io/npm/v/qartjs.svg	https://www.npmjs.com/package/qartjs
License	https://img.shields.io/npm/l/qartjs.svg	https://www.npmjs.com/package/qartjs
