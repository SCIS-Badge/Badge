# nali-ipip
a fork of http://www.surfchen.org/nali using ipip ipdb (http://ipip.net)

基于nali修改支持IPIP数据库(http://ipip.net)

### Install

./configure && make && make install

### Usage

command|nali (example: mtr 8.8.8.8|nali)

PS.为了方便随时随地随心所欲的研究某个ip的路由，并且考虑到原版自带的纯真库的正确率问题，所以撸了这个改版出来，欢迎各位使用。
