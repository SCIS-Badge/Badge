### Material Design 系列 Samples (持续更新中...)
这个Demo是一个关于Android material Design 控件的一些使用示例，会持续更新。
示例截图：


![samples.gif](material_design_simples.gif)


目前包含以下一些控件的使用：

##### 1,BottomSheetDialog 使用示例

##### 2,Toolbar 相关使用示例 
详情请看博客：[《Material Design 之 Toolbar 开发实践总结》](http://www.jianshu.com/p/e2ae6aaff696)

##### 3, AppbarLayout + CoordinatorLayout + CollapsingToolbarLayout 示例

详情请看：简书：[《Material Design之 AppbarLayout 开发实践总结》](http://www.jianshu.com/p/ac56f11e7ce1)
         掘金：[《Material Design之 AppbarLayout 开发实践总结》](https://gold.xitu.io/post/584d60b161ff4b0058e3b26b)


##### 4 SwipeDissmissBehavior 示例
  详情请看：简书博客：[Material Design 之 Behavior 的使用和自定义 Behavior](http://www.jianshu.com/p/82d18b0d18f4)
           掘金专栏：[Material Design 之 Behavior 的使用和自定义 Behavior](https://gold.xitu.io/post/585bb76961ff4b006cc9d5b6)
##### 5 BottomSheetBehavior 示例
详情请看：简书博客：[Material Design 之 Behavior 的使用和自定义 Behavior](http://www.jianshu.com/p/82d18b0d18f4)
           掘金专栏：[Material Design 之 Behavior 的使用和自定义 Behavior](https://gold.xitu.io/post/585bb76961ff4b006cc9d5b6)
##### 6 FAB and Snackbar 示例

##### 7 自定义Behavior(一)
详情请看：简书博客：[Material Design 之 Behavior 的使用和自定义 Behavior](http://www.jianshu.com/p/82d18b0d18f4)
           掘金专栏：[Material Design 之 Behavior 的使用和自定义 Behavior](https://gold.xitu.io/post/585bb76961ff4b006cc9d5b6)
##### 8 自定义Behavior (二)
详情请看：简书博客：[Material Design 之 Behavior 的使用和自定义 Behavior](http://www.jianshu.com/p/82d18b0d18f4)
           掘金专栏：[Material Design 之 Behavior 的使用和自定义 Behavior](https://gold.xitu.io/post/585bb76961ff4b006cc9d5b6)

##### 9 TabLayout +ViewPager + Fragment
  详情请看：简书博客：[Material Design 之 TabLayout 使用](http://www.jianshu.com/p/13f334eb16ce)
           掘金专栏：[Material Design 之 TabLayout 使用](https://gold.xitu.io/post/5864eb13570c3500695dcd1a)
##### 10 BottomNavigationView 示例

##### 11 TextInputLayout + TextInputEditText 示例

##### 12...






### 联系方式
 简书:[http://www.jianshu.com/u/35167a70aa39](http://www.jianshu.com/u/35167a70aa39)
 
 掘金：[https://juejin.im/user/56949a9960b2e058a42be0ba](https://juejin.im/user/56949a9960b2e058a42be0ba)
 
 技术交流QQ群：155971357
 
 公众号：**Android技术杂货铺**
 
 欢迎关注我的公众号，第一时间获取我的博客更新提醒，以及更多有价值的原创Android干货文章、职场经验、面试技巧等等。
 长按下方二维码即可关注。

 ![gzh.jpg](gzh.jpg)