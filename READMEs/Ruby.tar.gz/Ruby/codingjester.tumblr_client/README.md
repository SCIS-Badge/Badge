This repository no longer maintains tumblr_client, if you want to file issues, check out new code please see the official repository found
[here](https://github.com/tumblr/tumblr_client).

