Build status	https://img.shields.io/travis/andywer/threads.js/v1.svg?style=flat-square	https://travis-ci.org/andywer/threads.js
npm (tag)	https://img.shields.io/npm/v/threads.svg?style=flat-square	https://www.npmjs.com/package/threads
Chat room	https://img.shields.io/badge/chat-gitter.im-orange	https://gitter.im/threadsjs/community
