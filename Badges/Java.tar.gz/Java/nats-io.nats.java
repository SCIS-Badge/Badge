License Apache 2	https://img.shields.io/badge/License-Apache2-blue.svg	https://www.apache.org/licenses/LICENSE-2.0
Build Status	https://travis-ci.org/nats-io/nats.java.svg?branch=master	http://travis-ci.org/nats-io/nats.java?branch=master
Coverage Status	https://coveralls.io/repos/nats-io/nats.java/badge.svg?branch=master&service=github	https://coveralls.io/github/nats-io/nats.java?branch=master
Maven Central	https://maven-badges.herokuapp.com/maven-central/io.nats/jnats/badge.svg	https://maven-badges.herokuapp.com/maven-central/io.nats/jnats
Javadoc	http://javadoc.io/badge/io.nats/jnats.svg?branch=master	http://javadoc.io/doc/io.nats/jnats?branch=master
