
[![Github All Releases](https://img.shields.io/github/downloads/dreamcooled/sjupdater/total.svg?style=flat)](https://github.com/Dreamcooled/sjupdater/releases)
[![GitHub license](https://img.shields.io/github/license/dreamcooled/sjupdater.svg?style=flat)](https://github.com/Dreamcooled/sjupdater/blob/master/LICENSE.md)
[![GitHub issues](https://img.shields.io/github/issues/dreamcooled/sjupdater.svg?style=flat)](https://github.com/Dreamcooled/sjupdater/issues)
# SjUpdater

An Updater and Linkaggregator for Serienjunkies.org written in C#/WPF.
Any contribution would be highly appreciated.



#### Download
Binaries of current version (needs .NET 4.5):   [![GitHub release](https://img.shields.io/github/release/dreamcooled/sjupdater.svg?style=flat)](https://github.com/Dreamcooled/sjupdater/releases/latest)



#### Screenshots

![Main Screen](http://fs1.directupload.net/images/150831/xdoo57z4.png)
![Show Screen](http://fs2.directupload.net/images/141222/oq7pq2mv.png)
![Show Screen 2](http://fs2.directupload.net/images/141222/yhzxtrjk.png)
![Settings Screen](http://fs1.directupload.net/images/141222/plp3of5m.png)
![Notification](http://s7.directupload.net/images/140810/wf7jemqk.png)


