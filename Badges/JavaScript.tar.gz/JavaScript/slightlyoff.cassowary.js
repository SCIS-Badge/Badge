Build Status	https://travis-ci.org/slightlyoff/cassowary-js-refactor.png?branch=master	https://travis-ci.org/slightlyoff/cassowary-js-refactor
