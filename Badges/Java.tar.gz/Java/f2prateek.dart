Maven Central	https://maven-badges.herokuapp.com/maven-central/com.f2prateek.dart/dart/badge.svg	https://maven-badges.herokuapp.com/maven-central/com.f2prateek.dart/dart
Android Arsenal	https://img.shields.io/badge/Android%20Arsenal-Dart-brightgreen.svg?style=flat	http://android-arsenal.com/details/1/1444
Build Status	https://travis-ci.org/f2prateek/dart.svg?branch=master	https://travis-ci.org/f2prateek/dart
