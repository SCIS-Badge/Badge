@latest	https://img.shields.io/npm/v/@octokit/request.svg	https://www.npmjs.com/package/@octokit/request
Build Status	https://github.com/octokit/request.js/workflows/Test/badge.svg	https://github.com/octokit/request.js/actions?query=workflow%3ATest+branch%3Amaster
