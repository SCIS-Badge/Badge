## 更新情况
API接口不断增加中...

最近更新是在2020/6/1，更新抖音短视频去水印

* 娱乐类

  - 视频类

    - [抖音无水印解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/douyin)

    - [快手去水印解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/gifshow)

    - [微视去水印解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/weishi)

    - [皮皮虾无水印解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/PiPiXia)

    - [皮皮搞笑无水印解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/PiPiGaoXiao)

    - [CCTV央视网解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/cctv)

    - ~~[m3u8视频在线解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/m3u8)~~

    - ~~[flv视频在线解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/flv)~~

  - 音频类

    - [网易云音乐解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/163music)

    - [喜马拉雅FM信息采集](https://github.com/iqiqiya/iqiqiya-API/tree/master/ximalaya)
    
    - [echo回声无损音乐解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/echo)

  - 图片类

    - [必应每日一图](https://github.com/iqiqiya/iqiqiya-API/tree/master/bing)

    - [随机生成二次元图片](https://github.com/iqiqiya/iqiqiya-API/tree/master/ACG)

    - [一句话随机图片](https://github.com/iqiqiya/iqiqiya-API/tree/master/RandPic)

    - [bilibili封面图获取](https://github.com/iqiqiya/iqiqiya-API/tree/master/bilibili)

    - [千图网无水印解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/58pic)

    - [千库网无水印解析(测试中)](http://api.77sec.cn/)

    - [17素材网免VIP解析(测试中)](http://api.77sec.cn/17sucai)

    - [包图网免VIP解析(暂不开源)](http://api.77sec.cn/baotu)

  - 文字类

    - [一言(古诗句版)](https://github.com/iqiqiya/iqiqiya-API/tree/master/yiyan)

* 工具类

  - 生活类

    - [在线ip查询](https://github.com/iqiqiya/iqiqiya-API/tree/master/ip)

    - [快递查询-支持国内百家快递](https://github.com/iqiqiya/iqiqiya-API/tree/master/kuaidi)

    - [qq用户信息获取](https://github.com/iqiqiya/iqiqiya-API/tree/master/QQ)

    - [微信运动步数修改](https://github.com/iqiqiya/iqiqiya-API/tree/master/WeChat)
    
    - [短网址生成](https://github.com/iqiqiya/iqiqiya-API/tree/master/Shortlinks)

  - 其它类

    - [蓝奏云直链解析](https://github.com/iqiqiya/iqiqiya-API/tree/master/lanzou)

    - [哔哩哔哩up主开播提醒](https://github.com/iqiqiya/Bilibili_Up_Live_Reminder)

## 在线预览

[iqiqiya-API](https://api.77sec.cn/)

[iAkie在线工具箱](https://tools.iakie.com/)

## 项目说明

本项目主要是用来记录自己的进步，

同时帮助我这样的新手学习编写自己的API，仅用作学习交流

有问题直接issue，可以一起讨论

最后，如果对你有帮助请star，谢啦

[更多好玩，欢迎关注公众号【想到即道】](./ewm.jpg)

![Image text](./ewm.jpg)
