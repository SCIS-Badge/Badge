Build Status	https://secure.travis-ci.org/cowboyd/commonjs.rb.png	http://travis-ci.org/cowboyd/commonjs.rb
