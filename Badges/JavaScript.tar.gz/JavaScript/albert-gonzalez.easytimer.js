NPM	https://nodei.co/npm/easytimer.js.png?downloads=true&downloadRank=true	https://nodei.co/npm/easytimer.js/
