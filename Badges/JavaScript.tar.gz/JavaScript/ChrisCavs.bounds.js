bounds.js on NPM	https://img.shields.io/npm/v/bounds.js.svg?style=flat-square	https://www.npmjs.com/package/bounds.js
