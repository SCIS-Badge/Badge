travis	https://secure.travis-ci.org/dominictarr/JSON.sh.png?branch=master	https://travis-ci.org/dominictarr/JSON.sh
