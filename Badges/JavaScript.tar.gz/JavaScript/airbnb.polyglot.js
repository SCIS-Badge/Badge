Build Status	https://travis-ci.org/airbnb/polyglot.js.svg	https://travis-ci.org/airbnb/polyglot.js
Join the chat at https://gitter.im/airbnb/polyglot.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/airbnb/polyglot.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
