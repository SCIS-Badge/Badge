Coverage Status	https://coveralls.io/repos/github/ChiChou/grab.js/badge.svg?branch=master	https://coveralls.io/github/ChiChou/grab.js?branch=master
Build Status	https://travis-ci.org/ChiChou/grab.js.svg?branch=master	https://travis-ci.org/ChiChou/grab.js
