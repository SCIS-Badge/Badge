Build Status	https://travis-ci.org/gfranko/jquery.selectBoxIt.js.png?branch=master	https://travis-ci.org/gfranko/jquery.selectBoxIt.js
Bitdeli Badge	https://d2weczhvl823v0.cloudfront.net/gfranko/jquery.selectBoxIt.js/trend.png	https://bitdeli.com/free
