#awd-platfrom

this is a project to set up your awd environment(web challenges only) quickly, all of the gameboxes are docker-based, and the score board is terminal based.

usage: 
you need to copy your challenge for each team within the batch.py, for example: [python batch.py web_server 4], this command will copy the web_server directory to 4 folders, and creates the docker.sh as well as the run.sh for each folder. 
then to start all docker, just run [python start.py 4], this command will create totally 6 dockers, one for checker_server, one for flag_server, and 4 gameboxes.
to clean up all dockers, just run [python stop_clean.py], it will stop all dockers, and clear all dockes for you.
the scores of each team can be viewed in the output of check.py of the checker.

enjoy it!
