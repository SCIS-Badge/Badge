Build status	https://travis-ci.org/bestiejs/punycode.js.svg?branch=master	https://travis-ci.org/bestiejs/punycode.js
Code coverage status	http://img.shields.io/codecov/c/github/bestiejs/punycode.js.svg	https://codecov.io/gh/bestiejs/punycode.js
Dependency status	https://gemnasium.com/bestiejs/punycode.js.svg	https://gemnasium.com/bestiejs/punycode.js
twitter/mathias	https://gravatar.com/avatar/24e08a9ea84deb17ae121074d0f17125?s=70	https://twitter.com/mathias
