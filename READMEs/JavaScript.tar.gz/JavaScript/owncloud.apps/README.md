This repository is *archived*.

Most apps are outdated and incompatible with recent ownCloud versions.

The following apps were moved out:
- external: moved to https://github.com/owncloud/external
- user_external: moved to https://github.com/owncloud/user_external
- user_cas: obsoleted by https://marketplace.owncloud.com/apps/user_cas

