CI	https://img.shields.io/circleci/project/github/dydxprotocol/dydx.js.svg	https://circleci.com/gh/dydxprotocol/workflows/dydx.js/tree/master
Coverage Status	https://coveralls.io/repos/github/dydxprotocol/dydx.js/badge.svg?branch=master&t=oTubHH	https://coveralls.io/github/dydxprotocol/dydx.js?branch=master
License	https://img.shields.io/github/license/dydxprotocol/dydx.js.svg?longCache=true	https://github.com/dydxprotocol/dydx.js/blob/master/LICENSE
NPM	https://img.shields.io/npm/v/@dydxprotocol/dydx.js.svg	https://www.npmjs.com/package/@dydxprotocol/dydx.js
Slack	https://img.shields.io/badge/chat-on%20slack-brightgreen.svg?longCache=true	https://slack.dydx.exchange/
