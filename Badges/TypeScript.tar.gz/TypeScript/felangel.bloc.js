build	https://github.com/felangel/bloc.js/workflows/bloc.js/badge.svg	https://github.com/felangel/bloc.js/actions
codecov	https://codecov.io/gh/felangel/bloc.js/branch/master/graph/badge.svg	https://codecov.io/gh/felangel/bloc.js
License: MIT	https://img.shields.io/badge/license-MIT-purple.svg	https://opensource.org/licenses/MIT
Bloc Library	https://tinyurl.com/bloc-library	https://github.com/felangel/bloc
npm	https://badge.fury.io/js/%40felangel%2Fbloc.svg	https://www.npmjs.com/package/@felangel/bloc
npm	https://badge.fury.io/js/%40felangel%2Freact-bloc.svg	https://www.npmjs.com/package/@felangel/react-bloc
