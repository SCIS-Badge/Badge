Build Status	https://travis-ci.org/jaywcjlove/validator.js.svg?branch=master	https://travis-ci.org/jaywcjlove/validator.js
CircleCI	https://circleci.com/gh/jaywcjlove/validator.js.svg?style=svg	https://circleci.com/gh/jaywcjlove/validator.js
