Github file size	https://img.shields.io/github/size/marcbruederlin/particles.js/dist/particles.min.js.svg	https://github.com/marcbruederlin/particles.js/blob/master/dist/particles.min.js
Travis	https://img.shields.io/travis/marcbruederlin/particles.js.svg	https://travis-ci.org/marcbruederlin/particles.js
David	https://img.shields.io/david/marcbruederlin/particles.js.svg	https://david-dm.org/marcbruederlin/particles.js
David	https://img.shields.io/david/dev/marcbruederlin/particles.js.svg	https://david-dm.org/marcbruederlin/particles.js?type=dev
npm	https://img.shields.io/npm/v/particlesjs.svg	https://www.npmjs.com/package/particlesjs
CDNJS	https://img.shields.io/cdnjs/v/particlesjs.svg	https://cdnjs.com/libraries/particlesjs
GitHub license	https://img.shields.io/badge/license-MIT-blue.svg	https://raw.githubusercontent.com/marcbruederlin/particles.js/master/LICENSE
