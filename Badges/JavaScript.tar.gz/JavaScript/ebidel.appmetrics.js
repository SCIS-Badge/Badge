User timing inputs show up in the DevTools timeline	https://s16.postimg.org/bm2owyvqd/Screen_Shot_2016_08_23_at_6_03_30_PM.png	https://postimg.org/image/icj66eiw1/
Screen Shot 2016-08-23 at 6.22.37 PM.png	https://s16.postimg.org/rxa0gsuxx/Screen_Shot_2016_08_23_at_6_22_37_PM.png	https://postimg.org/image/6nme5yen5/
Logging records to the console	https://s4.postimg.org/b47jz5699/Screen_Shot_2016_08_23_at_6_08_26_PM.png	https://postimg.org/image/h558w7svd/
Screen Shot 2016-08-23 at 6.40.03 PM.png	https://s3.postimg.org/6y0ay534j/Screen_Shot_2016_08_23_at_6_40_03_PM.png	https://postimg.org/image/6l8wrykun/
