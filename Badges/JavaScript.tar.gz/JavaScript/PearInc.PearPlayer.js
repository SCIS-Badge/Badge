npm	https://img.shields.io/npm/v/pearplayer.svg?style=flat	https://www.npmjs.com/package/pearplayer
jsdelivr	https://data.jsdelivr.com/v1/package/npm/pearplayer/badge	https://www.jsdelivr.com/package/npm/pearplayer
License	https://img.shields.io/badge/license-MIT-blue.svg	https://www.jsdelivr.com/package/npm/pearplayer
