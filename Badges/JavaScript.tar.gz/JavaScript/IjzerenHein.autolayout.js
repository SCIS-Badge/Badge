Build Status	https://travis-ci.org/IjzerenHein/autolayout.js.svg?branch=master	https://travis-ci.org/IjzerenHein/autolayout.js
view on npm	http://img.shields.io/npm/v/autolayout.svg	https://www.npmjs.org/package/autolayout
License	http://img.shields.io/:license-mit-blue.svg	http://doge.mit-license.org
Example - click me	example.png	https://rawgit.com/IjzerenHein/visualformat-editor/master/dist/index.html?vfl=example
