discord.sh	https://i.imgur.com/xZ8r3N0.png	https://github.com/ChaoticWeg/discord.sh
Travis CI (master branch)	https://img.shields.io/travis/ChaoticWeg/discord.sh/master.svg?style=for-the-badge	https://travis-ci.org/ChaoticWeg/discord.sh
GitHub stars	https://img.shields.io/github/stars/ChaoticWeg/discord.sh.svg?style=for-the-badge	https://github.com/ChaoticWeg/discord.sh/stargazers
