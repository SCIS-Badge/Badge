Build Status	https://img.shields.io/travis/benweet/stackedit.js.svg?style=flat	https://travis-ci.org/benweet/stackedit.js
NPM version	https://img.shields.io/npm/v/stackedit-js.svg?style=flat	https://www.npmjs.org/package/stackedit-js
