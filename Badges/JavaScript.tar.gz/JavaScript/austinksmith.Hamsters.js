Backers on Open Collective	https://opencollective.com/hamstersjs/backers/badge.svg	#backers
Sponsors on Open Collective	https://opencollective.com/hamstersjs/sponsors/badge.svg	#sponsors
