# Retrofit_RxJava_MVP
Network uses Retrofit and RxJava With MVP architecture

Recent rxjava very fire, and then try to combine rxjava and Retrofit wrote a Demo, and try the next mvp

Branches night mode there is a problem, since you do not want to repeat the same functionality as written,night mode check my another demo
[https://github.com/7449/ZLSimple](https://github.com/7449/ZLSimple)


### NetWork RxJava2.X ?

[https://github.com/7449/RxNetWork](https://github.com/7449/RxNetWork)

![](https://github.com/blackCave/Retrofit_RxJava_MVP/blob/master/image/C.gif)

Thanks tngou api interface [http://www.tngou.net/doc/gallery](http://www.tngou.net/doc/gallery)


# Description Framework

	androidSupport
	glide
	rx
	retrofit2
	butterknife
