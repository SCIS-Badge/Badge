Build Status	https://travis-ci.org/yanhaijing/template.js.svg?branch=master	https://travis-ci.org/yanhaijing/template.js
license	https://img.shields.io/badge/license-MIT-blue.svg	https://github.com/yanhaijing/template.js/blob/master/LICENSE
