Language grade: C/C++	https://img.shields.io/lgtm/grade/cpp/g/uNetworking/uWebSockets.js.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/uNetworking/uWebSockets.js/context:cpp
