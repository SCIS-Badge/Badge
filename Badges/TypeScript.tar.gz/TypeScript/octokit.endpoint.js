@latest	https://img.shields.io/npm/v/@octokit/endpoint.svg	https://www.npmjs.com/package/@octokit/endpoint
