# Design Documents for pandas Project

This repository contains an evolving set of documents about the internal
(library developer-facing) and external (user-facing) aspects of the pandas
project.