# ng2-quiz

A general purpose quiz application developed in angular (version 8) that can be used for multiple purpose.
+
+For detailed documentation, please go to: https://www.codeproject.com/Articles/1167451/Quiz-Application-in-Angular

### Please raise a pull request for any bug fix or if you have implemented a new feature and feel it is useful.
