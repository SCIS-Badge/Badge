Build Status	https://travis-ci.org/algolia/search-insights.js.svg?branch=master	https://travis-ci.org/algolia/search-insights.js
npm version	https://badge.fury.io/js/search-insights.svg	https://badge.fury.io/js/search-insights
