CircleCI	https://circleci.com/gh/oasislabs/oasis.js.svg?style=svg	https://circleci.com/gh/oasislabs/oasis.js
Gitter chat	https://badges.gitter.im/Oasis-official/Lobby.svg	https://gitter.im/Oasis-official/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
docs	https://readthedocs.com/projects/oasis-labs-oasis-client/badge/?version=latest	https://oasis-labs-oasis-client.readthedocs-hosted.com/en/latest/
npm	https://img.shields.io/npm/v/@oasislabs/client.svg	https://www.npmjs.com/package/@oasislabs/client
npm	https://img.shields.io/npm/v/@oasislabs/gateway.svg	https://www.npmjs.com/package/@oasislabs/gateway
npm	https://img.shields.io/npm/v/@oasislabs/service.svg	https://www.npmjs.com/package/@oasislabs/service
npm	https://img.shields.io/npm/v/@oasislabs/confidential.svg	https://www.npmjs.com/package/@oasislabs/confidential
npm	https://img.shields.io/npm/v/@oasislabs/common.svg	https://www.npmjs.com/package/@oasislabs/common
npm	https://img.shields.io/npm/v/@oasislabs/test.svg	https://www.npmjs.com/package/@oasislabs/test
npm	https://img.shields.io/npm/v/@oasislabs/web3.svg	https://www.npmjs.com/package/@oasislabs/web3
