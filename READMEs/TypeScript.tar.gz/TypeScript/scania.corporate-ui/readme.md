
# Scania digital design system

### :warning: We have moved our repositories to another organisation called [scania-digital-design-system](https://github.com/scania-digital-design-system/)

This repository will be archived in Q3 2021. Please visit https://digitaldesign.scania.com/ for Scania Digital Design System. Checkout the new repository https://github.com/scania-digital-design-system/sdds for examples and code.

Get in touch with us on [teams](https://teams.microsoft.com/l/team/19%3a1257007a64d44c64954acca27a9d4b46%40thread.skype/conversations?groupId=79f9bfeb-73e2-424d-9477-b236191ece5e&tenantId=3bc062e4-ac9d-4c17-b4dd-3aad637ff1ac)

