Build Status	https://travis-ci.org/benfred/venn.js.svg?branch=master	https://travis-ci.org/benfred/venn.js
Downloads	https://img.shields.io/npm/dm/venn.js.svg	https://www.npmjs.com/package/venn.js
