Build Status	https://travis-ci.org/box/viewer.js.png?branch=master	https://travis-ci.org/box/viewer.js
Project Status	http://opensource.box.com/badges/stable.svg	http://opensource.box.com/badges
