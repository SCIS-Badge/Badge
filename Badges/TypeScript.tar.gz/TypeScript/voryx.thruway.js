Build Status	https://travis-ci.org/voryx/thruway.js.svg?branch=master	https://travis-ci.org/voryx/thruway.js
