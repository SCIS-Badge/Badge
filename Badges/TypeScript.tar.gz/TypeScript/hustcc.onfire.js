Build Status	https://travis-ci.org/hustcc/onfire.js.svg?branch=master	https://travis-ci.org/hustcc/onfire.js
npm	https://img.shields.io/npm/v/onfire.js.svg	https://www.npmjs.com/package/onfire.js
