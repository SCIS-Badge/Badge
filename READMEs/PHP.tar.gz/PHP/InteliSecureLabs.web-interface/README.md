<h2>Pineapple Web-Interface</h2>
Everyone should be aware of what the WiFi Pineapple is, if not please visit the following URLs:
<ul>
<li>http://www.hak5.org
<li>http://wifipineapple.com
</ul>
<h2>This Project</h2>
The Pineapple's originally cost approximately $200+(USD) recently the price has dropped to a more affordable $100(USD).
This is Pentura's take on forking the project to build an even cheaper clone, for University Undergraduates / Researchers with a limited budget.
With a maximum target of $50(USD), we set up to build an alternative model.

Our Solution:
<ul>
<li>TPLink WR703N - $20(USD)
<li> USB Flash Cruzer - $10(USD)
</ul>
<h2>TPLink Pineapple Mods</h2>
Additional file ouside of the web-interface can be found at: https://github.com/PenturaLabs/Pineapple-Confs.

This repository contains the forked web-interface, originally from Sebkinne.
