Build Status	https://secure.travis-ci.org/hotchemi/zaim.js.png	http://travis-ci.org/hotchemi/zaim.js
Coverage Status	https://coveralls.io/repos/hotchemi/zaim.js/badge.png?branch=master	https://coveralls.io/r/hotchemi/zaim.js
NPM version	https://badge.fury.io/js/zaim.png	http://badge.fury.io/js/zaim
