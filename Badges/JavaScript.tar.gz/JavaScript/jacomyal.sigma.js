Build Status	https://travis-ci.org/jacomyal/sigma.js.svg	https://travis-ci.org/jacomyal/sigma.js
