Build Status	https://travis-ci.org/yanhaijing/data.js.svg?branch=master	https://travis-ci.org/yanhaijing/data.js
license	http://img.shields.io/npm/l/express.svg	https://github.com/yanhaijing/data.js/blob/master/MIT-LICENSE.txt
release	https://img.shields.io/badge/release-v0.3.0-orange.svg	https://github.com/yanhaijing/data.js/releases/tag/v0.3.0
