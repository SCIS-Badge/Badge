# [DEPRECATED] Vagrantfile for Taiga

## Documentation

http://taigaio.github.io/taiga-doc/dist/setup-alternatives.html#setup-taiga-vagrant

## Community ##

[Taiga has a mailing list](http://groups.google.com/d/forum/taigaio). Feel free to join it and ask any questions you may have.

To subscribe for announcements of releases, important changes and so on, please follow [@taigaio](https://twitter.com/taigaio) on Twitter.

