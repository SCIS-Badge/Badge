npm Version	https://img.shields.io/npm/v/timeago.js.svg	https://www.npmjs.com/package/timeago.js
Build Status	https://github.com/hustcc/timeago.js/workflows/build/badge.svg	https://github.com/hustcc/timeago.js/actions
Coverage Status	https://coveralls.io/repos/github/hustcc/timeago.js/badge.svg?branch=master	https://coveralls.io/github/hustcc/timeago.js?branch=master
npm Download	https://img.shields.io/npm/dm/timeago.js.svg	https://www.npmjs.com/package/timeago.js
npm License	https://img.shields.io/npm/l/timeago.js.svg	https://www.npmjs.com/package/timeago.js
