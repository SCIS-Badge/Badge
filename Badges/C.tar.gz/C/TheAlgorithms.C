Gitpod Ready-to-Code	https://img.shields.io/badge/Gitpod-Ready--to--Code-blue?logo=gitpod	https://gitpod.io/#https://github.com/TheAlgorithms/C
Language grade: C/C++	https://img.shields.io/lgtm/grade/cpp/g/TheAlgorithms/C.svg?logo=lgtm&logoWidth=18	https://lgtm.com/projects/g/TheAlgorithms/C/context:cpp
Gitter chat	https://img.shields.io/badge/Chat-Gitter-ff69b4.svg?label=Chat&logo=gitter&style=flat-square	https://gitter.im/TheAlgorithms
contributions welcome	https://img.shields.io/static/v1.svg?label=Contributions&message=Welcome&color=0059b3&style=flat-square	https://github.com/TheAlgorithms/C/blob/master/CONTRIBUTING.md
Doxygen CI	https://github.com/TheAlgorithms/C/workflows/Doxygen%20CI/badge.svg	https://TheAlgorithms.github.io/C
Awesome CI	https://github.com/TheAlgorithms/C/workflows/Awesome%20CI%20Workflow/badge.svg	https://github.com/TheAlgorithms/C/actions?query=workflow%3A%22Awesome+CI+Workflow%22
