8-Bit Universal Nand reader for FTDI2323H Breakout boards

Based on http://spritesmods.com/?art=ftdinand code and ideas

Heavily modified to support writing nand, universally detecting and dumping nands
using Linux Kernel source code additions.

(c) 2014 B. Kerler <info AT revskills.de>