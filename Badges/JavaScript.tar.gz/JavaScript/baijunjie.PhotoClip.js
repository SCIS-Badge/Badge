npm version	https://badge.fury.io/js/photoclip.svg	https://badge.fury.io/js/photoclip
