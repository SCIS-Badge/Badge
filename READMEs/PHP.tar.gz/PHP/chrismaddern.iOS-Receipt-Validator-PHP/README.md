In App Purchase Receipt Validator - PHP
=======================================

Host this on any box which is running PHP and has direct outbound web access and it will be able to validate iOS IAP receipts for you (Sandbox or Production environment configurable).

Feel free to use this code in anything you make, with the standard disclaimer that if it doesn't work / blows up the universe, you're on your own.

Alternatively, the latest version is hosted at: http://www.chrismaddern.com/validate-itunes-receipt/

This points to production.

There is a Sandbox version embedded here:
http://www.chrismaddern.com/validate-app-store-iap-receipt-codes-online-tool/

The PHP is rough, but it works - any forks / pull requests are more than welcome!!
