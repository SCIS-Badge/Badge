Build Status	https://img.shields.io/travis/xmcp/pakku.js.svg?style=flat-square	https://travis-ci.org/xmcp/pakku.js
Chrome Web Store - Version	https://img.shields.io/chrome-web-store/v/jklfcpboamajpiikgkbjcnnnnooefbhh.svg?style=flat-square	https://chrome.google.com/webstore/detail/pakku/jklfcpboamajpiikgkbjcnnnnooefbhh
Chrome Web Store - Downloads	https://img.shields.io/chrome-web-store/d/jklfcpboamajpiikgkbjcnnnnooefbhh.svg?style=flat-square	https://chrome.google.com/webstore/detail/pakku/jklfcpboamajpiikgkbjcnnnnooefbhh
Chrome Web Store - Rating	https://img.shields.io/chrome-web-store/rating/jklfcpboamajpiikgkbjcnnnnooefbhh.svg?style=flat-square	https://chrome.google.com/webstore/detail/pakku/jklfcpboamajpiikgkbjcnnnnooefbhh
Mozilla Add-on - Version	https://img.shields.io/amo/v/pakkujs.svg?style=flat-square	https://addons.mozilla.org/zh-CN/firefox/addon/pakkujs?src=external-shield
Mozilla Add-on - Downloads	https://img.shields.io/amo/users/pakkujs.svg?style=flat-square	https://addons.mozilla.org/zh-CN/firefox/addon/pakkujs?src=external-shield
Mozilla Add-on - Rating	https://img.shields.io/amo/rating/pakkujs.svg?style=flat-square	https://addons.mozilla.org/zh-CN/firefox/addon/pakkujs?src=external-shield
