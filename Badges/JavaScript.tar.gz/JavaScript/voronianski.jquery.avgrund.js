Libscore Badge	http://img.shields.io/badge/libscore-34-brightgreen.svg?style=flat-square	http://libscore.com/#$.fn.avgrund
Bitdeli Badge	https://d2weczhvl823v0.cloudfront.net/voronianski/jquery.avgrund.js/trend.png	https://bitdeli.com/free
