Build Status	https://travis-ci.org/asmcrypto/asmcrypto.js.svg?branch=master	https://travis-ci.org/asmcrypto/asmcrypto.js
Join the chat at https://gitter.im/asmcrypto/asmcrypto.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/asmcrypto/asmcrypto.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
