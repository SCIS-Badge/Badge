Emergence.js - detect element visibility in the browser	https://xtianmiller.github.io/emergence.js/dist/images/emergence-title.png#2	https://xtianmiller.github.io/emergence.js
Emergence.js - detect element visibility in the browser	https://xtianmiller.github.io/emergence.js/dist/images/emergence-hero.png#2	https://xtianmiller.github.io/emergence.js
License: MIT	https://img.shields.io/badge/license-MIT-00ddd0.svg	https://opensource.org/licenses/MIT
NPM version	https://img.shields.io/badge/npm-v1.1.2-00ddd0.svg	https://www.npmjs.com/package/emergence.js
CDNJS version	https://img.shields.io/cdnjs/v/emergence.js.svg	https://cdnjs.com/libraries/emergence.js
