npm version	https://badge.fury.io/js/photoshop.d.ts.svg	http://badge.fury.io/js/photoshop.d.ts
Build Status	https://travis-ci.org/felixSchl/photoshop.d.ts.svg	https://travis-ci.org/felixSchl/photoshop.d.ts
