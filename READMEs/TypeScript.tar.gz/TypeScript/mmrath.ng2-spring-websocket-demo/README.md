# ng2-spring-websocket-demo
Demo Application for Spring Boot, WebSocket and Angular2

Source code for blog post: 
http://mmrath.com/post/websockets-with-angular2-and-spring-boot/
