Build Status	https://travis-ci.org/voronkovich/gitignore.plugin.zsh.svg?branch=master	https://travis-ci.org/voronkovich/gitignore.plugin.zsh
