GitHub repo	https://img.shields.io/badge/Repo-GitHub-yellow.svg	https://github.com/cytoscape/cytoscape.js
Twitter updates	https://img.shields.io/badge/Updates-Twitter-yellow.svg	https://twitter.com/cytoscapejs
News and tutorials	https://img.shields.io/badge/News%20and%20tutorials-Blog-yellow.svg	https://blog.js.cytoscape.org
Questions at StackOverflow	https://img.shields.io/badge/Questions-StackOverflow-yellow.svg	https://stackoverflow.com/questions/tagged/cytoscape.js
Ask a question at StackOverflow	https://img.shields.io/badge/Ask%20a%20question-StackOverflow-yellow.svg	https://stackoverflow.com/questions/ask?tags=cytoscape.js,javascript
GitHub license	https://img.shields.io/badge/License-MIT-blue.svg	https://raw.githubusercontent.com/cytoscape/cytoscape.js/master/LICENSE
DOI	https://zenodo.org/badge/2255947.svg	https://zenodo.org/badge/latestdoi/2255947
Cite	https://img.shields.io/badge/Cite-Oxford%20Bioinformatics%20Article-blue.svg	https://js.cytoscape.org/#introduction/citation
npm	https://img.shields.io/npm/v/cytoscape.svg	https://www.npmjs.com/package/cytoscape
Download	https://img.shields.io/npm/v/cytoscape.svg?label=Download	https://github.com/cytoscape/cytoscape.js/tree/master/dist
Extensions	https://img.shields.io/badge/Extensions-60-blue.svg	https://js.cytoscape.org/#extensions
npm installs	https://img.shields.io/npm/dm/cytoscape.svg?label=npm%20installs	https://www.npmjs.com/package/cytoscape
master branch tests	https://img.shields.io/travis/cytoscape/cytoscape.js/master.svg?label=master%20branch	https://travis-ci.org/cytoscape/cytoscape.js
unstable branch tests	https://img.shields.io/travis/cytoscape/cytoscape.js/unstable.svg?label=unstable%20branch	https://travis-ci.org/cytoscape/cytoscape.js
Greenkeeper badge	https://badges.greenkeeper.io/cytoscape/cytoscape.js.svg	https://greenkeeper.io/
