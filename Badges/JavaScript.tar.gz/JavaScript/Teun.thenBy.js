NPM Version	https://img.shields.io/npm/v/thenby.svg	https://npmjs.org/package/thenby
NPM Downloads	https://img.shields.io/npm/dm/thenby.svg	https://npmjs.org/package/thenby
