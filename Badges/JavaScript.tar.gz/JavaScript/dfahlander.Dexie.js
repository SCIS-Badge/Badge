NPM Version	https://img.shields.io/npm/v/dexie.svg?style=flat	https://npmjs.org/package/dexie
Build Status	https://travis-ci.com/dfahlander/Dexie.js.svg?branch=master	https://travis-ci.com/dfahlander/Dexie.js
Tested with Browserstack	http://dexie.org/assets/images/tested-with-browserstack2.png	https://www.browserstack.com
