NPM	https://nodei.co/npm/autocomplete-js.png?compact=true	https://nodei.co/npm/autocomplete-js/
NPM	https://nodei.co/npm-dl/autocomplete-js.png	https://nodei.co/npm/autocomplete-js/
Build Status	https://travis-ci.org/autocompletejs/autocomplete.js.svg?branch=v2.7.0&style=flat-quared	https://travis-ci.org/autocompletejs/autocomplete.js
License MIT	https://img.shields.io/dub/l/vibe-d.svg?maxAge=2592000&style=flat-quared	https://github.com/autocompletejs/autocomplete.js/blob/v2.7.0/LICENCE.md
