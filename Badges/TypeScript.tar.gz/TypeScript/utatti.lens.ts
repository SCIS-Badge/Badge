travis-ci	https://travis-ci.org/utatti/lens.ts.svg?branch=master	https://travis-ci.org/utatti/lens.ts
