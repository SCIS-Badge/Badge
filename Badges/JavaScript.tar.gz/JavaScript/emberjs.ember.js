npm version	https://img.shields.io/npm/v/ember-source.svg?style=flat	https://www.npmjs.com/package/ember-source
CI Status	https://github.com/emberjs/ember.js/workflows/CI/badge.svg	https://github.com/emberjs/ember.js/actions?query=workflow%3ACI
Code Climate	https://codeclimate.com/github/emberjs/ember.js.svg	https://codeclimate.com/github/emberjs/ember.js
Discord Community Server	https://img.shields.io/discord/480462759797063690.svg?logo=discord	https://discord.gg/zT3asNS
PRs Welcome	https://img.shields.io/badge/PRs-welcome-brightgreen.svg	https://help-wanted.emberjs.com/
GitHub license	https://img.shields.io/badge/license-MIT-blue.svg	https://github.com/emberjs/ember.js/blob/master/LICENSE
