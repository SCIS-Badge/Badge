openflow-openwrt
================

This is the OpenFlow 1.3 software switch package for OpenWRT. It includes generic configuration 
files that will be used when building the OpenWrt image.

This files are based on OpenFlow 1.0 for OpenWRT[1]. 

For build instructions check the ofsoftwitch 13 wiki page.
https://github.com/CPqD/ofsoftswitch13/wiki/OpenFlow-1.3-for-OpenWRT



References:
[1]-[Pantou](http://www.openflow.org/wk/index.php/Pantou_:_OpenFlow_1.0_for_OpenWRT)
