Auto-generated docs	https://img.shields.io/badge/ReadTheDocs-reference-informational.svg	http://pyota.readthedocs.io/en/latest/?badge=latest
Discord	https://img.shields.io/badge/Discord-9cf.svg?logo=discord	https://discord.iota.org/
StackExchange	https://img.shields.io/badge/StackExchange-9cf.svg?logo=stackexchange	https://iota.stackexchange.com/
MIT license	https://img.shields.io/github/license/iotaledger/iota.py.svg	https://github.com/iotaledger/entangled/blob/develop/LICENSE
Supported IRI API endpoints	https://img.shields.io/badge/Node%20API%20coverage-18/18%20commands-green.svg	https://docs.iota.org/docs/node-software/0.1/iri/references/api-reference
Build status	https://travis-ci.org/iotaledger/iota.py.svg?branch=master	https://travis-ci.org/iotaledger/iota.py
