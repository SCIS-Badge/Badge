OCL.js	https://raw.githubusercontent.com/stekoe/ocl.js/main/logo.png	https://ocl.stekoe.de
Travis Status	https://img.shields.io/travis/SteKoe/ocl.js/main.svg	https://travis-ci.org/SteKoe/ocl.js
devDependency Status	https://david-dm.org/SteKoe/ocl.js/dev-status.svg	https://david-dm.org/SteKoe/ocl.js#info=devDependencies
License: MIT	https://img.shields.io/github/license/mashape/apistatus.svg	https://github.com/SteKoe/ocl.js
npm (scoped)	https://img.shields.io/npm/v/@stekoe/ocl.js.svg	https://www.npmjs.com/package/@stekoe/ocl.js
