CircleCI	https://circleci.com/gh/blueberryapps/vcr.js.svg?style=svg	https://circleci.com/gh/blueberryapps/vcr.js
Dependency Status	https://dependencyci.com/github/blueberryapps/vcr.js/badge	https://dependencyci.com/github/blueberryapps/vcr.js
