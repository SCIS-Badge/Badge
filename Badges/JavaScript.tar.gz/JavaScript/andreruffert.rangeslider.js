Build Status	https://travis-ci.org/andreruffert/rangeslider.js.svg?branch=develop	https://travis-ci.org/andreruffert/rangeslider.js
jsDelivr Hits	https://data.jsdelivr.com/v1/package/npm/rangeslider.js/badge?style=rounded	https://www.jsdelivr.com/package/npm/rangeslider.js
npm downloads	https://img.shields.io/npm/dt/rangeslider.js.svg	https://www.npmjs.com/package/rangeslider.js
npm version	https://img.shields.io/npm/v/rangeslider.js.svg	https://www.npmjs.com/package/rangeslider.js
rangeslider.js	https://img.shields.io/badge/rangeslider-.js-00ff00.svg	http://rangeslider.js.org
Gitter	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/andreruffert/rangeslider.js
JS.ORG	https://img.shields.io/badge/js.org-rangeslider-ffb400.svg?style=flat-square	http://js.org
