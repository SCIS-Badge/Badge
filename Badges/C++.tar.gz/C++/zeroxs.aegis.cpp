Build Status	https://travis-ci.org/zeroxs/aegis.cpp.svg?branch=master	https://travis-ci.org/zeroxs/aegis.cpp
Discord	https://discordapp.com/api/guilds/287048029524066334/widget.png	https://discord.gg/w7Y3Bb8
License	https://img.shields.io/badge/license-MIT-blue.svg	https://github.com/zeroxs/aegis.cpp/blob/master/LICENSE
