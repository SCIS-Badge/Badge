Twig cache extension
====================

This extension is not maintained anymore. Please use
https://github.com/twigphp/cache-extra instead.

Documentation: https://twig.symfony.com/cache
