Build Status	https://travis-ci.org/crabbly/Print.js.svg?branch=master	https://travis-ci.org/crabbly/Print.js
Software License	https://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat	LICENSE
Standard - JavaScript Style Guide	https://img.shields.io/badge/code_style-standard-brightgreen.svg	http://standardjs.com/
npm	https://img.shields.io/npm/v/print-js.svg	https://www.npmjs.com/package/print-js
devDependencies Status	https://david-dm.org/crabbly/print.js/dev-status.svg	https://david-dm.org/crabbly/print.js?type=dev
dependencies Status	https://david-dm.org/crabbly/print.js/status.svg	https://david-dm.org/crabbly/print.js
