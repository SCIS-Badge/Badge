serverless	http://public.serverless.com/badges/v3.svg	https://www.serverless.com
Financial Contributors on Open Collective	https://opencollective.com/serverless-nextjs-plugin/all/badge.svg?label=backers	https://opencollective.com/serverless-nextjs-plugin
npm latest	https://badgen.net/npm/v/@sls-next/serverless-component/latest	https://www.npmjs.com/package/@sls-next/serverless-component?activeTab=versions
npm alpha	https://badgen.net/npm/v/@sls-next/serverless-component/alpha	https://www.npmjs.com/package/@sls-next/serverless-component?activeTab=versions
Codacy Badge	https://app.codacy.com/project/badge/Grade/c0d3aa2a86cb4ce98772a02015f46314	https://www.codacy.com/manual/danielcondemarin/serverless-nextjs/dashboard?utm_source=github.com&utm_medium=referral&utm_content=serverless-nextjs/serverless-next.js&utm_campaign=Badge_Grade
codecov	https://codecov.io/gh/serverless-nextjs/serverless-next.js/branch/master/graph/badge.svg	https://codecov.io/gh/serverless-nextjs/serverless-next.js
Cypress.io	https://img.shields.io/badge/tested%20with-Cypress-04C38E.svg	https://www.cypress.io/
