Version	https://img.shields.io/npm/v/oimo.svg	https://www.npmjs.com/package/oimo
Version	https://img.shields.io/cdnjs/v/oimo.svg	https://cdnjs.com/libraries/oimo
