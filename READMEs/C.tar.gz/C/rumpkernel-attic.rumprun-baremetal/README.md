The contents of the rumprun-baremetal repository have been __MERGED__ into
[rumprun](http://repo.rumpkernel.org/rumprun).  This repository is no longer
being updated!  
