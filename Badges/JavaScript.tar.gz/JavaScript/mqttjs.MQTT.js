codecov	https://codecov.io/gh/mqttjs/MQTT.js/branch/master/graph/badge.svg	https://codecov.io/gh/mqttjs/MQTT.js
JavaScript Style Guide	https://cdn.rawgit.com/feross/standard/master/badge.svg	https://github.com/feross/standard
