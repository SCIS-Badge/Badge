EGGSML - FROKOSTMANAGEMENT TIL DEN MODERNE ENTERPRISE
=====================================================

[![GitHub issues](https://img.shields.io/github/issues/Athas/EggsML.svg)](https://github.com/Athas/EggsML/issues)

For dokumentation: `find . -type f -exec cat {} \;`


BEGÅET AF
---------

Mest Brainfuck, Lindbo og Dybber.


FORBEDRET AF
------------

Mest Troels, Niels, Sebastian, Mikkel, Brandt, sshine, sword-smith og jer, vi har glemt :heart:
