## Buddy Memory Allocation

A simple buddy memory allocation library .

See test.c for detail use.

## Question ?

* Send me an email : http://www.codingnow.com/2000/gmail.gif
* My Blog : http://blog.codingnow.com
* http://blog.codingnow.com/2011/12/buddy_memory_allocation.html (in Chinese)
