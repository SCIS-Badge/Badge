Build Status	https://travis-ci.org/rumpkernel/buildrump.sh.png?branch=master	https://travis-ci.org/rumpkernel/buildrump.sh
