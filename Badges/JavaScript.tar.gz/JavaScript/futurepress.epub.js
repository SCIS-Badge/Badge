Gitter Chat	https://badges.gitter.im/futurepress/epub.js.png	https://gitter.im/futurepress/epub.js
