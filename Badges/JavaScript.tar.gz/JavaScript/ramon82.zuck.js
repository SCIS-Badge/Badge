Zuck.JS demo	https://raw.githubusercontent.com/ramon82/assets/master/zuck.js/preview.gif	https://on.ramon82.com/2k9e7au
CDNJS	https://img.shields.io/cdnjs/v/zuck.js.svg?colorA=333333&colorB=D32F2F&style=flat-square&maxAge=3600	https://cdnjs.com/libraries/zuck.js
NPM	https://img.shields.io/npm/v/zuck.js.svg?colorA=333333&colorB=D32F2F&style=flat-square&maxAge=3600	https://www.npmjs.com/package/zuck.js
ko-fi	https://www.ko-fi.com/img/githubbutton_sm.svg	https://ko-fi.com/F1F710G8L
