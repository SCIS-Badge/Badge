Code Climate	https://codeclimate.com/github/fbrandel/ParisHilton.js.png	https://codeclimate.com/github/fbrandel/ParisHilton.js
