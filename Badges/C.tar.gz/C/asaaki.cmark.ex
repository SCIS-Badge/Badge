Hex.pm package version	https://img.shields.io/hexpm/v/cmark.svg?style=flat-square	https://hex.pm/packages/cmark
Hex.pm package docs	https://img.shields.io/badge/hex-docs-orange.svg?style=flat-square	http://hexdocs.pm/cmark/
Hex.pm package license	https://img.shields.io/hexpm/l/cmark.svg?style=flat-square	https://github.com/asaaki/cmark.ex/blob/main/LICENSE
GitHub Workflow Status	https://img.shields.io/github/workflow/status/asaaki/cmark.ex/CI?style=flat-square	https://github.com/asaaki/cmark.ex/actions?query=workflow%3ACI
Coverage Status (main)	https://img.shields.io/coveralls/asaaki/cmark.ex/main.svg?style=flat-square	https://coveralls.io/r/asaaki/cmark.ex
Inline docs	http://inch-ci.org/github/asaaki/cmark.ex.svg?branch=main&style=flat-square	http://inch-ci.org/github/asaaki/cmark.ex
