Build Status	https://travis-ci.org/jakubfiala/atrament.js.svg?branch=master	https://travis-ci.org/jakubfiala/atrament.js
