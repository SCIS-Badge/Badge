# NPP_HexEdit
Notepad++ Plugin Hexedit
unofficial repo with sourcecode from http://sourceforge.net/projects/npp-plugins/files/Hex%20Editor/


Build Status
------------

AppVeyor `VS2017` and `VS2015`  [![Build status](https://ci.appveyor.com/api/projects/status/x8j5dnfur93n6six?svg=true)](https://ci.appveyor.com/project/chcg/npp-hexedit)

Further repos at github:
- https://github.com/JetNpp/HexEditor
- https://github.com/darkdragon-001/NPP-Plugins-HexEditor
- https://github.com/mackwai/NPPHexEditor
