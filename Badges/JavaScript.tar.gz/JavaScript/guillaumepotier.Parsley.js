Build Status	https://travis-ci.org/guillaumepotier/Parsley.js.svg?branch=master	https://travis-ci.org/guillaumepotier/Parsley.js
