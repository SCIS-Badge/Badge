travis build	https://travis-ci.org/daniel-lundin/snabbt.js.svg?branch=es6	https://travis-ci.org/daniel-lundin/snabbt.js/builds/
npm version	https://badge.fury.io/js/snabbt.js.svg	https://badge.fury.io/js/snabbt.js
