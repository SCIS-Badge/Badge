Build Status	https://travis-ci.org/rubensworks/graphql-to-sparql.js.svg?branch=master	https://travis-ci.org/rubensworks/graphql-to-sparql.js
Coverage Status	https://coveralls.io/repos/github/rubensworks/graphql-to-sparql.js/badge.svg?branch=master	https://coveralls.io/github/rubensworks/graphql-to-sparql.js?branch=master
npm version	https://badge.fury.io/js/graphql-to-sparql.svg	https://www.npmjs.com/package/graphql-to-sparql
