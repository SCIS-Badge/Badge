Build Status	https://travis-ci.org/jtrussell/angular-snap.js.png?branch=master	https://travis-ci.org/jtrussell/angular-snap.js
