CuckooMon
=========

This repository is old and has been deprecated in favor of the new
[Cuckoo Monitor][mon].

[mon]: https://github.com/cuckoobox/monitor
