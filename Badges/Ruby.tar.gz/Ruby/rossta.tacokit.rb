Build Status	https://travis-ci.org/rossta/tacokit.rb.svg?branch=master	https://travis-ci.org/rossta/tacokit.rb
Code Climate	https://codeclimate.com/github/rossta/tacokit.rb/badges/gpa.svg	https://codeclimate.com/github/rossta/tacokit.rb
Dependency Status	https://gemnasium.com/rossta/tacokit.rb.svg	https://gemnasium.com/rossta/tacokit.rb
Coverage Status	https://coveralls.io/repos/rossta/tacokit.rb/badge.svg	https://coveralls.io/r/rossta/tacokit.rb
