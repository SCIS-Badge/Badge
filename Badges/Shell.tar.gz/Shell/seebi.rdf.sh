Build Status	https://travis-ci.org/seebi/rdf.sh.svg?branch=develop	https://travis-ci.org/seebi/rdf.sh
