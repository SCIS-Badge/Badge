Build Status	https://secure.travis-ci.org/fjakobs/async.js.png	http://travis-ci.org/fjakobs/async.js
