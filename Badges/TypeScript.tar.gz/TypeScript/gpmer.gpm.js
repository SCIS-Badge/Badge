Greenkeeper badge	https://badges.greenkeeper.io/gpmer/gpm.js.svg	https://greenkeeper.io/
Build Status	https://travis-ci.org/gpmer/gpm.js.svg?branch=master	https://travis-ci.org/gpmer/gpm.js
Dependency	https://david-dm.org/gpmer/gpm.js.svg	https://david-dm.org/gpmer/gpm.js
Prettier	https://img.shields.io/badge/Code%20Style-Prettier-green.svg	https://github.com/prettier/prettier
npm version	https://badge.fury.io/js/%40axetroy%2Fgpm.svg	https://badge.fury.io/js/%40axetroy%2Fgpm
