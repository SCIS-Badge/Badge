Build Status	https://travis-ci.org/flowjs/flow.js.svg	https://travis-ci.org/flowjs/flow.js
Test Coverage	https://codeclimate.com/github/flowjs/flow.js/badges/coverage.svg	https://codeclimate.com/github/flowjs/flow.js/coverage
Saucelabs Test Status	https://saucelabs.com/browser-matrix/flowjs.svg	https://saucelabs.com/u/flowjs
Buy Me A Coffee	https://cdn.buymeacoffee.com/buttons/default-orange.png	https://www.buymeacoffee.com/aidas
