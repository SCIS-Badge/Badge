Bricks.js on NPM	https://img.shields.io/npm/v/bricks.js.svg?style=flat-square	https://www.npmjs.com/package/bricks.js
Bricks.js Downloads on NPM	https://img.shields.io/npm/dm/bricks.js.svg?style=flat-square	https://www.npmjs.com/package/bricks.js
Standard JavaScript Style	https://img.shields.io/badge/code_style-standard-brightgreen.svg?style=flat-square	http://standardjs.com/
Built With Love	http://forthebadge.com/images/badges/built-with-love.svg	http://forthebadge.com
