Build Status	https://img.shields.io/travis/shopjs/shop.js.svg	https://travis-ci.org/shopjs/shop.js
NPM version	https://img.shields.io/npm/v/shop.js.svg	https://www.npmjs.com/package/shop.js
Gitter chat	https://img.shields.io/badge/gitter-join_chat-brightgreen.svg	https://gitter.im/shopjs/community
