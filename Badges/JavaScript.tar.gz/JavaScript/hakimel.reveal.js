reveal.js	https://hakim-static.s3.amazonaws.com/reveal-js/logo/v1/reveal-black-text.svg	https://revealjs.com
Slides	https://s3.amazonaws.com/static.slid.es/images/slides-github-banner-320x40.png?1	https://slides.com/
