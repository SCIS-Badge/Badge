Status	https://img.shields.io/badge/status-active-success.svg	#
Build	https://travis-ci.org/sh-dv/hat.sh.svg?branch=master	https://travis-ci.org/sh-dv/hat.sh
License: MIT	https://img.shields.io/badge/license-MIT-blue.svg	#
hat.sh - Free, fast, secure and serverless file encryption | Product Hunt Embed	https://api.producthunt.com/widgets/embed-image/v1/top-post-badge.svg?post_id=157956&theme=dark&period=daily	https://www.producthunt.com/posts/hat-sh?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-hat-sh
hat.sh - Free, fast, secure and serverless file encryption	https://i.imgur.com/Euyd1ap.png	https://www.privacytools.io/software/encryption-tools/
