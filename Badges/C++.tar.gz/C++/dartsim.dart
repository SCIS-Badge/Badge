GitHub Actions Build Status	https://github.com/dartsim/dart/workflows/C%2FC%2B%2B%20CI/badge.svg	https://github.com/dartsim/dart/actions
Build Status	https://travis-ci.org/dartsim/dart.png?branch=master	https://travis-ci.org/dartsim/dart
Build status	https://ci.appveyor.com/api/projects/status/6rta8olo95bpu84r/branch/master?svg=true	https://ci.appveyor.com/project/jslee02/dart/branch/master
codecov	https://codecov.io/gh/dartsim/dart/branch/master/graph/badge.svg	https://codecov.io/gh/dartsim/dart
Codacy Badge	https://api.codacy.com/project/badge/Grade/1251beff30164eb7ba60a1cc9e6daef9	https://www.codacy.com/app/jslee02/dart?utm_source=github.com&utm_medium=referral&utm_content=dartsim/dart&utm_campaign=Badge_Grade
DOI	http://joss.theoj.org/papers/10.21105/joss.00500/status.svg	https://doi.org/10.21105/joss.00500
