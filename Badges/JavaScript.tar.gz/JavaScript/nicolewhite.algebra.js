Build Status	https://travis-ci.org/nicolewhite/algebra.js.svg?branch=master	https://travis-ci.org/nicolewhite/algebra.js
Coverage Status	https://coveralls.io/repos/nicolewhite/algebra.js/badge.svg?branch=master	https://coveralls.io/r/nicolewhite/algebra.js?branch=master
npm version	https://badge.fury.io/js/algebra.js.svg	http://badge.fury.io/js/algebra.js
Join the chat at https://gitter.im/nicolewhite/algebra.js	https://badges.gitter.im/Join%20Chat.svg	https://gitter.im/nicolewhite/algebra.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
