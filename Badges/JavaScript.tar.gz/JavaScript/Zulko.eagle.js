npm version	https://badge.fury.io/js/eagle.js.svg	https://badge.fury.io/js/eagle.js
Build Status	https://travis-ci.org/Zulko/eagle.js.svg?branch=master	https://travis-ci.org/Zulko/eagle.js
screenshot	https://raw.githubusercontent.com/Zulko/eagle.js/master/img/screenshot.jpg	https://zulko.github.io/eaglejs-demo/#/introducing-eagle
