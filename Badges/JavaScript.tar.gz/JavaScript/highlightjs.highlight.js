beta	https://badgen.net/npm/v/highlight.js/beta	https://www.npmjs.com/package/highlight.js
slack	https://badgen.net/badge/icon/slack?icon=slack&label&color=pink	https://join.slack.com/t/highlightjs/shared_invite/zt-k1f72n07-dUsqwCYtNPz7laRm7mBCTg
jsDelivr CDN downloads	https://badgen.net/jsdelivr/hits/gh/highlightjs/cdn-release?label=jsDelivr+CDN&color=purple	https://www.jsdelivr.com/package/gh/highlightjs/cdn-release
code quality	https://badgen.net/lgtm/grade/g/highlightjs/highlight.js/js	https://lgtm.com/projects/g/highlightjs/highlight.js/?mode=list
help welcome issues	https://badgen.net/github/label-issues/highlightjs/highlight.js/help%20welcome/open	https://github.com/highlightjs/highlight.js/issues?q=is%3Aopen+is%3Aissue+label%3A%22help+welcome%22
good first issue	https://badgen.net/github/label-issues/highlightjs/highlight.js/good%20first%20issue/open	https://github.com/highlightjs/highlight.js/issues?q=is%3Aopen+is%3Aissue+label%3A%22beginner+friendly%22
