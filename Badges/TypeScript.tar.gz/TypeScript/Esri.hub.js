npm version	https://img.shields.io/npm/v/@esri/hub-initiatives.svg?style=flat-square	https://www.npmjs.com/package/@esri/hub-initiatives
build status	https://img.shields.io/travis/Esri/hub.js/master.svg?style=flat-square	https://travis-ci.org/Esri/hub.js
Coverage Status	https://codecov.io/gh/Esri/hub.js/branch/master/graph/badge.svg	https://codecov.io/gh/Esri/hub.js
apache licensed	https://img.shields.io/badge/license-Apache%202.0-orange.svg?style=flat-square	#license
