# Bone.io: Realtime HTML5 Framework

<a href="http://bone.io"><img align="right" src="http://bone.io/static/img/skeleton-no-shirt-21fba8a2563ed3c11031360301701e9d.png"></a>

### Documentation

Visit the [bone.io](http://bone.io) website for docs.

### Support / Contributing

We accept pull requests, bug fixes, and suggestions.

### Questions

Create a github issue and add a label of "question".
