<h1 align="center">
  <img src="./website/static/img/wix-logo.png" height="80" />
  <img src="./website/static/img/underscope-logo.png" height="80" />
  <br/>
  React Native Navigation Hooks
</h1>

[![version](https://img.shields.io/npm/v/react-native-navigation-hooks.svg)](https://www.npmjs.com/package/react-native-navigation-hooks)
[![minzipped size](https://img.shields.io/bundlephobia/minzip/react-native-navigation-hooks.svg)](https://www.npmjs.com/package/react-native-navigation-hooks)
[![downloads](https://img.shields.io/npm/dt/react-native-navigation-hooks.svg)](https://www.npmjs.com/package/react-native-navigation-hooks)
[![codecov](https://codecov.io/gh/underscopeio/react-native-navigation-hooks/branch/master/graph/badge.svg)](https://codecov.io/gh/underscopeio/react-native-navigation-hooks)
[![Tweet](https://img.shields.io/twitter/url/http/shields.io.svg?style=social)](https://twitter.com/intent/tweet?text=React%20Native%20Navigation%20Hooks!&url=https://github.com/underscopeio/react-native-navigation-hooks&via=underscopeio&hashtags=react,reactjs,reactnative,javascript,hooks,reactnativenavigation)

A set of React hooks for React Native Navigation [docs](https://underscopeio.github.io/react-native-navigation-hooks/).

# Quick Links

- [Documentation](https://underscopeio.github.io/react-native-navigation-hooks/)
- [Changelog](https://github.com/underscopeio/react-native-navigation-hooks/blob/master/CHANGELOG.md)
- [Stack Overflow](http://stackoverflow.com/questions/tagged/react-native-navigation-hooks)

# Installation

Follow the installation guides in the [documentation](https://underscopeio.github.io/react-native-navigation-hooks/).
