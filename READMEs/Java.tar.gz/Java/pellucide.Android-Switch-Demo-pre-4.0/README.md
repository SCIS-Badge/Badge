Android 4.0 added a new widget called "Switch" that acts like a switch with two states(On and Off). This project back-ported the code to Android 2.2.2(API 8).
This project adds a few other features. The screen shot shows some examples of the features

##The related discussion on stackoverflow.
http://stackoverflow.com/questions/9752760/slide-toggle-for-android


![Screenshot] (https://raw.github.com/pellucide/Android-Switch-Demo-pre-4.0/master/android-switch-demo/Screenshot.png)