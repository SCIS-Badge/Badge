Build Status	https://api.travis-ci.org/SlexAxton/yepnope.js.svg?branch=master	https://travis-ci.org/SlexAxton/yepnope.js
