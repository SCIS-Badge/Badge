npm	https://img.shields.io/npm/v/remotestoragejs.svg	https://www.npmjs.com/package/remotestoragejs
Build Status	http://img.shields.io/travis/remotestorage/remotestorage.js.svg?style=flat	http://travis-ci.org/remotestorage/remotestorage.js
Dependency Status	http://img.shields.io/david/remotestorage/remotestorage.js.svg?style=flat	https://david-dm.org/remotestorage/remotestorage.js#info=dependencies
devDependency Status	http://img.shields.io/david/dev/remotestorage/remotestorage.js.svg?style=flat	https://david-dm.org/remotestorage/remotestorage.js#info=devDependencies
NLnet Logo	http://sockethub.org/res/img/nlnet-logo.svg	https://nlnet.nl
