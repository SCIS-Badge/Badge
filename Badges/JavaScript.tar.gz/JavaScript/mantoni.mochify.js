Mochify	header.png	https://github.com/mantoni/mochify.js/
Build	https://github.com/mantoni/mochify.js/actions/workflows/test.yml/badge.svg	https://github.com/mantoni/mochify.js/actions/workflows/test.yml
SemVer	http://img.shields.io/:semver-%E2%9C%93-brightgreen.svg	http://semver.org
License	http://img.shields.io/npm/l/mochify.svg	https://github.com/mantoni/mochify.js/blob/master/LICENSE
