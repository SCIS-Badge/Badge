CircleCI	https://circleci.com/gh/Dash-Industry-Forum/dash.js/tree/development.svg?style=svg	https://circleci.com/gh/Dash-Industry-Forum/dash.js/tree/development
Browser Stack Logo	https://cloud.githubusercontent.com/assets/7864462/12837037/452a17c6-cb73-11e5-9f39-fc96893bc9bf.png	https://www.browserstack.com/
