Dependency Status	https://david-dm.org/fent/randexp.js.svg	https://david-dm.org/fent/randexp.js
codecov	https://codecov.io/gh/fent/randexp.js/branch/master/graph/badge.svg	https://codecov.io/gh/fent/randexp.js
