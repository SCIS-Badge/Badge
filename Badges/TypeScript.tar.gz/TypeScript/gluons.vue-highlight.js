license	https://img.shields.io/github/license/gluons/vue-highlight.js.svg?style=flat-square	https://github.com/gluons/vue-highlight.js/blob/master/LICENSE
vue 2	https://img.shields.io/badge/vue-2-42b983.svg?style=flat-square	https://vuejs.org
npm	https://img.shields.io/npm/v/vue-highlight.js.svg?style=flat-square	https://www.npmjs.com/package/vue-highlight.js
npm	https://img.shields.io/npm/dt/vue-highlight.js.svg?style=flat-square	https://www.npmjs.com/package/vue-highlight.js
Travis	https://img.shields.io/travis/gluons/vue-highlight.js.svg?style=flat-square	https://travis-ci.org/gluons/vue-highlight.js
Codacy grade	https://img.shields.io/codacy/grade/3d15a7c11bfe47c69a2aed93cc67cc29.svg?style=flat-square	https://www.codacy.com/app/gluons/vue-highlight.js
TSLint	https://img.shields.io/badge/TSLint-gluons-15757B.svg?style=flat-square	https://github.com/gluons/tslint-config-gluons
npm	https://nodei.co/npm/vue-highlight.js.png?downloads=true&downloadRank=true&stars=true	https://www.npmjs.com/package/vue-highlight.js
