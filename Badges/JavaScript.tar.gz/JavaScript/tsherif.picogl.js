GZIP size	https://badge-size.herokuapp.com/tsherif/picogl.js/master/build/picogl.min.js.svg?compression=gzip	https://github.com/tsherif/picogl.js/blob/master/build/picogl.min.js
Gitter	https://img.shields.io/gitter/room/picogl.js/general.svg	https://gitter.im/picogl-js/general
License	https://img.shields.io/github/license/tsherif/picogl.js.svg	https://github.com/tsherif/picogl.js/blob/master/LICENSE
NPM	https://img.shields.io/npm/v/picogl.svg	https://www.npmjs.com/package/picogl
