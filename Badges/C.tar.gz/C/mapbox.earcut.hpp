Travis	https://img.shields.io/travis/mapbox/earcut.hpp.svg	https://travis-ci.org/mapbox/earcut.hpp
AppVeyor	https://ci.appveyor.com/api/projects/status/a1ysrqd69mqn7coo/branch/master?svg=true	https://ci.appveyor.com/project/Mapbox/earcut-hpp-8wm4o/branch/master
Coverage	https://img.shields.io/coveralls/github/mapbox/earcut.hpp.svg	https://coveralls.io/github/mapbox/earcut.hpp
Coverity Scan	https://img.shields.io/coverity/scan/14000.svg	https://scan.coverity.com/projects/14000
Average time to resolve an issue	http://isitmaintained.com/badge/resolution/mapbox/earcut.hpp.svg	http://isitmaintained.com/project/mapbox/earcut.hpp
Percentage of issues still open	http://isitmaintained.com/badge/open/mapbox/earcut.hpp.svg	http://isitmaintained.com/project/mapbox/earcut.hpp
Mourner	https://img.shields.io/badge/simply-awesome-brightgreen.svg	https://github.com/mourner/projects
