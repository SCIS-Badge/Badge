Build Status	https://img.shields.io/travis/Nickersoft/push.js.svg	https://travis-ci.org/Nickersoft/push.js
Coverage Status	https://img.shields.io/coveralls/Nickersoft/push.js.svg	https://coveralls.io/github/Nickersoft/push.js?branch=master
Known Vulnerabilities	https://snyk.io/test/github/nickersoft/push.js/badge.svg	https://snyk.io/test/github/nickersoft/push.js
Maintainability	https://api.codeclimate.com/v1/badges/52747084d9786c1570df/maintainability	https://codeclimate.com/github/Nickersoft/push.js/maintainability
npm version	https://img.shields.io/npm/v/push.js.svg	https://npmjs.com/package/push.js
npm	https://img.shields.io/npm/dm/push.js.svg	https://npmjs.com/package/push.js
Greenkeeper badge	https://badges.greenkeeper.io/Nickersoft/push.js.svg	https://greenkeeper.io/
