Build Status	https://travis-ci.org/gumroad/countdown.js.png	https://travis-ci.org/gumroad/countdown.js
