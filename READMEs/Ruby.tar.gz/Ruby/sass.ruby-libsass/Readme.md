Ruby-Libsass (DEPRECATED)
=======

Please use sassc-ruby instead!

Written by Hampton Catlin

*THIS IS NOT THE ORIGINAL RUBY VERSION OF SASS*

About
-----

This is a Ruby wrapper around the libsass project. The goal
of this project is to provide an act-alike to the original Sass
project. Where "alias SassC Sass" would provide a drop-in
replacement. This is an ambitious goal, but hopefully we can 
attain it.

Setup
-----

    git submodule init
    git submodule update


