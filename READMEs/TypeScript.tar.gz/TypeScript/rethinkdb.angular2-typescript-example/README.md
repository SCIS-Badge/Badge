# Angular 2 Demo Application

This RethinkDB chat demo is written in Typescript. It includes a Node.js backend that uses the Koa framework and a single-page frontend written with an Angular 2 beta release. It uses RethinkDB changefeeds and Socket.io to propagate realtime updates from the backend to the frontend.