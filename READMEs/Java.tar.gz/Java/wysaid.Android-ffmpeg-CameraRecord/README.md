# 简介 #

New - A better version: [android-gpuimage-plus](https://github.com/wysaid/android-gpuimage-plus)

安卓下实现的 实时相机滤镜显示 + 拍照 + 处理结果视频音频录制 demo (需要 javacv, 已配置好)

## 截屏 ##

<img src="https://raw.githubusercontent.com/wysaid/Android-ffmpeg-CameraRecord/master/screenshot/screenshot1.jpg" alt="wysaid">
<img src="https://raw.githubusercontent.com/wysaid/Android-ffmpeg-CameraRecord/master/screenshot/screenshot0.jpg" alt="wysaid">

# 开发中, 功能不全 #

目前仅是demo， 仅供参考， 本repo的代码请随意使用， 我无所谓😋, 当然对你有帮助的地方你要注明一下本人， 我也是非常高兴的。

Just a demo.
