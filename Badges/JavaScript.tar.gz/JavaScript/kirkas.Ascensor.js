Build Status	https://travis-ci.org/kirkas/Ascensor.js.png?branch=master	https://travis-ci.org/kirkas/Ascensor.js
devDependency Status	https://david-dm.org/kirkas/Ascensor.js/dev-status.png	https://david-dm.org/kirkas/Ascensor.js#info=devDependencies
