guino
=====

GUI interface for arduino


UPDATE 27-DEC-2014 (@mentarus):
* Added Linux support       
* Might have issues with ofxUIWaveform as it no longer have an addPoint method

License: CC-NC-BY 2.0

http://creativecommons.org/licenses/by-nc/2.0/
