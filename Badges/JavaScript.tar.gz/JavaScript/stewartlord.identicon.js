CDNJS version	https://img.shields.io/cdnjs/v/identicon.js.svg	https://cdnjs.com/libraries/identicon.js
NPM Stats	https://nodei.co/npm/identicon.js.png?downloads=true	https://npmjs.org/package/identicon.js
