Travis CI	http://travis-ci.org/caiogondim/logdown.js.svg?branch=master	https://travis-ci.org/caiogondim/logdown.js?branch=master
Codecov	https://codecov.io/gh/caiogondim/logdown.js/branch/master/graph/badge.svg	https://codecov.io/gh/caiogondim/logdown.js
npm	https://img.shields.io/npm/v/logdown.svg	https://www.npmjs.com/package/logdown
