Multiple.js on NPM	https://img.shields.io/npm/v/multiple.js.svg	https://www.npmjs.com/package/multiple.js
Multiple.js on Bower	https://img.shields.io/bower/v/multiple.js.svg	http://bower.io/search/?q=multiple.js
Join the chat at https://gitter.im/NeXTs/Multiple.js	https://badges.gitter.im/NeXTs/Multiple.js.svg	https://gitter.im/NeXTs/Multiple.js?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
example	http://nexts.github.io/Multiple.js/dist/images/demo.jpg	http://multiple.js.org/
