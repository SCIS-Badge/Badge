License	https://img.shields.io/badge/License-MIT-brightgreen.svg	https://github.com/apexcharts/apexcharts.js/blob/master/LICENSE
build	https://api.travis-ci.com/apexcharts/apexcharts.js.svg?branch=master	https://travis-ci.com/apexcharts/apexcharts.js
ver	https://img.shields.io/npm/v/apexcharts.svg	https://www.npmjs.com/package/apexcharts
prettier	https://img.shields.io/badge/code_style-prettier-ff69b4.svg?style=flat-square	https://github.com/prettier/prettier
jsdelivr	https://data.jsdelivr.com/v1/package/npm/apexcharts/badge	https://www.jsdelivr.com/package/npm/apexcharts
Firefox	https://raw.githubusercontent.com/alrra/browser-logos/master/src/firefox/firefox_48x48.png	http://godban.github.io/browsers-support-badges/
Chrome	https://raw.githubusercontent.com/alrra/browser-logos/master/src/chrome/chrome_48x48.png	http://godban.github.io/browsers-support-badges/
Safari	https://raw.githubusercontent.com/alrra/browser-logos/master/src/safari/safari_48x48.png	http://godban.github.io/browsers-support-badges/
Edge	https://raw.githubusercontent.com/alrra/browser-logos/master/src/edge/edge_48x48.png	http://godban.github.io/browsers-support-badges/
IE	https://upload.wikimedia.org/wikipedia/commons/1/1b/Internet_Explorer_9_icon.svg	http://godban.github.io/browsers-support-badges/
interactive chart	https://apexcharts.com/media/interactivity.gif	https://codepen.io/apexcharts/pen/QrbEQg
dynamic-loading-chart	https://apexcharts.com/media/dynamic-selection.gif	https://apexcharts.com/javascript-chart-demos/column-charts/dynamic-loaded-chart/
annotations	https://apexcharts.com/media/annotations.png	https://apexcharts.com/docs/annotations/
annotations	https://apexcharts.com/wp-content/uploads/2018/05/line-column-area-mixed-chart.svg	https://apexcharts.com/javascript-chart-demos/mixed-charts/
candlestick	https://apexcharts.com/media/candlestick.png	https://apexcharts.com/javascript-chart-demos/candlestick-charts/
heatmap	https://apexcharts.com/media/heatmap-charts.png	https://apexcharts.com/javascript-chart-demos/heatmap-charts/
radialbar-chart	https://apexcharts.com/media/radialbars-gauges.png	https://apexcharts.com/javascript-chart-demos/radialbar-charts/
sparkline-chart	https://apexcharts.com/media/sparklines.png	https://apexcharts.com/javascript-chart-demos/sparklines/
