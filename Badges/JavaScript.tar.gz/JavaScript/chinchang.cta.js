npm version	https://badge.fury.io/js/cta.svg	http://badge.fury.io/js/cta
