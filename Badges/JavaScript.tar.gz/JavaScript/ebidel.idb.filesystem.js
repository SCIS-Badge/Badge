Demo app screenshot	https://raw.github.com/ebidel/idb.filesystem.js/master/demos/playground/images/demo_screenshot.png	http://html5-demos.appspot.com/static/filesystem/idb.filesystem.js/demos/basic/index.html
Analytics	https://ga-beacon.appspot.com/UA-46812528-1/ebidel/idb.filesystem.js/README	https://github.com/igrigorik/ga-beacon
