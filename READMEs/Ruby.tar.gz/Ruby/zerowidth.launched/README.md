# Launched

A launchd.plist editor.

`launchd` is a powerful and flexible replacement for cron, but writing the plist
files for it by hand can be difficult. This app makes it easier.

YIBYABS: Yes, I Built Yet Another Bootstrap Site!

## Is it any good?

Yes.

## Contributing

* fork
* patch
* test
* pull request

## License

MIT, see `LICENSE`.
