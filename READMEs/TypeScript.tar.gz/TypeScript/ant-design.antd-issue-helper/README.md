# Ant Design Issue Helper

Inspired by https://github.com/vuejs/vue-issue-helper

## Development

```
$ yarn
$ yarn start
```

## Deployment

```
$ yarn deploy
```
