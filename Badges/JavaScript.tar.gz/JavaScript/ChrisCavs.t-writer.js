t-writer.js on NPM	https://img.shields.io/npm/v/t-writer.js.svg?style=flat-square	https://www.npmjs.com/package/t-writer.js
Standard JavaScript Style	https://img.shields.io/badge/code_style-standard-brightgreen.svg?style=flat-square	http://standardjs.com/
