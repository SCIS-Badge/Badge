NPM version	https://img.shields.io/npm/v/ally.js.svg	https://www.npmjs.com/package/ally.js
NPM Downloads	https://img.shields.io/npm/dm/ally.js.svg	https://www.npmjs.com/package/ally.js
MIT License	https://img.shields.io/npm/l/ally.js.svg	https://github.com/medialize/ally.js/blob/master/LICENSE.txt
Travis CI	https://img.shields.io/travis/medialize/ally.js/master.svg	https://travis-ci.org/medialize/ally.js
Code Climate	https://img.shields.io/codeclimate/github/medialize/ally.js.svg	https://codeclimate.com/github/medialize/ally.js
Test coverage	https://img.shields.io/codeclimate/coverage/github/medialize/ally.js.svg	https://codeclimate.com/github/medialize/ally.js/coverage
Dependencies	https://img.shields.io/david/medialize/ally.js.svg	https://www.npmjs.com/package/ally.js
Dev-Dependencies	https://img.shields.io/david/dev/medialize/ally.js.svg	https://www.npmjs.com/package/ally.js
