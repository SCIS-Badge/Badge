solr-fabric
===========

[Fabric](http://www.fabfile.org/) scripts for installing SolrCloud

See [Solr Fabric Guide](./solr-fabric-guide.md)
