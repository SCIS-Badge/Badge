NPM version	https://badge.fury.io/js/rasterizehtml.svg	https://www.npmjs.org/package/rasterizehtml
Build Status	https://travis-ci.org/cburgmer/rasterizeHTML.js.svg?branch=master	https://travis-ci.org/cburgmer/rasterizeHTML.js
