OwnTracks for Android
=======

This is the OwnTracks Android app. 
See our [booklet](http://owntracks.org/booklet/features/android/) for a list of known issues and restrictions. 

![Android CI](https://github.com/owntracks/android/workflows/Android%20CI/badge.svg)

