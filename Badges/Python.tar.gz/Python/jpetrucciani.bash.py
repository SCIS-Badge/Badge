image	https://travis-ci.org/jpetrucciani/bash.py.svg?branch=master	https://travis-ci.org/jpetrucciani/bash.py
PyPI version	https://badge.fury.io/py/bash.py.svg	https://badge.fury.io/py/bash.py
Code style: black	https://img.shields.io/badge/code%20style-black-000000.svg	https://github.com/ambv/black
Python 3.6+ supported	https://img.shields.io/badge/python-3.6+-blue.svg	https://www.python.org/downloads/release/python-360/
