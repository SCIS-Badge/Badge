Support	https://img.shields.io/badge/patreon-support-orange.svg	https://www.patreon.com/user?u=2978551&ty=h&u=2978551
Support	https://img.shields.io/badge/opencollective-donate-red.svg	https://opencollective.com/osjs
Donate	https://img.shields.io/badge/liberapay-donate-yellowgreen.svg	https://liberapay.com/os-js/
Donate	https://img.shields.io/badge/paypal-donate-yellow.svg	https://paypal.me/andersevenrud
Community	https://img.shields.io/badge/join-community-green.svg	https://community.os-js.org/
