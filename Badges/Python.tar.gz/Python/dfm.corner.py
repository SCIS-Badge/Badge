image	http://img.shields.io/travis/dfm/corner.py/master.svg?style=flat	https://travis-ci.org/dfm/corner.py
image	https://coveralls.io/repos/github/dfm/corner.py/badge.svg?branch=master&style=flat	https://coveralls.io/github/dfm/corner.py?branch=master&style=flat
image	http://img.shields.io/badge/license-BSD-blue.svg?style=flat	https://github.com/dfm/corner.py/blob/master/LICENSE
image	https://zenodo.org/badge/4729/dfm/corner.py.svg?style=flat	https://zenodo.org/badge/latestdoi/4729/dfm/corner.py
image	http://joss.theoj.org/papers/10.21105/joss.00024/status.svg?style=flat	http://dx.doi.org/10.21105/joss.00024
