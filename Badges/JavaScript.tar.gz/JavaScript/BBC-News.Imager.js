Build Status	https://secure.travis-ci.org/BBC-News/Imager.js.svg?branch=master	http://travis-ci.org/BBC-News/Imager.js
