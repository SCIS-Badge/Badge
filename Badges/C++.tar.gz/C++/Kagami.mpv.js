mpv	https://i.imgur.com/qQFg0aI.png	https://mpv.io/
Travis	https://img.shields.io/travis/Kagami/mpv.js.svg	https://travis-ci.org/Kagami/mpv.js
NPM	https://img.shields.io/npm/v/mpv.js.svg	https://npmjs.org/package/mpv.js
