Build Status	https://travis-ci.org/justadudewhohacks/face-api.js.svg?branch=master	https://travis-ci.org/justadudewhohacks/face-api.js
Slack	https://slack.bri.im/badge.svg	https://slack.bri.im
