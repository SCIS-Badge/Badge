License	https://img.shields.io/badge/License-GPL-blue.svg	https://www.gnu.org/licenses/gpl-3.0.html
PayPal Donate	https://img.shields.io/badge/donate-PayPal.me-ff69b4.svg	https://www.paypal.me/alvarotrigo/9.95
jsDelivr Hits	https://data.jsdelivr.com/v1/package/npm/fullpage.js/badge?style=rounded	https://www.jsdelivr.com/package/npm/fullpage.js
Google	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/google-4.png	http://www.yourprimer.com/
BBC	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/bbc-4.png	http://www.bbc.co.uk/news/resources/idt-d88680d1-26f2-4863-be95-83298fd01e02
sym	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/sym-5.png	http://www.sanyang.com.tw/service/Conception/
Donate	https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif	https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=BEK5JQCQMED4J&lc=GB&item_name=fullPage%2ejs&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Stackpath	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/stackpath3.png	https://www.stackpath.com/
Browserstack	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/browserstack3.png	http://www.browserstack.com/
CodePen	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/codepen3.png	https://codepen.com
CodeFirst	http://wallpapers-for-ipad.com/fullpage/imgs3/logos/codefirst2.png	https://www.codefirst.co.uk
