# PEEL
Physics Engine Evaluation Lab

![alt text](peel.jpg?raw=true)

PEEL is a tool designed to evaluate, compare and benchmark physics engines. In a way, it is very similar to the old PAL project (Physics Abstraction Layer).

It was initially written to compare PhysX versions between each-other, and catch performance regressions. Support for entirely different engines was added later, giving the tool a much larger scope. To this date it has been successfully used by various people to discover previously unknown issues in their engines, and actually improve them.

Please refer to the user manual for more details.
