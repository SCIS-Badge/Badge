image	https://img.shields.io/pypi/v/secure.svg	https://pypi.org/project/secure/
Python 3	https://img.shields.io/badge/python-3-blue.svg	https://www.python.org/downloads/
image	https://img.shields.io/pypi/l/secure.svg	https://pypi.org/project/secure/
image	https://img.shields.io/badge/code%20style-black-000000.svg	https://github.com/ambv/black
