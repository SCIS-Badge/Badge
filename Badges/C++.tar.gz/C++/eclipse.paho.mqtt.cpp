Build Status	https://travis-ci.org/eclipse/paho.mqtt.cpp.svg?branch=master	https://travis-ci.org/eclipse/paho.mqtt.cpp
