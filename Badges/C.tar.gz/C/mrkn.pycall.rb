Build Status	https://github.com/mrkn/pycall.rb/workflows/CI/badge.svg	https://github.com/mrkn/pycall.rb/actions?query=workflow%3ACI
Build status	https://ci.appveyor.com/api/projects/status/0fad23u4qj1yr49e/branch/master?svg=true	https://ci.appveyor.com/project/mrkn/pycall-rb/branch/master
