# CircularMenu
环形菜单控件。
 ![](https://github.com/sungerk/CircularMenu/blob/master/art/4F32B082-A303-4E1E-BCD1-135A353A9E95.png)
 
![]( https://github.com/sungerk/CircularMenu/blob/master/art/8199CACA-B2E2-4F31-A6F1-03EAED43DF37.png)
  
![](https://github.com/sungerk/CircularMenu/blob/master/art/D35B57CE-5A63-41C9-8620-AFEF6CD3AEBD.png)

![](https://github.com/sungerk/CircularMenu/blob/master/art/FE58B29A-4588-4E1D-AC5B-920CC318E63E.png)

