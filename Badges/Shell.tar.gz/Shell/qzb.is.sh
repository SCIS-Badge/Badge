NPM Version	https://img.shields.io/npm/v/is.sh.svg	https://npmjs.org/package/is.sh
Build	https://img.shields.io/travis/qzb/is.sh/master.svg	https://travis-ci.org/qzb/is.sh
