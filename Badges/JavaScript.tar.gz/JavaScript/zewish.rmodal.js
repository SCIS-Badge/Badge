NPM version	https://img.shields.io/npm/v/rmodal.svg?style=flat-square	https://www.npmjs.com/package/rmodal
Build Status	https://travis-ci.org/zewish/rmodal.js.svg?branch=master	https://travis-ci.org/zewish/rmodal.js
Coverage Status	https://coveralls.io/repos/github/zewish/rmodal.js/badge.svg?branch=master	https://coveralls.io/github/zewish/rmodal.js?branch=master
Dependencies	https://david-dm.org/zewish/rmodal.js.svg	https://david-dm.org/zewish/rmodal.js
Downloads	https://img.shields.io/npm/dm/rmodal.svg?style=flat-square	https://www.npmjs.com/package/rmodal
Logo	https://raw.githubusercontent.com/zewish/rmodal.js/master/logo.png	https://rmodal.js.org
