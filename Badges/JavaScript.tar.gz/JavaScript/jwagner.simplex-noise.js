Build Status	https://travis-ci.org/jwagner/simplex-noise.js.svg?branch=master	https://travis-ci.org/jwagner/simplex-noise.js
