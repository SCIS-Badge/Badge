This is the set of sample projects for the O'Reilly Gradle Book series.

Please feel free to send pull requests that make the use of Gradle or Groovy more idiomatic. Additional samples are also welcomed.

Each project should have a README.md and a run-example.bsh script. The script allows for executions user would type at the command line to showcase that particular example in action.

Thanks,
Matthew McCullough & Tim Berglund, Authors