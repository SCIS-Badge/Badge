Dependency Status	https://david-dm.org/fent/timequeue.js.svg	https://david-dm.org/fent/timequeue.js
codecov	https://codecov.io/gh/fent/timequeue.js/branch/master/graph/badge.svg	https://codecov.io/gh/fent/timequeue.js
