

## nginx-consul

Docker container running an nginx configuration stored in Consul K/V. 
