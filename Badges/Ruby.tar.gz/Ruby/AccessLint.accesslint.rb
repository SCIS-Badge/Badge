Gem Version	https://badge.fury.io/rb/access_lint.svg	http://badge.fury.io/rb/access_lint
Code Climate	https://codeclimate.com/repos/52c4c7ca6956804bb2000905/badges/5a971515dcfd43cf57e1/gpa.svg	https://codeclimate.com/repos/52c4c7ca6956804bb2000905/feed
