npm status	https://img.shields.io/npm/v/@esri/solution-common.svg?style=round-square&color=blue	https://www.npmjs.com/package/@esri/solution-common
Build status	https://img.shields.io/travis/com/Esri/solution.js/develop.svg	https://travis-ci.com/Esri/solution.js
Coverage status	https://coveralls.io/repos/github/Esri/solution.js/badge.svg	https://coveralls.io/github/Esri/solution.js
Apache 2.0 licensed	https://img.shields.io/badge/license-Apache%202.0-blue.svg	#license
