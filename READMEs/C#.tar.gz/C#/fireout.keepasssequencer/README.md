# keepasssequencer

## Getting Started

Have a look at the [wiki for the user documentation](https://github.com/fireout/keepasssequencer/wiki)

## Releases

Releases are located in the github [release section](https://github.com/fireout/keepasssequencer/releases) and in the [release folder](https://github.com/fireout/keepasssequencer/tree/master/release).  
You can copy the Sequencer.dll and Sequencer.dll.config in the KeePass directory.  See the [wiki](https://github.com/fireout/keepasssequencer/wiki/1.-Installation) for more details.

## Source Code

Most recent code reside within the [develop](https://github.com/fireout/keepasssequencer/tree/develop) branch.

