# ArduinoCI Ruby gem (`arduino_ci`) [![Gem Version](https://badge.fury.io/rb/arduino_ci.svg)](https://rubygems.org/gems/arduino_ci)

## [This project has moved to the Arduino CI GitHub Organziation](https://github.com/Arduino-CI/arduino_ci)

## https://github.com/Arduino-CI/arduino_ci
