Unfortunately this project is no longer actively developed.

Use AppleScript baked in to OmniFocus for a more powerful experience:

  `tell application "OmniFocus" to parse tasks into default document with transport text "some text"`
  
Or check out Brett Terpstra's project OTask

http://brettterpstra.com/2011/07/02/otask-cli-for-omnifocus/
