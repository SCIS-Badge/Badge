Build Status	https://travis-ci.org/mattboldt/typed.js.svg?branch=typed-2.0	https://travis-ci.org/mattboldt/typed.js
Code Climate	https://codeclimate.com/github/mattboldt/typed.js/badges/gpa.svg	https://codeclimate.com/github/mattboldt/typed.js
GitHub release	https://img.shields.io/github/release/mattboldt/typed.js.svg	
npm	https://img.shields.io/npm/dt/typed.js.svg	https://img.shields.io/npm/dt/typed.js.svg
GitHub license	https://img.shields.io/badge/license-MIT-blue.svg	https://raw.githubusercontent.com/mattboldt/typed.js/master/LICENSE.txt
