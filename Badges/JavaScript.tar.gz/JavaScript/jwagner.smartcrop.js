Build Status	https://travis-ci.org/jwagner/smartcrop.js.svg?branch=master	https://travis-ci.org/jwagner/smartcrop.js
