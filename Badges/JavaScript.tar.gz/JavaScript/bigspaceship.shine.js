Inline docs	http://inch-ci.org/github/bigspaceship/shine.js.svg?branch=master	http://inch-ci.org/github/bigspaceship/shine.js
