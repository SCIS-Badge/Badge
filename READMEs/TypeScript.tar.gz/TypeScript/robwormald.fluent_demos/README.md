# fluent_demos
Demo code from Reactive Angular2 @ Fluent 2016. Slides [here](https://docs.google.com/presentation/d/1pBM3Is5SrXn_wmK_sF2BDXZUm44BmoUT_Ohg9da6K1k/edit?usp=sharing)

## instructions

- clone this repo
- `npm install`
- `npm install -g typings`
- `typings install`
- `npm start`
