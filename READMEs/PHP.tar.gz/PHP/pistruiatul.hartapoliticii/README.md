<img src="http://www.hartapoliticii.ro/images/top_title.png" align="right">
### Un pic despre harta politicii

Harta Politicii își propune să fie un repository complet de date despre
politicienii români, cu scopul declarat de a ne ajuta să ne informăm și să
putem decide în cunoștință de cauză.

Politicienii români tind să abuzeze promisiunile și mult prea puțini se referă
la trecut și la fapte care să le susțină. Noi ne dorim să schimbăm acest lucru.

http://hartapoliticii.ro


### Dacă vrei să participi

Citește [wiki-ul](https://github.com/pistruiatul/hartapoliticii/wiki), acolo găsești
tot ce trebuie.


Am creat două grupuri de discuții pentru harta politicii:

- [hartapoliticii-discuss](http://groups.google.com/group/hartapoliticii-discuss) – unde pot fi discutate teme generale despre harta politicii, ce direcție ar trebui să ia, feedback, păreri, opinii
- [hartapoliticii-dev](http://groups.google.com/group/hartapoliticii-dev) – pentru dezvoltatori și discuții tehnice, referințe la cod, alerte

Să te înscrii pe grupul [hartapoliticii-discuss](http://groups.google.com/group/hartapoliticii-discuss) este un pas foarte bun în a începe să participi la proiect.

Dacă vrei să discutăm mai mult și nu îți plac grupurile de discuții dă-mi
un email la octavian.costache [at] gmail.com (promit să răspund la toate).
