# [Sensei LMS](https://woocommerce.com/products/sensei/)
**A learning management plugin for WordPress, which provides the smoothest platform for helping you teach anything.**

Sensei LMS is a commercial plugin available from https://woocommerce.com/products/sensei/. The plugin is hosted here on a public Github repository in order to better facilitate community contributions from developers and users alike. If you have a suggestion, a bug report, or a patch for an issue, feel free to submit it here (following the guidelines below). We do ask, however, that if you are using the plugin on a live site that you please purchase a valid license from the website. We cannot provide support or one-click updates to anyone that does not hold a valid license key.

## Architecture

The Sensei LMS structural model can be divided into components. These components are not well separated in the current
version, but serves as a model for future changes.

* Core
  * Post Types
  * Settings
* Users
  * Teachers
  * Learners
  * Messages
  * Emails
* Content
  * Courses
  * Modules
  * Lessons
  * Shortcodes
* Analytics
* Assessment
* Views
  * Templates (Frontend)
  * Admin
  * Installation
* Access Management
  * eCommerce
  * Membership
  * Permissions

## Contributing to Sensei LMS
See our guidelines here: [Contributing to Sensei LMS](https://github.com/woothemes/sensei/blob/master/CONTRIBUTING.md)

## Development Blog
Please follow further development updates at [https://senseilms.com/blog/](https://senseilms.com/blog/)
