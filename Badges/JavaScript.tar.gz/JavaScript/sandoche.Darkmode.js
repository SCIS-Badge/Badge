npm version	https://img.shields.io/npm/v/darkmode-js/latest.svg	https://npmjs.com/package/darkmode-js
npm downloads	https://img.shields.io/npm/dt/darkmode-js.svg	https://npmjs.com/package/darkmode-js
License	https://img.shields.io/npm/l/darkmode-js.svg	./LICENSE
Medium Badge	https://badgen.net/badge/icon/medium?icon=medium&label	https://medium.com/@sandoche
Twitter: sandochee	https://img.shields.io/twitter/follow/sandochee.svg?style=social	https://twitter.com/sandochee
patreon.png	https://c5.patreon.com/external/logo/become_a_patron_button.png	https://www.patreon.com/sandoche
patreon.png	https://c5.patreon.com/external/logo/become_a_patron_button.png	https://www.patreon.com/sandoche
