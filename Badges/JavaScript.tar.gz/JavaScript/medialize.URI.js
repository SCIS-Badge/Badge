CDNJS	https://img.shields.io/cdnjs/v/URI.js.svg	https://cdnjs.com/libraries/URI.js
