image	https://img.shields.io/pypi/v/chartkick.svg	https://pypi.python.org/pypi/chartkick
image	https://travis-ci.org/mher/chartkick.py.svg?branch=master	https://travis-ci.org/mher/chartkick.py
