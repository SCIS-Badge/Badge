Tweezer.js on NPM	https://img.shields.io/npm/v/tweezer.js.svg?style=flat-square	https://www.npmjs.com/package/tweezer.js
Tweezer.js Downloads on NPM	https://img.shields.io/npm/dm/tweezer.js.svg?style=flat-square	https://www.npmjs.com/package/tweezer.js
Standard JavaScript Style	https://img.shields.io/badge/code_style-standard-brightgreen.svg?style=flat-square	http://standardjs.com/
Built With Love	http://forthebadge.com/images/badges/built-with-love.svg	http://forthebadge.com
