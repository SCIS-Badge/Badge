Build Status	https://api.travis-ci.org/jimeh/stub.sh.svg	https://travis-ci.org/jimeh/stub.sh
