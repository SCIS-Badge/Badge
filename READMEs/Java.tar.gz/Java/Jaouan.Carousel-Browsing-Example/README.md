Android - Carousel browsing example
========

It's just an example of carousel browsing, a bit inspired by [Frank Lau's animation](https://dribbble.com/shots/2906536-animation).

![demo](art/demo.gif)


License
========

[Apache License Version 2.0](LICENSE)