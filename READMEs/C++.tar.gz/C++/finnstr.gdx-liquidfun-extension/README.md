<img src="liquidfun-extension-logo.png"
alt="gdx-liquidfun-extension logo" style="float:right;" />

gdx-liquidfun-extension
=======================

An extension to implement liquidfun into libgdx.
Read the wiki to learn how to use this extension in your project.

You can also get some information or ask some questions [in the badlogic forum][].

  [in the badlogic forum]: http://www.badlogicgames.com/forum/viewtopic.php?f=17&t=13717

If you want to stay up to date with my projects [like my Facebook Page][].
[like my Facebook Page]: https://www.facebook.com/Finnstr-Productions-482229171950290/
