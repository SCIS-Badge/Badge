Build Status	https://travis-ci.org/ekalinin/sitemap.js.svg?branch=master	https://travis-ci.org/ekalinin/sitemap.js
