# react-rails redux sample
this is a simple example application using  react-rails and redux
* rails 5.0.0.1
* redux 3.0.4
* react-rails 1.10.0
* react 15.4.1

## Installation

```
git clone https://github.com/suzan2go/react-rails-redux-sample.git
cd react-rails-redux-sample
bundle install
npm install
```


## Troubleshooting

```
Error while running /home/pavel/projects/react-rails-redux-sample/node_modules/.bin/browserifyinc -t babelify --list --cachefile=/home/pavel/projects/react-rails-redux-sample/tmp/cache/browserify-rails/browserifyinc-cache.json -o "/home/pavel/projects/react-rails-redux-sample/tmp/cache/browserify-rails/output20160329-23163-17hjpm7" -:

/usr/bin/env: node No such file or directory

(in /home/pavel/projects/react-rails-redux-sample/app/assets/javascripts/components.js)
```

You can find answer here: http://stackoverflow.com/questions/20886217/browserify-error-usr-bin-env-node-no-such-file-or-directory
