npm version	https://img.shields.io/npm/v/decimal.js.svg	https://www.npmjs.com/package/decimal.js
Build Status	https://travis-ci.org/MikeMcl/decimal.js.svg	https://travis-ci.org/MikeMcl/decimal.js
CDNJS	https://img.shields.io/cdnjs/v/decimal.js.svg	https://cdnjs.com/libraries/decimal.js
