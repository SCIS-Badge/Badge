<a href='https://ko-fi.com/A302HW7' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi4.png?v=f' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a> 

<a href="//imgur.com/RRh9qzz"><img src="http://imgur.com/RRh9qzz.gif" title="source: imgur.com" /></a>


###Usage

This can be used as a custom view in messaging, chat, music, video application to preview the contents of the URL link in an application.

###What made me to do this repo?

This repo is truely made on the inspiration of latest version of WhatsApp Android app which fetches all the contents from the URL link.

### Credits:
1. Koushik Dutta
2. Leonardo Cardoso



