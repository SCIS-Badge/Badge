CMD	https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg	https://github.com/sindresorhus/awesome
Open in Cloud Shell	https://gstatic.com/cloudssh/images/open-btn.png	https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/cihanmehmet/sub.sh&tutorial=README.md
