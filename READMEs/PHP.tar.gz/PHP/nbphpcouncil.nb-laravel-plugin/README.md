nb-laravel-plugin
=================

Laravel Framework plugin for NetBeans 7.4+
