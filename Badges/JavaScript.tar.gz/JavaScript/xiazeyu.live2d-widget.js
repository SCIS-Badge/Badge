npm	https://badge.fury.io/js/live2d-widget.svg?label=live2d-widget	https://www.npmjs.com/package/live2d-widget
deps	https://img.shields.io/david/xiazeyu/live2d-widget.js.svg	javascript:void(0);
devdeps	https://img.shields.io/david/dev/xiazeyu/live2d-widget.js.svg	javascript:void(0);
downloads	https://img.shields.io/npm/dt/live2d-widget.svg	https://www.npmjs.com/package/live2d-widget
downloads-month	https://img.shields.io/npm/dm/live2d-widget.svg	https://www.npmjs.com/package/live2d-widget
GitHub stars	https://img.shields.io/github/stars/xiazeyu/live2d-widget.js.svg	https://github.com/xiazeyu/live2d-widget.js/stargazers
GitHub forks	https://img.shields.io/github/forks/xiazeyu/live2d-widget.js.svg	https://github.com/xiazeyu/live2d-widget.js/network
GitHub issues	https://img.shields.io/github/issues/xiazeyu/live2d-widget.js.svg	https://github.com/xiazeyu/live2d-widget.js/issues
Commitizen friendly	https://img.shields.io/badge/commitizen-friendly-brightgreen.svg	http://commitizen.github.io/cz-cli/
PRs Welcome	https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square	http://makeapullrequest.com
license	https://img.shields.io/github/license/xiazeyu/live2d-widget.js.svg	https://github.com/xiazeyu/live2d-widget.js/blob/master/LICENSE
Backers on Open Collective	https://opencollective.com/live2d-widgetjs/backers/badge.svg	#backers
Sponsors on Open Collective	https://opencollective.com/live2d-widgetjs/sponsors/badge.svg	#sponsors
Author	https://img.shields.io/badge/author-cneyhn-green.svg	https://delusion.coding.me/
Author QQ	https://img.shields.io/badge/QQ-1106996185-blue.svg	tencent://message/?uin=1106996185&Site=Senlon.Net&Menu=yes
Collaborator 0	https://img.shields.io/badge/author-xiazeyu-green.svg	https://xiazeyu.coding.me/
Collaborator 0 QQ	https://img.shields.io/badge/QQ-2320732807-blue.svg	tencent://message/?uin=2320732807&Site=Senlon.Net&Menu=yes
current-device	https://img.shields.io/npm/v/current-device.svg?label=current-device	https://github.com/matthewhudson/current-device
