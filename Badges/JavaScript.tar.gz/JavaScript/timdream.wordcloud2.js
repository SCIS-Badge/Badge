npm version	https://badge.fury.io/js/wordcloud.svg	http://badge.fury.io/js/wordcloud
