npm	https://img.shields.io/npm/v/uptime.js.svg?style=plastic	https://www.npmjs.com/package/uptime.js
npm	https://img.shields.io/npm/dt/uptime.js.svg?style=plastic	https://www.npmjs.com/package/uptime.js
GitHub license	https://img.shields.io/github/license/intelligo-systems/uptime.js.svg	https://github.com/intelligo-systems/uptime.js/blob/master/LICENSE
Twitter	https://img.shields.io/twitter/url/https/github.com/intelligo-systems/uptime.js.svg?style=social	https://twitter.com/intent/tweet?text=Wow:&url=https%3A%2F%2Fgithub.com%2Fintelligo-systems%2Fintelligo
NPM	https://nodei.co/npm/uptime.js.png?downloads=true&downloadRank=true&stars=true	https://nodei.co/npm/uptime.js/
