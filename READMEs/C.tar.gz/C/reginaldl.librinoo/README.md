# Following Github acquisition from Microsoft, this repository has been moved to gitlab: https://gitlab.com/reginaldl/librinoo
