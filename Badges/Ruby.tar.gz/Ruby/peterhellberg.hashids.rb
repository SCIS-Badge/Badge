Build Status	https://travis-ci.org/peterhellberg/hashids.rb.svg?branch=master	http://travis-ci.org/peterhellberg/hashids.rb
