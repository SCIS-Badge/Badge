Gem Version	https://badge.fury.io/rb/m.svg	https://rubygems.org/gems/m
Code Climate	https://codeclimate.com/github/qrush/m.svg	https://codeclimate.com/github/qrush/m
Build Status	https://travis-ci.org/qrush/m.svg?branch=master	https://travis-ci.org/qrush/m
Coverage Status	https://coveralls.io/repos/qrush/m/badge.svg?branch=master	https://coveralls.io/r/qrush/m
