Open Frameworks Tutorials for Beginners
================================

Slideshare presentation available here : 
Day 1 : https://drive.google.com/file/d/0B7eqRqc3T7ZyRjFLU1A3a0NVb1k/edit?usp=sharing
Day 2 : https://drive.google.com/file/d/0B7eqRqc3T7ZyYnpodkl6dGhNZm8/edit?usp=sharing


Project files support
* xcode on OSX
* visual studio 2012 on Windows 7/8  ( not all examples... ) 

---------------------------------


00_basics is an example of basic class structure

00_translation is an example of transformation matrices


01_Circles - generative art app with mirroring
02_Animator - interactive recording of mouseClicks and storing them in FBO frames
03_Particles - particles example and openGL drawing modes
04_fragShader_fun - using fragment shaders from glsl.heroku.com
05_pixels - stipple effect on various images sources



