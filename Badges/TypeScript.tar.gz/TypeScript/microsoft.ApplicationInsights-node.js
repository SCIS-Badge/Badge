npm version	https://badge.fury.io/js/applicationinsights.svg	http://badge.fury.io/js/applicationinsights
Build Status	https://travis-ci.org/Microsoft/ApplicationInsights-node.js.svg?branch=master	https://travis-ci.org/Microsoft/ApplicationInsights-node.js
