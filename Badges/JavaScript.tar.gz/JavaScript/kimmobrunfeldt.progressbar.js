Build Status	https://api.travis-ci.org/kimmobrunfeldt/progressbar.js.svg?branch=master	https://travis-ci.org/kimmobrunfeldt/progressbar.js
Sauce Test Status	https://app.saucelabs.com/browser-matrix/kimmobrunfeldt.svg	https://app.saucelabs.com/u/kimmobrunfeldt
